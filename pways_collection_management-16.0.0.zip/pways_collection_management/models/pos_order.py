# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class PosOrder(models.Model):
    _inherit = "pos.order"

    def _prepare_invoice_vals(self):
        res = super(PosOrder, self)._prepare_invoice_vals()
        res.update({'ntfl_type': 'pos'})
        return res
