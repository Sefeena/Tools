# -*- coding: utf-8 -*-
from odoo import fields, api, models, _

class ResCompany(models.Model):
    _inherit = "res.company"

    nhif_journal_id = fields.Many2one('account.journal', string="Journal")
    nhif_credit_account_id = fields.Many2one('account.account', string="Credit Account")
    nhif_debit_account_id = fields.Many2one('account.account', string="Debit Account")
