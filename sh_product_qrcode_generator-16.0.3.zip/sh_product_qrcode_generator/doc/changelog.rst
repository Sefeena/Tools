16.0.1(Date: 10 September 2022)
-------------------------------
Initial Release.

16.0.2(Date: 31 January 2023)
-----------------------------
- [UPDATE]  
    - Add Search by QR Code while Adding Product in line.
    - Add Report for Print QR code Labels in Product.

16.0.3(Date: 16 March 2023)
---------------------------
- [FIX] 
    - Product Template variant not created properly.