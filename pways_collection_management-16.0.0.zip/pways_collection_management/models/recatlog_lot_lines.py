from odoo import models, fields, api, _

class StockProductionLot(models.Model):
    _inherit = 'stock.lot'

    recatlog_lot_line_ids = fields.One2many('recatalog.lot.line', 'lot_id')  
    extra_net_kg = fields.Float(string='Extra Net KG', compute='_compute_extra_net_kg', digits='Product Unit of Measure')
    transfer_to_agent = fields.Many2one('res.partner', string='Agent', domain=[('is_agent', '=', True)])
    
    @api.depends('recatlog_lot_line_ids', 'recatlog_lot_line_ids.lot_id')
    def _compute_extra_net_kg(self):
        for line in self:
            extra_net_kg = 0
            for catlog_line in line.recatlog_lot_line_ids:
                parent_uom = self.env['uom.uom'].search([('category_id', '=', catlog_line.sample_product_uom.category_id.id), ('uom_type', '=', 'reference')], limit=1)
                extra_net_kg += catlog_line.sample_product_uom._compute_quantity(catlog_line.sample_product_qty, parent_uom, rounding_method='HALF-UP')
            line.extra_net_kg = extra_net_kg

class ReCatalogLotLine(models.Model):
    _name = 'recatalog.lot.line'
    _description = 'ReCatalog Lot Lines'

    lot_id = fields.Many2one('stock.lot')
    catalog_id = fields.Many2one('catalog.order', string="Catlog Order")
    sample_product_id = fields.Many2one('product.product', string="Sample Product")
    sample_product_uom = fields.Many2one('uom.uom', string="Unit of Measure")
    sample_product_qty = fields.Float('Quantity')