from odoo import models, fields, api, _

class CcPerfromanceWizard(models.TransientModel):
    _name = 'cc.performance.wizard'

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    route_id = fields.Many2one("routes.routes")
    location_id = fields.Many2one('stock.location','Collection Center')

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'route_id' : self.route_id.id,
            'location_id': self.location_id.id,
        }
        return self.env.ref('pways_collection_management.cc_performance_report').report_action(self, data=data)

class CcPerfromanceWizardReport(models.AbstractModel):
    _name = 'report.pways_collection_management.cc_performance_template'

    def _prepare_report_lines(self, weighment_ids,location_id):
        # lines = []
        # import pdb;pdb.set_trace();
        weighment_line_ids =  weighment_ids.mapped('weighment_line_ids').filtered(lambda x: x.location_id.id == location_id)
        group_by_location = {}
        for line in weighment_line_ids:
            if (line.location_id.id,line.weighment_id.route_id.id,line.weighment_id.weighment_date) in group_by_location:
                group_by_location[(line.location_id.id,line.weighment_id.route_id.id,line.weighment_id.weighment_date)] |= line
            else:
              group_by_location[(line.location_id.id,line.weighment_id.route_id.id,line.weighment_id.weighment_date)] = line
        vals = []
        for location_route_date, lines in group_by_location.items():
            net_weight = sum(lines.mapped('net'))
            farmer_count = self.env['farm.info'].search_count([('location_id','=',location_id)])
            # farmer_active_count = len(self.env['farm.info'].search([('location_id','=',location_id),('farmer_regist_id.contract_status','=','active')]))
            farmer = lines.mapped('weighment_id').mapped('farmer_id').mapped('farmer_id')
            farmer_active_count = len(farmer)
            # farmer_active_count = len([farm for farm in farmer.mapped('contract_status') if farm == 'active'])
            vals.append({
                 'date': location_route_date[2],
                 'collection_center' :  self.env['stock.location'].browse(location_route_date[0]).name or '',
                 'net_weight' : round(net_weight, 2) or 0.0, 
                 'route_name' : self.env['routes.routes'].browse(location_route_date[1]).name, 
                 'farmer_count': farmer_count,
                 'farmer_active_count':farmer_active_count,
                })
        return vals


    def get_domain(self, data):
        domain = []
        route_id = self.env['routes.routes'].browse(data.get('route_id'))
        if data.get('date_from') and data.get('date_to'):
             domain += [('weighment_date', '>=', data.get('date_from')), ('weighment_date', '<=', data.get('date_to'))]
        if route_id:
            domain += [('route_id', '=', route_id.id)]
        return domain


    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        route_id = self.env['routes.routes'].browse(data.get('route_id'))
        domain = self.get_domain(data)
        location = data.get('location_id')
        weighment_ids = self.env['grower.weighment'].search(domain)
        lines = self._prepare_report_lines(weighment_ids, location)
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date_from' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'route_name' : route_id.name ,
            'lines': lines,
        }