from odoo import fields, models, api
from dateutil.relativedelta import relativedelta

class MedicalReports(models.Model):
    _name = 'medical.report.line'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    name = fields.Char(string="Name")
    medical_report = fields.Binary('Medical Report', attachment=True)
    date_of_examination = fields.Date(string="Date Of Examination")
    next_date = fields.Date(string="Next Date")
    employee_id = fields.Many2one('hr.employee', string="Employee")
    process = fields.Boolean('Proccess')
    user_id = fields.Many2one('res.users', default=lambda self: self.env.user)

    @api.onchange('date_of_examination')
    def _onchange_date_of_examination(self):
        if self.date_of_examination:
            six_months_after = self.date_of_examination + relativedelta(months=6)
            self.next_date = six_months_after