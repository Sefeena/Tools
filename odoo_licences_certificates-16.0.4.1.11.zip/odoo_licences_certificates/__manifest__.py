# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd.

# See LICENSE file for full copyright and licensing details.

{
    'name': 'Certificates and Licenses with Expiry Management',
    'currency': 'EUR',
    'license': 'Other proprietary',
    'price': 99.0,
    'author': "Probuse Consulting Service Pvt. Ltd.",
    'website': "http://www.probuse.com",
    'images': ['static/description/lic_image.png'],
    'summary': 'This app allow you to manage Recycling and Waste items.',
    'support': 'contact@probuse.com',
    'live_test_url': 'https://probuseappdemo.com/probuse_apps/odoo_licences_certificates/922',#'https://youtu.be/tka1K2y0XrM',
    'description': """
Certificates
Certificate
Certificates expire
Certificates expiry
Certificate expire
Certificate expire date
Certificates and Licenses with Expiry Management
Licenses
License
Licenses management
License management
License app
Certificate app
expiry management


""",
    'version': '4.1.11',
    'category': 'Services/Project',
    'depends': [
                'sale',
                'hr',
                'project',
                'website',
                'portal',
                ],
    'data': [
        'security/licences_certificate_security.xml',
        'security/ir.model.access.csv',
        'data/licences_certificate_cron.xml',
        'data/mail_templete_data.xml',
        'views/licences_certificate_type_view.xml',
        'views/licences_certificate_view.xml',
        'views/report_licences_certificate.xml',
        'views/res_partner_view.xml',
        'views/record_licences_view.xml',
        'views/record_licenes_report.xml',
        'views/record_licences_template.xml',
    ],
    'installable': True,
    'application': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
