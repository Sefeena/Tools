# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, date, timedelta
import calendar


class FarmerPaymentAdvice(models.TransientModel):
    _name = "farmer.payment.advice.wizard"
    _description = "Farmer Payment Advice Wizard"

    def _get_default_month(self):
        return str(date.today().month)

    def _get_default_year(self):
        return self.env['ntfl.year'].search([('name', '=', str(date.today().year))], limit=1)

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    partner_id = fields.Many2one('res.partner', string="Out Grower", required=True)
    month = fields.Selection([
                            ('1', 'JAN'),
                            ('2', 'FEB'),
                            ('3', 'MAR'),
                            ('4', 'APR'),
                            ('5', 'MAY'),
                            ('6', 'JUN'),
                            ('7', 'JAL'),
                            ('8', 'AUG'),
                            ('9', 'SEP'),
                            ('10', 'OCT'),
                            ('11', 'NOV'),
                            ('12', 'DEC'),
    ], default=_get_default_month, required=True)
    year = fields.Many2one('ntfl.year', string='Year', required=True, default=_get_default_year)

    @api.onchange('month', 'year')
    def _onchange_month_year(self):
        today = date.today()
        if self.month and self.year:
            last_day = calendar.monthrange(int(self.year.name), int(self.month))[1]
            date_from = today.replace(year=int(self.year.name), month=int(self.month), day=1).strftime("%Y-%m-%d")
            date_to = today.replace(year=int(self.year.name), month=int(self.month), day=last_day).strftime("%Y-%m-%d")
            self.date_from = date_from
            self.date_to = date_to
        # payment_ids = []
        # self.payment_id = False
        # if self.date_from and self.date_to and self.partner_id:
        #     weighment_ids = self.env['grower.weighment'].search([
        #         ('farmer_id', '=', self.partner_id.id),
        #         ('weighment_date', '>=', self.date_from),
        #         ('weighment_date', '<=', self.date_to),
        #     ])
        #     picking_ids = self.env['stock.picking'].search([('weighment_id', 'in', weighment_ids.ids)])
        #     bill_ids = self.env['account.move'].search([('picking_id', 'in', picking_ids.ids)])
        #     for bill in bill_ids:
        #         inv_payment_ids = [line.get('account_payment_id') for line in bill._get_reconciled_info_JSON_values()]
        #         payment_ids += inv_payment_ids
        # return {'domain': {'payment_id': [('id', 'in', payment_ids)]}}

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'partner_id': self.partner_id.id,
        }
        return self.env.ref('pways_collection_management.action_farmer_payment_advice_report').report_action(self, data=data)

class PaymentAdviceReport(models.AbstractModel):
    _name = 'report.pways_collection_management.fp_advice_report'

    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_from = data.get('date_from')
        date_to = data.get('date_to')
        partner_id = data.get('partner_id')
        payment_id = self.env['account.payment'].sudo().browse(data.get('payment_id'))

        paid_bill_ids = self.env['account.move'].search([
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('state', '=', 'posted'),
            ('partner_id', '=', partner_id),
            ('payment_state', 'in', ('paid', 'partial')),
        ])
        bill_payment_ids = []
        for bill in paid_bill_ids:
            for line in bill._get_reconciled_info_JSON_values():
                rec_payment_id = line.get('account_payment_id')
                if rec_payment_id and rec_payment_id not in bill_payment_ids:
                    bill_payment_ids.append(line.get('account_payment_id'))

        bill_payments = self.env['account.payment'].browse(bill_payment_ids).filtered(lambda x: not x.farmer_advance)

        transport_product_id = self.env.ref('pways_collection_management.transport_rate_product')
        fertilizer_product_id = self.env.ref('pways_collection_management.fertilizer_deduction_product')
        gl_bill_lines = paid_bill_ids.mapped('invoice_line_ids').filtered(lambda x: x.product_id.green_leaf_ok)
        transport_lines = paid_bill_ids.mapped('invoice_line_ids').filtered(lambda x: x.product_id == transport_product_id)
        fertilizer_lines = paid_bill_ids.mapped('invoice_line_ids').filtered(lambda x: x.product_id == fertilizer_product_id)
        total_qty = round(sum(gl_bill_lines.mapped('quantity')), 2)
        tranport_rate = round(sum(transport_lines.mapped('price_subtotal')), 2)
        nhif_move_id = self.env['account.move'].search([
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('partner_id', '=', partner_id),
            ('is_nhif_deduction', '=', True),
        ], limit=1)
        advance_ids = self.env['out.grower.loan'].search([
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('farmer_id', '=', partner_id),])

        loan_payment_ids = self.env['account.payment'].search([
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('state', '=', 'posted'),
            ('farmer_advance', '=', True),
            ('partner_id', '=', partner_id),
            ('payment_type', '=', 'outbound'),
            ('partner_type', '=', 'supplier'),
        ])
        loan_amount = sum(loan_payment_ids.mapped('amount'))
        fertilizer_amount = abs(sum(fertilizer_lines.mapped('price_subtotal')))
        net_amount = sum(gl_bill_lines.mapped('price_subtotal'))
        nhif_amount = nhif_move_id.amount_total
        advance_amount = sum(advance_ids.mapped('total_amount'))

        total_earning = round(net_amount - abs(tranport_rate), 2)
        total_deduction = round(nhif_amount + abs(fertilizer_amount) + advance_amount, 2) + loan_amount
        net_paid = sum(bill_payments.mapped('amount'))
        return {
            'net_supply_gl': total_qty,
            'net_amount': net_amount,
            'payment_ref': ', '.join(bill_payments.mapped('name')),
            'nhif_amount': nhif_amount,
            'bank_id': payment_id.partner_bank_id,
            'tranport_rate': tranport_rate,
            'fertilizer_amount': fertilizer_amount,
            'net_paid': net_paid,
            'advance_amount': advance_amount,
            'docs' : docs,
            'loan_amount': loan_amount,
            'total_deduction': total_deduction,
            'total_earning': total_earning,
        }
