# -*- coding: utf-8 -*-
# from odoo import http


# class NtInstallmentManagement(http.Controller):
#     @http.route('/nt_installment_management/nt_installment_management', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/nt_installment_management/nt_installment_management/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('nt_installment_management.listing', {
#             'root': '/nt_installment_management/nt_installment_management',
#             'objects': http.request.env['nt_installment_management.nt_installment_management'].search([]),
#         })

#     @http.route('/nt_installment_management/nt_installment_management/objects/<model("nt_installment_management.nt_installment_management"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('nt_installment_management.object', {
#             'object': obj
#         })
