# -*- coding: utf-8 -*-

from . import category
from . import configuration
from . import customer
from . import installment
from . import product
from . import purchase
from . import vendor
