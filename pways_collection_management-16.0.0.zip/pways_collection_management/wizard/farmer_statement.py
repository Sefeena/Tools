# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime


class FarmerStatementWizard(models.TransientModel):
    _name = 'farmer.statement.wizard'
    _description = "Trip Details Wizard"

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    report_type = fields.Selection([('farmer', 'Out Grower'), ('vehicle', 'Vehicle'), ('trip', 'Trip')], default='farmer')
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    trip_id = fields.Many2one('trip.trip', 'Trip')
    farmer_id = fields.Many2one('res.partner', string="Out Grower", domain=[('is_farmer', '=', True)])

    @api.onchange('report_type')
    def _onchange_report_type(self):
        self.vehicle_id = False
        self.trip_id = False
        self.farmer_id = False

    def action_print_report(self):
        header = {'farmer': 'Out Grower Weighment Statement', 'vehicle': 'Out Grower Vehicle Wise', 'trip': 'Out Grower Trip Wise'}
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'vehicle_id' : self.vehicle_id.id,
            'trip_id' : self.trip_id.id,
            'vehicle_id' : self.vehicle_id.id,
            'farmer_id' : self.farmer_id.id,
            'report_type': self.report_type,
            'report_header': header.get(self.report_type)
        }
        return self.env.ref('pways_collection_management.farmer_statement_report').report_action(self, data=data)

class FarmerStatementReport(models.AbstractModel):
    _name = 'report.pways_collection_management.farmer_statement_template'

    def _prepare_report_lines(self, weighment_ids):
        lines = []
        for record in weighment_ids.mapped('weighment_line_ids'):
            w_date = record.weighment_id.weighment_date
            lines.append({
                'date': w_date and w_date.strftime('%d-%m-%Y') or '',
                'farmer_name': record.weighment_id.farmer_id.name,
                'farmer_code': record.weighment_id.farmer_id.code or '',
                'national_id': record.weighment_id.farmer_id.national_id or '',
                'collection_center':  record.location_id.name or '',
                'trip_name': record.weighment_id.trip_id.name,
                'transaction_no': record.transaction_no or '',
                'vehcile_no': record.weighment_id.vehicle_id.license_plate or '',
                'gross_weight': round(record.weight, 2) or 0.0,
                'tare_weight': round(record.tare, 2) or 0.0,
                'moisture': round(record.moisture, 2) or 0.0,
                'net_weight': round(record.net, 2) or 0.0,
            })
        return lines
        
    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        farmer_id = self.env['res.partner'].browse(data.get('farmer_id'))
        trip_id = self.env['trip.trip'].browse(data.get('trip_id'))
        report_type = data.get('report_type')
        domain = [('weighment_date', '>=', data.get('date_from')), ('weighment_date', '<=', data.get('date_to'))]

        if report_type == 'vehicle' and vehicle_id:
            domain += [('vehicle_id', '=', vehicle_id.id)]
        if report_type == 'farmer' and farmer_id:
            domain += [('farmer_id', '=', farmer_id.id)]
        if report_type == 'trip' and trip_id:
            domain += [('trip_id', '=', trip_id.id)]

        weighment_ids = self.env['grower.weighment'].search(domain)
        lines = self._prepare_report_lines(weighment_ids)
        # solved_lines = weighment_ids.mapped('weighment_line_ids')#.filtered(lambda x: x.ticket_id)
        # ticket_lines = self._prepare_ticket_lines(solved_lines)

        # if report_type == 'farmer' and farmer_id:
            # in_domain = [('create_date', '>=', data.get('date_from')), ('create_date', '<=', data.get('date_to')), ('to_farmer_id', '=', farmer_id.id), ('purpose_type', '=', 'transfer')]
            # ticket_ids = self.env['helpdesk.ticket'].search(in_domain)
            # in_line_vals = self._prepare_in_lines(ticket_ids)
            # ticket_lines = ticket_lines + in_line_vals

        final_net_wt = 0.0
        for line in lines:
            final_net_wt += line.get('net_weight')
        # for t_line in ticket_lines:
        #     if t_line.get('txn_type') in ('DEL', 'OUT'):
        #         final_net_wt -= t_line.get('net_weight')
        #     else:
        #         final_net_wt += t_line.get('net_weight')

        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'from_date':  data.get('date_from'),
            'date_to':  data.get('date_to'),
            'docs': docs,
            'lines': lines,
            # 'ticket_lines': ticket_lines,
            'final_net_wt': round(final_net_wt, 2),
            'report_header': data.get('report_header'),
        }


    # def _prepare_ticket_lines(self, weighment_line_ids):
    #     lines = []
    #     for line in weighment_line_ids:
    #         weighment_id = line.weighment_id
    #         w_date = line.weighment_id.weighment_date
    #         farmer_id = weighment_id.farmer_id
    #         location_id = line.location_id
    #         txn_type = ''
    #         if line.ticket_id.purpose_type == 'transfer':
    #             txn_type = 'OUT'
    #             farmer_id = line.ticket_id.to_farmer_id
    #             location_id = line.ticket_id.location_id
    #         else:
    #             txn_type = 'DEL'

    #         lines.append({
    #             'date': w_date and w_date.strftime('%d-%m-%Y') or '',
    #             'txn_type': txn_type,
    #             'farmer_name': farmer_id.name,
    #             'farmer_code': farmer_id.code or '',
    #             'national_id': farmer_id.national_id or '',
    #             'collection_center': location_id.name or '',
    #             'trip_name': weighment_id.trip_id.name,
    #             'transaction_no': line.transaction_no or '',
    #             'vehcile_no': weighment_id.vehicle_id.license_plate or '',
    #             'gross_weight': round(line.weight, 2) or 0.0,
    #             'tare_weight': round(line.tare, 2) or 0.0,
    #             'moisture': round(line.moisture, 2) or 0.0,
    #             'net_weight': -round(line.net, 2) or 0.0,
    #         })
    #     return lines

    # def _prepare_in_lines(self, ticket_ids):
    #     lines = []
    #     for ticket in ticket_ids:
    #         g_lines = self.env['grower.weighment.line'].search([('ticket_id', '=', ticket.id)])
    #         for line in g_lines:
    #             weighment_id = line.weighment_id
    #             w_date = line.weighment_id.weighment_date
    #             farmer_id = line.ticket_id.partner_id
    #             location_id = line.ticket_id.location_id

    #             lines.append({
    #                 'date': w_date and w_date.strftime('%d-%m-%Y') or '',
    #                 'txn_type': 'IN',
    #                 'farmer_name': farmer_id.name,
    #                 'farmer_code': farmer_id.code or '',
    #                 'national_id': farmer_id.national_id or '',
    #                 'collection_center': location_id.name or '',
    #                 'trip_name': weighment_id.trip_id.name,
    #                 'transaction_no': line.transaction_no or '',
    #                 'vehcile_no': weighment_id.vehicle_id.license_plate or '',
    #                 'gross_weight': round(line.weight, 2) or 0.0,
    #                 'tare_weight': round(line.tare, 2) or 0.0,
    #                 'moisture': round(line.moisture, 2) or 0.0,
    #                 'net_weight': round(line.net, 2) or 0.0,
    #             })
    #     return lines