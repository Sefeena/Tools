=================
Claims Management
=================

This application allows you to track your customers/vendors claims and grievances.

Contributors
------------

* Sodexis, Inc <dev@sodexis.com>

This module is maintained by the Sodexis.
