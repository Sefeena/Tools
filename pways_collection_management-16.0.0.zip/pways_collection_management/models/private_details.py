# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from datetime import datetime
from dateutil.relativedelta import relativedelta

class HrEmployee(models.Model):
    _inherit = "hr.employee"

    medical_details_ids = fields.One2many('medical.report.line', 'employee_id', string='Medical Details')
    certification_ids = fields.One2many('education.certification', 'employee_id', string='Medical Details')
    practice_emp_ids= fields.One2many('practice.employee', 'employee_id', string='Employee Parameters')
    private_details_ids =fields.One2many('private.details','employee_id',string="Personal Enformation")
    start_date = fields.Date(string="Start Date", copy=False)
    end_date = fields.Date(string="End Date", copy=False)
    location = fields.Char(string="Location")
    description = fields.Text(string="Description", copy=False)
    labour_count = fields.Integer(compute='_casual_labour', string='#CasualLabour')
    state =fields.Selection([('draft','Draft'),('first_approval','First Approval'),('second_approval','Employee'),('cancelled','Cancelled'),], default="draft", string="State")
    practice_ids = fields.Many2many('hr.applicant.parameters', string='KPI')
    employee_type =fields.Selection([('permanent','Permanent'),('temporary','Temporary'),('secondary','Secondary'), ('casual', 'Casual'), ('other','Other'),], default="temporary", string="Employee Type")
    hourly_rate = fields.Float(string="Hourly Rate")
    job_position = fields.Many2one('hr.job',string="Job Position")
    job_detail = fields.Text('Job Detail')
    is_partner = fields.Boolean(string="Is Partner")
    emp_partner_id = fields.Many2one('res.partner', string="Partner")

    @api.model
    def create(self, values):
        res = super(HrEmployee, self).create(values)
        partner_id = self.env['res.partner'].create({'name' : res.name})
        res.emp_partner_id = partner_id.id
        return res
    
    @api.onchange('department_id')
    def _onchange_department_id(self):
        if self.department_id:
            self.job_position = self.department_id.job_id and self.department_id.job_id.id
            self.job_position.job_position_kpi_ids = [(4,x.id) for x in self.department_id.kpi_parameter_ids]

    @api.onchange('job_position')
    def _onchange_job_position(self):
        if self.job_position:
            self.practice_ids = self.job_position.job_position_kpi_ids
            self.job_detail = self.job_position.job_detail

    def first_approval(self):
        self.ensure_one()
        self.state = 'first_approval'

    def second_approval(self):
        self.ensure_one()
        self.state = 'second_approval'

    def button_cancelled(self):
        self.ensure_one()
        self.state = 'cancelled'

    def _casual_labour(self):
        for rec in self:
            labour_ids = self.env['casual.labour'].search([('employee_id', '=', rec.id)])
            rec.labour_count = len(labour_ids.ids)

    def open_casual_labour(self):
        casual_labour_ids = self.env['casual.labour'].search([('employee_id', '=', self.id)])
        return {
            'name': _('Casual Labour'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'casual.labour',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', casual_labour_ids.ids)],
        }

    def create_casual_labour(self):
        labour_id = self.env['casual.labour'].create({
            'start_date' : self.start_date,
            'end_date' : self.end_date,
            'location' : self.location,
            'description' : self.description,
            'employee_id' : self.id
        })
        return labour_id

class EducationCertification(models.Model):
    _name = "education.certification"
    
    name = fields.Char(string="Name")
    education_certification = fields.Binary('Certification', attachment=True)
    employee_id = fields.Many2one('hr.employee', string="Employee")
  

class PracticeEmployee(models.Model):
    _name = "practice.employee"
    
    name = fields.Char(string="Name")
    education_certification = fields.Binary('Certification', attachment=True)
    employee_id = fields.Many2one('hr.employee', string="Employee")

class PresonalDetails(models.Model):
    _name = "private.details"

    employee_id = fields.Many2one('hr.employee', string="Employee")
    name = fields.Char(string="Name")
    age = fields.Char(string="Age")
    percentage = fields.Float("Percentage")
    telephone = fields.Char(string="Telephone")




  


