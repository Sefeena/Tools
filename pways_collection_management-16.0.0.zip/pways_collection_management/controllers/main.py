# -*- coding: utf-8 -*-
from odoo import http, fields
from odoo.http import request
import json

from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
import ast
import logging
_logger = logging.getLogger(__name__)

from odoo import http
from odoo.addons.sale.controllers.portal import CustomerPortal
from odoo.http import request

class FarmerRegistrationWebhook(http.Controller):

    def get_state_id(self, data):
        state_id = request.env['res.country.state'].sudo().search([('name', '=', data)], limit=1)
        if not state_id:
            return False
        return state_id.id

    def get_country_id(self, data):
        country_id = request.env['res.country'].sudo().search([('name', '=', data)], limit=1)
        if not country_id:
            return False
        return country_id.id

    def find_partner(self,data):
        partner_id = request.env['res.partner'].sudo().search([('name', '=', data)], limit=1)
        if not partner_id:
            partner_id = request.env['res.partner'].sudo().create({'name' : data})
            return partner_id
        return partner_id

    def find_bank(self, data):
        bank_id = request.env['res.bank'].sudo().search([('name', '=', data.get("bic"))], limit=1)
        if not bank_id:
            bank_id = request.env['res.bank'].sudo().create({
                "name" : data.get("bank_name"),
                "street" : data.get("street"),
                "street2" : data.get("street2"),
                "zip" : data.get("zip"),
                # "state_id" : self.get_state_id(data.get("state_id"))  if data.get("state_id") else False,
                # "country_id" : self.get_country_id(data.get("country_id"))  if data.get("country_id") else False,
                "phone" : data.get("phone"),
                "email" : data.get("email"),
                "bic" : data.get("bic"),
            })
            return bank_id.id
        return bank_id.id

    def _prepare_bank_info(self, bank_info):
        line_ids = []
        for rec in bank_info:
            partner_id = self.find_partner(rec.get('partner_id'))
            line_ids.append((0, 0, {
                    "acc_number" : rec.get("acc_number"),
                    "partner_id" : partner_id.id if partner_id else False,
                    "acc_holder_name" : partner_id.name if partner_id else False,
                    "bank_id" : self.find_bank(rec) if rec.get('bank_name') else False,
                }))
        return line_ids


    def _prepare_farme_info(self, farm_info):
        line_ids = []
        for rec in farm_info:
            line_ids.append((0, 0, {
                    "plot_size" : rec.get('plot_size'),
                    "plot_number" : rec.get('plot_number'),
                    "area_under_tea" : rec.get('area_under_tea'),
                    "par_year_kg" : rec.get('par_year_kg'),
                    "ndarawetta_factory_acres" : rec.get('ndarawetta_factory_acres'),
                    # "parcel_number" : rec.get('parcel_number'),
                    "farmer_latitude" : rec.get('farmer_latitude'),
                    "farmer_longitude" : rec.get('farmer_longitude'),
                    "plot_forest_cover" : rec.get('plot_forest_cover'),
                    "extension_contact" : rec.get('extension_contact'),
                    "bank_ids" : self._prepare_bank_info(rec.get('bank_info')) if rec.get('bank_info') else [],
                    "remark" : rec.get('remark'),
                }))
        return line_ids

    def get_clerk_id(self, name):
        clerk_id = request.env['res.partner'].sudo().search([('name', '=', name)], limit=1)
        if not clerk_id:
            clerk_id = request.env['res.partner'].sudo().create({'name' : name, 'is_clerk' : True})
            return clerk_id.id
        return clerk_id.id

    def _prepare_child_ids_info(self, child_ids_info):
        line_ids = []
        for data in child_ids_info:
            line_ids.append((0, 0, {
                    "name" : data.get("name"),
                    "type" : data.get("type"),
                    "street" : data.get("street"),
                    "street2" : data.get("street2"),
                    "zip" : data.get("zip"),
                    "city" : data.get("city"),
                    "state_id" : self.get_state_id(data.get("state_id"))  if data.get("state_id") else False,
                    "country_id" : self.get_country_id(data.get("country_id"))  if data.get("country_id") else False,
                    "email" : data.get('email'),
                    "phone" : data.get("phone"),
                }))
        return line_ids

    def _prepare_farmer_registration(self, data):
        return {
            "name" : data.get("name"),
            "code" : data.get("code"),
            "national_id" : data.get("national_id"),
            "type" : data.get("type"),
            "street" : data.get("street"),
            "street2" : data.get("street2"),
            "zip" : data.get("zip"),
            "city" : data.get("city"),
            "state_id" : self.get_state_id(data.get("state_id"))  if data.get("state_id") else False,
            "country_id" : self.get_country_id(data.get("country_id"))  if data.get("country_id") else False,
            "email" : data.get('email'),
            "phone" : data.get("phone"),
            "mobile" : data.get("mobile"),
            "company_type" : data.get("company_type"),
            "contract_period" : data.get("contract_period"),
            "contract_status" : data.get("contract_status"),
            "contract_sign_date" : data.get("contract_sign_date"),
            "transport_rate" : data.get("transport_rate"),
            "gender" : data.get("gender"),
            "farmer_type" : data.get("farmer_type"),
            "devise_id" : data.get('id'),
            "clerk_id" : self.get_clerk_id(data.get('clerk_id')) if data.get('clerk_id') else False,
            }

    @http.route('/farmer/registration', type='json', auth='public', csrf=False)
    def fetch_user_data(self, **post):
        data = request.jsonrequest
        vals = self._prepar1e_farmer_registration(data)
        registration_id = request.env['farmer.registration'].sudo().create(vals)
        return {'status_message' : 200, "registration_id" : registration_id.id}

    @http.route('/farm/information', type='json', auth='public', csrf=False)
    def farm_information(self, **post):
        data = request.jsonrequest
        values = data.get('params')
        if values.get('registration_id'):
            farmer_registration_id = request.env['farmer.registration'].sudo().browse(values.get('registration_id'))
            if farmer_registration_id:
                farm_lines = self._prepare_farme_info(values.get('farm_info')) if values.get('farm_info') else False
                farmer_registration_id.sudo().write({'farm_info_ids' : farm_lines})
                return {'status_message' : 200,}
        return {'status_message' : 200, 'message' : "Farmer not register"}

    def get_total_weighment(self, farmer_id):
        today = date.today()
        start_date = today.replace(year=today.year, month=today.month, day=1).strftime("%Y-%m-%d")
        end_date = today.strftime("%Y-%m-%d")
        weighment_ids = request.env['grower.weighment'].sudo().search([('farmer_id', '=', farmer_id.id), ('weighment_date', '>=', start_date), ('weighment_date', '<=', end_date)])
        total_weighment = sum(weighment_ids.mapped('total_net'))
        return total_weighment

    def find_farmer(self, trip_id):
        farm_info = []
        trip_id =  [int(trip_id)]
        trip = request.env['trip.trip'].sudo().browse(trip_id)
        farm_info_ids = request.env['farm.info'].sudo().search([('location_id', 'in', trip.collection_ids.ids)])
        for farm in farm_info_ids.filtered(lambda x: x.farm_partner_id and x.location_id):
            total_weighment = self.get_total_weighment(farm.farm_partner_id)
            farm_info.append({
                    'farmer_id':farm.farm_partner_id.id,
                    'farm_id': farm.id,
                    'name' : farm.farm_partner_id.name,
                    'code':farm.farm_partner_id.code,
                    'national_id':farm.farm_partner_id.national_id,
                    'farm_code': farm.farm_code,
                    'email' : farm.farm_partner_id.email,
                    'collection_id' : farm.location_id.id,
                    'collection_center_name' : farm.location_id.name,
                    'monthly_cumulative_weighment' : total_weighment
                })
        return farm_info

    def get_domain(self, values):
        domain = [('state', '=', 'in_progress')]
        if values.get('trip_date'):
            domain += [('trip_date', '=', values.get('trip_date'))]
        if values.get('route_id'):
            domain += [('route_id', '=', int(values.get('route_id')))]
        if values.get('phone_imei'):
            domain += [('phone_imei', '=', values.get('phone_imei'))]
        return domain

    def find_trip(self, values):
        trip_info = []
        domain = self.get_domain(values)
        trip_ids = request.env['trip.trip'].sudo().search(domain)
        for trip in trip_ids:
            trip_info.append({
                'trip_id' : trip.id,
                'vehicle_id' : trip.vehicle_id.id,
                'route_id': trip.route_id.id,
                'vehicle_name' : trip.vehicle_id.license_plate,
                'clerk_id' : trip.clerk_id.id,
                'clerk_name' : trip.clerk_id.name,
                'collection_center' : [(collection.id, collection.name) for collection in trip.mapped('collection_ids')],
                'trip_no' : trip.name,
                'tare_value': trip.tare_value,
                'moisture_value': trip.moisture_value,
                'weighing_scale':trip.weighing_scale,
                'phone_imei':trip.phone_imei,
                'scale_unique_number': trip.scale_unique_number,
                'weighment_allow_kg': trip.weighment_allow_in_kg,
                'no_bags': trip.no_of_assignment,
                'mobile_user':trip.clerk_id.clark_mobile_user,
                'mobile_password':trip.clerk_id.clark_mobile_password,
                'extenstion_officer_id' : trip.extenstion_officer.id,
                'extenstion_officer_name' : trip.extenstion_officer.name,
		        'image':trip.image_128,
		        'Is_admin':"0",
                })
        return trip_info

    @http.route('/get_farmer/out_grower', type='json', auth='public', csrf=False)
    def get_farmer_out_grower(self, **post):
        data = request.jsonrequest
        farmer_data = self.find_farmer(data.get('trip_id'))
        return {'status_message' : 200, 'farmer_info' : farmer_data}

    # get Trip data
    @http.route('/get_trip_data', type='json', auth='public', csrf=False)
    def get_trip_data_out_grower(self, **post):
        data = request.jsonrequest
        trip_info = self.find_trip(data)
        return {'status_message' : 200, 'trip_info' : trip_info}

    def get_weighmrnt_domain(self, values):
        domain = []
        if values.get('farmer_id'):
            domain += [('farmer_id', '=', int(values.get('farmer_id')))]
        if values.get('trip_id'):
            domain += [('trip_id', '=', int(values.get('trip_id')))]
        return domain

    def _prepare_weighment_lines(self, weighment_lines, weighment_id=None, attachment=None):
        line_ids = []
        _logger.info(type(weighment_lines))
        if not isinstance(weighment_lines, list):
            weighment_lines = ast.literal_eval(weighment_lines)
        for rec in weighment_lines:
            lines = request.env['grower.weighment.line'].sudo().search([('transaction_no', '=', rec.get("transaction_no")), ('unq_no', '=', rec.get("Unq_no"))])
            found_attachment = request.env['ir.attachment'].sudo().search([('name', '=', rec.get("transaction_no"))])
            # if not found_attachment:
            #      request.env['ir.attachment'].sudo().create({
            #             'name': rec.get("transaction_no"),
            #             'type': 'binary',
            #             'datas': attachment,
            #             'res_model': 'grower.weighment',
            #             'res_id': weighment_id.id,
            #             'mimetype': 'application/x-pdf'
            #     })
            if not lines:
                line_ids.append((0, 0, {
                    "transaction_no": rec.get("transaction_no") or False,
                    "weight" : float(rec.get("gross_weight")),
                    "tare" : float(rec.get("tare_weight")),
                    "unq_no": rec.get("Unq_no") or False,
                    'location_id' : int(rec.get('collection_center_id')) or False,
                    "moisture" : float(rec.get("moisture_amt")),
                    "net" : float(rec.get("net_weight")),
                    'weighment_start_date':  rec.get('weighment_start_date') or False,
                    'weighment_end_date':  rec.get('weighment_end_date') or False,
                    'latitude' : rec.get('latitude') or False,
                    'logititude' : rec.get('logititude') or False,
                }))
        return line_ids

    def _prepare_weighment(self, values):
        return {
            'farmer_id' : int(values.get('farmer_id')) or False,
            'trip_id' : int(values.get('trip_id')) or False,
            'route_id' : int(values.get('route_id')) or False,
            'clerk_id' : int(values.get('clerk_id')) or False,
            'mobile_id' : values.get('mobile_id') or False,
            'device_id' : values.get('device_id') or False,
            'weighment_date': values.get('weighment_date') or False,
            'vehicle_id': int(values.get('vehicle_id')) or False
        }


    def find_out_grower_weighmrnt(self, values):
        domain = self.get_weighmrnt_domain(values)
        weighment_obj = request.env['grower.weighment']
        weighment_id = weighment_obj.sudo().search(domain)
        if not weighment_id:
            create_values = self._prepare_weighment(values)
            weighment_id = weighment_obj.sudo().create(create_values)
        binary_data = values.get('weighment_attachment', False)
        lines = self._prepare_weighment_lines(values.get('weighment_lines'), weighment_id=weighment_id, attachment=binary_data)
        weighment_id.write({'weighment_line_ids' : lines})
        return weighment_id

    @http.route('/out_grower_weighment_data', type='json', auth='public', csrf=False)
    def post_grower_weighment(self, **post):
        data = request.jsonrequest
        _logger.info("DATA", data)
        weighment_id = self.find_out_grower_weighmrnt(data)
        return {'status_message' : 200, 'weighment_id' :[ weighment_id.id]}

    @http.route('/get_farmer_information', type='json', auth='public', csrf=False)
    def get_farmer_information(self, **post):
        line_ids = []
        vals = {}
        data = request.jsonrequest
        partner_ids = request.env['res.partner'].sudo().search(['|', ('is_farmer', '=', True), ('supplier_rank', '>', 0)])
        for partner in partner_ids:
            farmer_id = request.env['farmer.registration'].sudo().search([('uuid_random', '=', partner.uuid_random)], limit=1)
            line_ids.append({
                'farmer_id' : farmer_id.id if farmer_id else False,
                'name': partner.name,
                'code': partner.uuid_random})
        return {'status_message' : 200, 'farmer_info' : line_ids}

    @http.route('/get_vechile_information', type='json', auth='public', csrf=False)
    def get_vechile_information(self, **post):
        line_ids = []
        data = request.jsonrequest
        vehicle_ids = request.env['fleet.vehicle'].sudo().search([])
        line_ids = [{
            'vehicle_id' : record.id,
            'vehicle_name': record.model_id.name if record.model_id else False,
            'vehicle_no': record.license_plate} for record in vehicle_ids]
        return {'status_message' : 200, 'vehicle_info' : line_ids}

    @http.route('/get_route_information', type='json', auth='public', csrf=False)
    def get_route_information(self, **post):
        line_ids = []
        data = request.jsonrequest
        route_ids = request.env['routes.routes'].sudo().search([])
        line_ids = [{'route_id' : record.id, 'route_name': record.name} for record in route_ids]
        return {'status_message' : 200, 'route_info' : line_ids}
    
    @http.route('/get_trip_information', type='json', auth='public', csrf=False)
    def get_trip_information(self, **post):
        line_ids = []
        data = request.jsonrequest
        trip_ids = request.env['trip.trip'].sudo().search([])
        line_ids = [{'trip_id' : record.id, 'trip_name': record.name, 'route_id' : record.route_id.id if record.route_id else False} for record in trip_ids]
        return {'status_message' : 200, 'trip_info' : line_ids}

    # @http.route('/create_record_of_query', type='json', auth='public', csrf=False)
    # def create_record_of_query(self, **post):
    #     quary_ids = []
    #     data = request.jsonrequest
    #     if data.get('data'):
    #         for line in data.get('data'):
    #             quary_id = request.env['outgrower.odoo.quary'].sudo().search([('weighment_no', '=', line.get('weighment_no'))])
    #             if not quary_id:
    #                 quary_id = request.env['outgrower.odoo.quary'].sudo().create(line)
    #                 quary_ids.append({line.get('weighment_no') : quary_id.id})
    #     return {'status_message' : 200, 'quary_ids' : quary_ids}
