# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
from datetime import timedelta
import datetime

class CasualLabour(models.Model):
    _name = 'casual.labour'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char("Casual Number",default="New")
    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    casual_start_date = fields.Date(string="Casual Start Date")
    casual_end_date = fields.Date(string="Casual End Date")
    attendances_ids = fields.One2many('hr.attendance', 'calsule_id', string="Attendances Lines")
    location = fields.Char(string="Location", copy=False)
    description = fields.Text(string="Description")
    employee_id = fields.Many2one('hr.employee', string="Employee")
    casual_type = fields.Selection([('manufacturer','Manufacturing'),('shorting','Sorting'),('packaging','Packaging'), ('other','Other')], string="Casual Type")
    no_of_casual = fields.Integer(string="No Of Casual Employee",)
    employee_ids = fields.Many2many('hr.employee', 'employee_template', string="Employee")
    production_id = fields.Many2one('mrp.production', string="Production")
    sorting_order_id = fields.Many2one('sorting.order', string="Shorting Order")
    packaging_order_id = fields.Many2one('packaging.order', string="Packaging Order")
    state = fields.Selection([('draft', 'Draft'), ('first_approval','First Approval'), ('second_approval','second_approval'), ('confirm', 'Confirm'), ('start','Start'),('stop','Stop')], default="draft", string="Casual Type")
    total_hours = fields.Float(string="Total Hours", compute='_compute_total_hours')
    payment_count = fields.Integer(compute='_payment_count', string='# Payment')

    def _compute_total_hours(self):
        for cl in self:
            cl.total_hours = sum(cl.attendances_ids.mapped('total_amount'))

    @api.model
    def create(self, vals):
        code = self.env['ir.sequence'].next_by_code('casual.labour')
        vals['name'] = code
        return super(CasualLabour, self).create(vals)

    @api.onchange('no_of_casual')
    def _no_of_casual_employee(self):
        for rec in self:
            calsule_empl = []
            if rec.no_of_casual:
                casual_employee_ids = self.env['hr.employee'].search([('employee_type', '=', 'casual')])
                labour_ids = self.env['casual.labour'].search([('state', '=', 'start')])
                for emp in casual_employee_ids:
                    if emp.id not in labour_ids.mapped('employee_ids').ids:
                        calsule_empl.append(emp.id)
                if len(calsule_empl) >= rec.no_of_casual:
                    rec.employee_ids = calsule_empl[0 : rec.no_of_casual]
                else:
                    rec.employee_ids = calsule_empl

    @api.constrains('employee_ids')
    def _check_constraint(self):
        for rec in self:
            casual_labour_ids = self.env['casual.labour'].search([('employee_ids', 'in', rec.employee_ids.ids), ('id', '!=', rec.id), ('state', '!=', 'stop')])
            for exsting_record in casual_labour_ids:
                if exsting_record.start_date <= rec.start_date and exsting_record.end_date >= rec.end_date:
                    raise ValidationError('Casual Alrady runing...')
                elif exsting_record.start_date >= rec.start_date:
                    raise ValidationError('Casual Alrady runing...')
                elif exsting_record.end_date >= rec.start_date:
                    raise ValidationError('Casual Alrady runing...')
                elif exsting_record.start_date >= rec.start_date and exsting_record.end_date >= rec.end_date:
                    raise ValidationError('Casual Alrady runing...')
                elif exsting_record.start_date >= rec.start_date and exsting_record.end_date <= rec.end_date:
                    raise ValidationError('Casual Alrady runing...')

    def first_approval(self):
        self.state = 'first_approval'

    def action_confirm(self):
        self.state = 'confirm'

    def second_approval(self):
        self.state = 'second_approval'

    def action_start(self):
        self.casual_start_date = fields.Date.today()
        self.state = 'start'

    def action_stop(self):
        end_date = fields.Date.today()
        self.casual_end_date = end_date
        attendance_ids = self.env['hr.attendance'].search([('check_in', '>=', fields.Datetime.to_string(self.casual_start_date)), ('check_out', '<=', fields.Datetime.to_string(self.casual_end_date)), ('employee_id', 'in', self.employee_ids.ids)])
        self.total_hours = sum(attendance_ids.mapped('worked_hours'))
        if attendance_ids:
            attendance_ids.write({'calsule_id' : self.id})
        self.state = 'stop'

    def _payment_count(self):
        for rec in self:
            payment_ids = self.env['account.payment'].search([('casual_id', '=', rec.id)])
            rec.payment_count = len(payment_ids.ids)

    def view_payment(self):
        payment_ids = self.env['account.payment'].search([('casual_id', '=', self.id)])
        return {
            'name': _('Payment'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.payment',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', payment_ids.ids)],
        }

class PackagingTemplate(models.Model):
    _inherit = 'packaging.order.template'

    costing_line_ids = fields.One2many('costing.line', 'packaging_template_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

class PackagingOrder(models.Model):
    _inherit = 'packaging.order'

    casual_labour_ids = fields.One2many('casual.labour', 'packaging_order_id', string="Casual Labour")
    costing_line_ids = fields.One2many('costing.line', 'packaging_order_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

    @api.onchange('template_id', 'product_uom_id', 'location_dest_id')
    def onchange_template_id(self):
        super(PackagingOrder, self).onchange_template_id()
        self.costing_line_ids = [(5, 0, 0)]
        if self.template_id and self.template_id.costing_line_ids:
            lines = [(0, 0, self._prepare_costing_lines(line)) for line in self.template_id.costing_line_ids]
            self.costing_line_ids = lines

    def _prepare_costing_lines(self, line):
        return {
            'costing_type_id': line.costing_type_id and line.costing_type_id.id or False,
            'product_id': line.product_id and line.product_id.id or False,
            'name': line.name or '',
            'quantity': line.quantity,
            'product_uom_id': line.product_uom_id.id,
            'unit_price': line.unit_price,
        }

    def _prepare_pkg_costing_lines(self, costing_line_ids, packaging_order_location_id):
        costing_line_vals = []
        for costing_line in costing_line_ids:
            costing_line_vals.append({
                'name': costing_line.product_id.name,
                'product_id': costing_line.product_id.id,
                'product_uom': costing_line.product_uom_id.id,
                'origin': self.name,
                'location_id': self.location_id.id,
                'location_dest_id': packaging_order_location_id.id,
                'procure_method': 'make_to_stock',
                'product_uom_qty': costing_line.quantity,
                'quantity_done': costing_line.quantity,
            })
        return costing_line_vals

    def action_done(self):
        res = super(PackagingOrder, self).action_done()
        costing_line_ids = self.costing_line_ids.filtered(lambda x: x.quantity > 0 and x.costing_type_id.is_material)
        warehouse_id = self.location_id.warehouse_id
        packaging_order_location_id = warehouse_id.packaging_order_location_id
        if not packaging_order_location_id:
            raise ValidationError(_('Please set packaging order location on warehouse'))
        if self.state == 'done' and costing_line_ids:
            costing_moves = self.env['stock.move']
            values = self._prepare_pkg_costing_lines(costing_line_ids, packaging_order_location_id)
            for val in values:
                stock_to_packing = self.env['stock.move'].create(val)
                costing_moves |= stock_to_packing._action_confirm()
            costing_moves._action_done()
        return res

class SortingOrder(models.Model):
    _inherit = 'sorting.order'

    casual_labour_ids = fields.One2many('casual.labour', 'sorting_order_id', string="Casual Labour")
    costing_line_ids = fields.One2many('costing.line', 'sorting_order_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

    def _prepare_srt_costing_lines(self, costing_line_ids):
        costing_line_vals = []
        for costing_line in costing_line_ids:
            costing_line_vals.append({
                'name': costing_line.product_id.name,
                'product_id': costing_line.product_id.id,
                'product_uom': costing_line.product_uom_id.id,
                'origin': self.name,
                'location_id': self.location_id.id,
                'location_dest_id': sorting_location_id.id,
                'procure_method': 'make_to_stock',
                'product_uom_qty': costing_line.quantity,
                'quantity_done': costing_line.quantity,
            })
        return costing_line_vals

    def action_done(self):
        res = super(SortingOrder, self).action_done()
        costing_line_ids = self.costing_line_ids.filtered(lambda x: x.quantity > 0 and x.costing_type_id.is_material)
        warehouse_id = self.location_id.warehouse_id
        sorting_location_id = warehouse_id.sorting_location_id
        if not sorting_location_id:
            raise ValidationError(_('Please set sorting location on warehouse'))
        if self.state == 'done' and costing_line_ids:
            costing_moves = self.env['stock.move']
            values = self._prepare_srt_costing_lines(costing_line_ids)
            for val in values:
                stock_to_sorting = self.env['stock.move'].create(val)
                costing_moves |= stock_to_sorting._action_confirm()
            costing_moves._action_done()
        return res

class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    product_id = fields.Many2one(
        'product.product', 'Product',
        domain="[('bom_ids', '!=', False), ('bom_ids.active', '=', True), ('bom_ids.type', '=', 'normal'), ('type', 'in', ['product', 'consu']), '|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        readonly=True, required=True, check_company=True,
        states={'draft': [('readonly', False)]})
    casual_labour_ids = fields.One2many('casual.labour', 'production_id', string="Casual Labour")
    costing_line_ids = fields.One2many('costing.line', 'production_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

    def _prepare_mrp_costing_lines(self, costing_line_ids):
        costing_line_vals = []
        for costing_line in costing_line_ids.filtered(lambda x: x.product_id.type != 'service'):
            costing_line_vals.append({
                'name': costing_line.product_id.name,
                'product_id': costing_line.product_id.id,
                'product_uom': costing_line.product_uom_id.id,
                'origin': self.name,
                'raw_material_production_id': self.id,
                'location_id': self.location_src_id.id,
                'location_dest_id': self.product_id.with_company(self.company_id).property_stock_production.id,
                'procure_method': 'make_to_stock',
                'product_uom_qty': costing_line.quantity,
                'quantity_done': costing_line.quantity,
            })
        return costing_line_vals

    def button_mark_done(self):
        res = super(MrpProduction, self).button_mark_done()
        warehouse_id = self.location_src_id.warehouse_id.id
        costing_line_ids = self.costing_line_ids.filtered(lambda x: x.quantity > 0 and x.costing_type_id.is_material)
        if self.state == 'done' and costing_line_ids:
            costing_moves = self.env['stock.move']
            values = self._prepare_mrp_costing_lines(costing_line_ids)
            for val in values:
                stock_to_sorting = self.env['stock.move'].create(val)
                costing_moves |= stock_to_sorting._action_confirm()
            costing_moves._action_done()
        return res

class CostingLine(models.Model):
    _name = "costing.line"
    _description = "Costing Line"

    @api.depends('unit_price', 'quantity')
    def _compute_amount(self):
        for line in self:
            line.price_subtotal = line.unit_price * line.quantity

    product_id = fields.Many2one('product.product', string="Product")
    name = fields.Char(string="Description")
    quantity = fields.Float('Quantity', default=1.0, digits='Product Unit of Measure')
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    product_uom_id = fields.Many2one('uom.uom', 'Unit of Measure', required=True, domain="[('category_id', '=', product_uom_category_id)]",)
    unit_price = fields.Float(string='Unit price')
    price_subtotal = fields.Float(string='Subtotal', compute="_compute_amount")
    production_id = fields.Many2one('mrp.production', string="Manufacturing Order")
    sorting_order_id = fields.Many2one('sorting.order', string="Shorting Order")
    packaging_order_id = fields.Many2one('packaging.order', string="Packaging Order")
    packaging_template_id = fields.Many2one('packaging.order.template', string='Template')
    operation_type = fields.Selection([
            ('material', 'Material'),
            ('manpower', 'Manpower'),
            ('other', 'Other'),
        ], string='Type')
    costing_type_id = fields.Many2one('costing.type', string="Type")

    @api.onchange("product_id")
    def _onchange_product(self):
        if self.product_id:
            self.name = self.product_id.name
            self.unit_price = self.product_id.standard_price
            self.product_uom_id = self.product_id.uom_id.id

class CostingType(models.Model):
    _name = 'costing.type'

    name = fields.Char('Type', required=True)
    is_material = fields.Boolean(string="Is Material")
    is_electric = fields.Boolean(string="Is Electric")


class HRAttendance(models.Model):
    _inherit = "hr.attendance"

    calsule_id = fields.Many2one('casual.labour', string="Casual")
    hourly_rate = fields.Float('Rate', related='employee_id.hourly_rate', store=True)
    total_amount = fields.Float(compute='_compute_total_amount', string='Total')

    @api.depends('worked_hours')
    def _compute_total_amount(self):
        for attendance in self:
            attendance.total_amount = round(attendance.worked_hours, 2) * attendance.hourly_rate

class AccountPayment(models.Model):
    _inherit = "account.payment"

    casual_id = fields.Many2one('casual.labour', "Casual")