# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api, fields, models

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    nssf = fields.Char(string="NSSF")
    nhif = fields.Char(string="NHIF")
    kra = fields.Char(string="KRA")

    bank_ids = fields.Many2many('res.partner.bank', 'partner_id', string='Banks', compute='_compute_bank_ids')
    property_account_payable_id = fields.Many2one('account.account', string="Account Payable")
    property_account_receivable_id = fields.Many2one('account.account', string="Account Receivable")

    def _compute_bank_ids(self):
        self.property_account_payable_id = self.emp_partner_id.property_account_payable_id
        self.property_account_receivable_id = self.emp_partner_id.property_account_receivable_id
        self.bank_ids |= self.emp_partner_id.bank_ids

class HrContractType(models.Model):
    _name = 'hr.contract.type'

    name = fields.Char('Contract Type', required=True, copy=False)

class ContractHR(models.Model):
    _inherit = "hr.contract"

    contract_type = fields.Many2one('hr.contract.type', string="Contract Type")