## Module <base_account_budget>

#### 07.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Budget Management

