Mass Clear Data
=====================================

Odoo Version : Odoo 16.0 Community


Installation
==================================================================
Install the Application -> Apps -> Mass Clear Data(cqt_clear_data)



