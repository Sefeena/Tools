# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class PackagingSequence(models.Model):
    _name= 'packaging.sequence'
    _rec_name = "sequence_id"
    _description = "Package Different Sequence Generate"

    name = fields.Char('Name', required=True, index=True, readonly=True, copy=False, default='New')
    packing_type = fields.Selection([('pos', 'POS'), ('auction', 'Auction'), ('export', 'Export'), ('local', 'Local'), ('other', 'Other')], string='Packing Type', default='local')
    sequence_id = fields.Many2one('ir.sequence')
