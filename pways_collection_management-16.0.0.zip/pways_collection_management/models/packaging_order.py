# -*- coding: utf-8 -*-
from odoo import fields, models, api, tools, _
from odoo.tools import float_compare
from odoo.exceptions import UserError, ValidationError


class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    is_sort = fields.Boolean('Sort Operation')
    draft_sort_count = fields.Integer(compute='_compute_picking_count')
    confirm_sort_count = fields.Integer(compute='_compute_picking_count')
    in_progress_count = fields.Integer(compute='_compute_picking_count')

    def _compute_picking_count(self):
        super(StockPickingType, self)._compute_picking_count()
        for rec in self:
            rec.in_progress_count = self.env['packaging.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'in_progress')])
            rec.draft_sort_count = self.env['packaging.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'draft')])
            rec.confirm_sort_count = self.env['packaging.order'].search_count([('picking_type_id', '=', rec.id), ('state', '=', 'confirm')])

    def get_action_sort_tree(self):
        return self._get_action('pways_collection_management.packaging_order_operation_template_action_id')

    def get_action_picking_tree_ready(self):
        if self.code == 'packaging_order':
            context = dict(self._context)
            return {
                'name': _('Packaging order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'in_progress')],
                'view_mode': 'tree,form',
                'res_model': 'packaging.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }
        return super(StockPickingType, self).get_action_picking_tree_ready()

    def action_open_draft_order(self):
        if self.code == 'packaging_order':
            context = dict(self._context)
            return {
                'name': _('Packaging order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'draft')],
                'view_mode': 'tree,form',
                'res_model': 'packaging.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }

    def action_open_confirm_order(self):
        if self.code == 'packaging_order':
            context = dict(self._context)
            return {
                'name': _('Packaging order'),
                'domain': [('picking_type_id', '=', self.id), ('state', '=', 'confirm')],
                'view_mode': 'tree,form',
                'res_model': 'packaging.order',
                'views': [[False, "tree"], [False, "form"]],
                'type': 'ir.actions.act_window',
                'context': context
            }

class PackagingOrder(models.Model):
    _name = 'packaging.order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Packaging Order'

    def _get_operation_type(self):
        return self.env['stock.picking.type'].search([('code', '=', 'packaging_order'), ('company_id', '=', self.env.company.id)], limit=1)

    name = fields.Char(required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))
    product_id = fields.Many2one('product.product', string="Product", required=True)
    template_id = fields.Many2one('packaging.order.template', string="Packaging Order Template")
    group_id = fields.Many2one('procurement.group', copy=False)
    product_qty = fields.Float(
        'Quantity',
        default=1.0, digits='Product Unit of Measure',
        readonly=True, required=True, tracking=True,
        states={'draft': [('readonly', False)]})
    product_uom_id = fields.Many2one(
        'uom.uom', 'Product Unit of Measure',
        domain="[('category_id', '=', product_uom_category_id)]",
        states={'draft': [('readonly', False)]},
        required=True)
    order_id = fields.Many2one('packaging.order', string="Packaging Order")
    schedule_date = fields.Datetime(string='Schedule Date', tracking=True)
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    picking_type_id = fields.Many2one(
        'stock.picking.type', 'Operation Type',
        default=_get_operation_type,
        domain="[('code', '=', 'packaging_order'), ('company_id', '=', company_id)]",
        check_company=True)
    process_qty = fields.Float(compute='_compute_process_qty', digits='Product Unit of Measure')
    location_id = fields.Many2one('stock.location', "Source Location", required=True)
    location_dest_id = fields.Many2one('stock.location', "Destination Location")
    company_id = fields.Many2one(
        'res.company', 'Company', default=lambda self: self.env.company,
        index=True, required=True)
    backorder_id = fields.Many2one(
        'packaging.order', 'Sort Back Order of',
        copy=False, index=True, readonly=True,
        check_company=True)
    #sorted_date = fields.Datetime(string='Packaging Order Date')
    packaging_order_date = fields.Datetime(string='Packaging Order Date')
    move_id = fields.Many2one('stock.move', copy=False)
    move_state = fields.Selection(related='move_id.state', store=True, readonly=True, string="Reservation Status")
    state = fields.Selection([
            ('draft', 'Draft'),
            ('confirm', 'Confirmed'),
            ('in_progress', 'Processing'),
            ('cancel', 'Cancelled'),
            ('done', 'Done')
        ], string='Status', copy=False, tracking=True,
        default='draft')
    order_line = fields.One2many('packaging.order.line', 'order_id', string="Operation lines")
    user_id = fields.Many2one('res.users', 'Responsible', default=lambda self: self.env.uid)
    pack_lot_ids = fields.One2many('pack.lot.line', 'order_id')
    # Technical field to generate same lot name for all the finished products
    lot_name = fields.Char('Lot Name for finished product', copy=False)
    packing_type = fields.Selection([('pos', 'POS'), ('auction', 'Auction'), ('export', 'Export'), ('local', 'Local'), ('other', 'Other')], string='Packing Type', default='local')
    available_lot_ids = fields.Many2many('stock.lot')
    assigned = fields.Boolean(copy=False)
    total_reserved_qty = fields.Float(string='Total Qty', compute="_compute_total_reserved_qty", digits='Product Unit of Measure')
    total_demand_qty = fields.Float(string='Total Qty', compute="_compute_total_demand_qty", digits='Product Unit of Measure')
    total_consumed_qty = fields.Float(string='Consumed Qty', compute="_compute_total_consumed_qty", digits='Product Unit of Measure')

    @api.depends('order_line.qty', 'order_line.product_uom_id')
    def _compute_total_demand_qty(self):
        for rec in self:
            total_qty = 0.0
            for line in rec.order_line:
                total_qty += line.demand_qty
            rec.total_demand_qty = total_qty

    def _compute_total_consumed_qty(self):
        for rec in self:
            total_qty = 0.0
            for line in rec.pack_lot_ids:
                total_qty += line.qty
            rec.total_consumed_qty = total_qty

    @api.depends('pack_lot_ids.lot_id', 'pack_lot_ids.qty')
    def _compute_total_reserved_qty(self):
        for rec in self:
            total_qty = 0.0
            for line in rec.pack_lot_ids:
                total_qty += line.qty
            rec.total_reserved_qty = total_qty

    def _prepare_stock_to_pack_vals(self, packaging_order_location_id):
        group = self.env['procurement.group'].create({
            'name': self.name,
        })
        return {
            'name': self.product_id.name,
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'origin': self.name,
            'group_id': group.id,
            'consume_packaging_order_id': self.id,
            'location_id': self.location_id.id,
            'location_dest_id': packaging_order_location_id.id,
            'procure_method': 'make_to_stock',
            'product_uom_qty': self.product_qty,
        }

    def action_assign_lots(self):
        if self.product_id and self.location_id:
            warehouse_id = self.location_id.warehouse_id
            packaging_order_location_id = warehouse_id.packaging_order_location_id
            if not packaging_order_location_id:
                raise ValidationError(_('Please set packaging order location on warehouse'))

            vals = self._prepare_stock_to_pack_vals(packaging_order_location_id)
            stock_to_pack = self.move_id
            if not self.move_id:
                stock_to_pack = self.env['stock.move'].create(vals)
                stock_to_pack._action_confirm()
            stock_to_pack._action_assign()
            pack_lines = []
            for sml in stock_to_pack.move_line_ids:
                pack_lines.append((0, 0, {
                    'qty': sml.product_uom_qty,
                    'order_id': self.id,
                    'product_id': self.product_id.id,
                    'lot_id': sml.lot_id.id,
                    'move_line_id': sml.id,
                }))
            if stock_to_pack.move_line_ids:
                self.write({'move_id': stock_to_pack.id, 'pack_lot_ids': pack_lines, 'assigned': True})

    @api.onchange('product_id', 'location_id')
    def _onchange_product(self):
        if self.product_id and self.location_id:
            quants = self.env['stock.quant'].search([('lot_id', '!=', False), ('location_id', '=', self.location_id.id), ('product_id', '=', self.product_id.id)])
            self.available_lot_ids = quants.filtered(lambda x: (x.quantity - x.reserved_quantity) > 0).mapped('lot_id').ids
        else:
            self.available_lot_ids = [(6, 0, [])]

    def _compute_process_qty(self):
        process_qty = 0.0
        for order in self:
            for line in order.order_line:
                process_qty += sum(line.finish_line_ids.mapped('qty'))
            order.process_qty = process_qty

    @api.onchange('picking_type_id')
    def _onchange_picking_type_id(self):
        self.location_id = self.picking_type_id.default_location_src_id and self.picking_type_id.default_location_src_id.id
        self.location_dest_id = self.picking_type_id.default_location_dest_id and self.picking_type_id.default_location_dest_id.id

    def action_draft(self):
        self.state = 'draft'
        return True

    def action_confirm(self):
        if self.product_qty != self.total_demand_qty:
            raise ValidationError(_('Packaging quantity must be equal to demand quantity.'))
        # move_id = self.env['stock.move']
        # warehouse_id = self.location_id.warehouse_id
        # packaging_order_location_id = warehouse_id.packaging_order_location_id
        # if not packaging_order_location_id:
        #     raise ValidationError(_('Please set packaging order location on warehouse'))
        # group = self.env['procurement.group'].create({
        #     'name': self.name,
        # })
        # move_lines = []
        # if not self.pack_lot_ids:
        #     raise ValidationError(_('Please add operation details.'))
        # if sum(self.pack_lot_ids.mapped('qty')) != self.product_qty:
        #     raise ValidationError(_('Please set lot with qty in operation details.'))
        # for line in self.pack_lot_ids:
        #     move_lines.append((0, 0, {
        #         'product_id': line.product_id.id,
        #         'lot_id': line.lot_id.id,
        #         'qty_done': line.qty,
        #         'product_uom_id': line.product_id.uom_id.id,
        #         'location_id': self.location_id.id,
        #         'location_dest_id': packaging_order_location_id.id,
        #     }))
        # stock_to_virtual = self.env['stock.move'].create({
        #     'name': self.product_id.name,
        #     'product_id': self.product_id.id,
        #     'product_uom': self.product_uom_id.id,
        #     'origin': self.name,
        #     'group_id': group.id,
        #     'location_id': self.location_id.id,
        #     'location_dest_id': packaging_order_location_id.id,
        #     'procure_method': 'make_to_stock',
        #     'product_uom_qty': self.product_qty,
        #     'move_line_ids': move_lines,
        # })
        # stock_to_virtual._action_confirm()
        # stock_to_virtual._action_assign()
        self.write({'state': 'confirm'})
        return True

    def action_processing(self):
        self.state = 'in_progress'
        return True

    def action_unassign(self):
        if self.product_id and self.location_id and self.move_id:
            self.move_id._do_unreserve()
            self.pack_lot_ids.unlink()
            self.order_line.mapped('finish_line_ids').unlink()
            self.assigned = False
        return True

    def action_done(self):
        today = fields.Date.today()
        for order in self:
            if order.process_qty != order.total_consumed_qty:
                raise ValidationError(_('Total Consumed Qty is not equal to Process Qty'))
            if order.process_qty > order.product_qty:
                raise ValidationError(_('You cannot process more than initial qunatity'))
            todo_qty = order.product_qty - order.process_qty
            if todo_qty > 0:
                new_wizard = self.env['pack.backorder.wizard'].create({})
                view_id = self.env.ref('pways_collection_management.view_packaging_order_backorder_form').id

                return {
                    'type': 'ir.actions.act_window',
                    'name': _('Create Backorder'),
                    'view_mode': 'form',
                    'res_model': 'pack.backorder.wizard',
                    'target': 'new',
                    'res_id': new_wizard.id,
                    'views': [[view_id, 'form']],
                }
            else:
                stock_move = self.env['stock.move']
                for line in order.order_line.filtered(lambda x: x.qty > 0):
                    move_id = self.env['stock.move'].create(line.prepare_moves())
                    cost_price = order.total_amount / line.qty
                    # Need to clear cost_price
                    move_id.write({'price_unit': cost_price})
                    stock_move = move_id._action_confirm()
                    stock_move._action_done()
                    line.write({'move_id': stock_move})
                order.move_id.write({'quantity_done': self.product_qty})
                for line in order.move_id.move_line_ids:
                    line.write({'qty_done': line.product_uom_qty})
                order.move_id._action_done()
            order.packaging_order_date = today
        # NEED TO SET Packaging DATE
        self.state = 'done'

    def action_cancel(self):
        self.order_line.move_id._action_cancel()
        self.pack_lot_ids.unlink()
        self.state = 'cancel'
        return True

    def _prepare_template_lines(self, line):
        return {
            'product_id': line.product_id and line.product_id.id or False,
            'qty': line.product_qty,
            'product_uom_id': line.product_id.uom_id.id,
            'location_dest_id': self.location_dest_id and self.location_dest_id.id,
        }

    @api.onchange('product_id')
    def onchange_product_id(self):
        for order in self:
            order.product_uom_id = order.product_id.uom_id and order.product_id.uom_id.id
        if self.product_id:
            self.template_id = False
            template_ids = self.env['packaging.order.template'].search([('product_id', '=', self.product_id.id)])
            return {'domain': {'template_id': [('id', 'in', template_ids.ids)]}}

    @api.onchange('template_id', 'product_uom_id', 'location_dest_id')
    def onchange_template_id(self):
        self.order_line = [(5, 0, 0)]
        if self.template_id and self.template_id.packaging_order_line:
            lines = [(0, 0, self._prepare_template_lines(line)) for line in self.template_id.packaging_order_line]
            self.order_line = lines
            self.location_id = self.template_id.location_id.id
            self.location_dest_id = self.template_id.location_dest_id.id
            self.packing_type = self.template_id.packing_type
            self.product_qty = self.total_demand_qty

    def _get_sequence_name(self, vals):
        pack_id  = self.env['packaging.sequence'].search([('packing_type', '=',vals['packing_type'])])
        name = self.env['ir.sequence'].next_by_code(pack_id.sequence_id.code) or 'New'
        return name

    @api.model
    def create(self, vals):
        vals['name'] = self._get_sequence_name(vals)
        return super(PackagingOrder, self).create(vals)

    def unlink(self):
        if any(order.state not in ('draft', 'cancel') for order in self):
            raise UserError(_('You can delete draft/cancel orders only.'))
        return super(PackagingOrder, self).unlink()

class PackagingOrder(models.Model):
    _inherit = 'packaging.order'

    casual_labour_ids = fields.One2many('casual.labour', 'packaging_order_id', string="Casual Labour")
    costing_line_ids = fields.One2many('costing.line', 'packaging_order_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

    @api.onchange('template_id', 'product_uom_id', 'location_dest_id')
    def onchange_template_id(self):
        super(PackagingOrder, self).onchange_template_id()
        self.costing_line_ids = [(5, 0, 0)]
        if self.template_id and self.template_id.costing_line_ids:
            lines = [(0, 0, self._prepare_costing_lines(line)) for line in self.template_id.costing_line_ids]
            self.costing_line_ids = lines

    def _prepare_costing_lines(self, line):
        return {
            'costing_type_id': line.costing_type_id and line.costing_type_id.id or False,
            'product_id': line.product_id and line.product_id.id or False,
            'name': line.name or '',
            'quantity': line.quantity,
            'product_uom_id': line.product_uom_id.id,
            'unit_price': line.unit_price,
        }

    def _prepare_pkg_costing_lines(self, costing_line_ids, packaging_order_location_id):
        costing_line_vals = []
        for costing_line in costing_line_ids:
            costing_line_vals.append({
                'name': costing_line.product_id.name,
                'product_id': costing_line.product_id.id,
                'product_uom': costing_line.product_uom_id.id,
                'origin': self.name,
                'location_id': self.location_id.id,
                'location_dest_id': packaging_order_location_id.id,
                'procure_method': 'make_to_stock',
                'product_uom_qty': costing_line.quantity,
                'quantity_done': costing_line.quantity,
            })
        return costing_line_vals

    def action_done(self):
        res = super(PackagingOrder, self).action_done()
        costing_line_ids = self.costing_line_ids.filtered(lambda x: x.quantity > 0 and x.costing_type_id.is_material)
        warehouse_id = self.location_id.warehouse_id
        packaging_order_location_id = warehouse_id.packaging_order_location_id
        if not packaging_order_location_id:
            raise ValidationError(_('Please set packaging order location on warehouse'))
        if self.state == 'done' and costing_line_ids:
            costing_moves = self.env['stock.move']
            values = self._prepare_pkg_costing_lines(costing_line_ids, packaging_order_location_id)
            for val in values:
                stock_to_packing = self.env['stock.move'].create(val)
                costing_moves |= stock_to_packing._action_confirm()
            costing_moves._action_done()
        return res


class PackagingOrderLine(models.Model):
    _name = 'packaging.order.line'
    _description = 'Packaging Order lines'

    product_id = fields.Many2one('product.product', string="Product")
    qty = fields.Float('Quantity', default=0.0, digits='Product Unit of Measure')
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    product_uom_id = fields.Many2one('uom.uom', 'Unit of Measure', required=True, domain="[('category_id', '=', product_uom_category_id)]",)
    order_id = fields.Many2one('packaging.order', string="Packaging Order")
    location_dest_id = fields.Many2one('stock.location', "Destination Location")
    move_id = fields.Many2one('stock.move', copy=False)
    finish_line_ids = fields.One2many('finish.pack.lot.line', 'line_id')
    state = fields.Selection([
            ('draft', 'Draft'),
            ('confirm', 'Confirmed'),
            ('in_progress', 'Processing'),
            ('cancel', 'Cancelled'),
            ('done', 'Done')
        ], string='Status', copy=False, tracking=True,
        default='draft', related='order_id.state')
    lot_id = fields.Many2one(
        'stock.lot', 'Lot/Serial Number',
        domain="[('product_id', '=', product_id), ('company_id', '=', move_id.company_id), ('id', 'in', order_id.available_lot_ids)]", check_company=True,
        help="Lot/Serial Number of the product to unbuild.")
    finish_qty = fields.Float('Quantity', compute="_compute_finish_qty", digits='Product Unit of Measure')
    demand_qty = fields.Float('Demand', compute="_compute_finish_qty", digits='Product Unit of Measure')
    remaining_qty  = fields.Float('Remaining', compute="_compute_finish_qty", digits='Product Unit of Measure')

    @api.depends('finish_line_ids.qty')
    def _compute_finish_qty(self):
        for line in self:
            total_qty = sum(line.finish_line_ids.mapped('qty'))
            line.finish_qty = line.order_id.product_uom_id._compute_quantity(total_qty, line.product_uom_id)
            line.demand_qty = line.product_uom_id._compute_quantity(line.qty, line.order_id.product_uom_id)
            line.remaining_qty = line.demand_qty - sum(line.finish_line_ids.mapped('qty'))

    def _prepare_moves_lines(self):
        warehouse_id = self.location_dest_id.warehouse_id
        sorting_location_id = warehouse_id.sorting_location_id
        lot_name =  self.order_id.lot_name or self.env['ir.sequence'].next_by_code('finish.pack.lot')  +'('+ self.order_id.packing_type+')'
        lot_id = self.env['stock.lot'].create({
            'product_id': self.product_id.id,
            'name': lot_name,
            'company_id': self.order_id.company_id.id,
            'packaging_ref': self.order_id.name,
        })
        if not self.order_id.lot_name:
            self.order_id.lot_name = lot_id.name
        self.lot_id = lot_id.id
        consumed_lines = self.order_id.move_id.move_line_ids.filtered(lambda x: x.lot_id.id in self.finish_line_ids.mapped('lot_id').ids)
        return [(0,0,{
                'lot_id': lot_id.id,
                'qty_done':  self.qty,
                'product_id': self.product_id.id,
                'product_uom_id': self.product_uom_id.id,
                'location_id': sorting_location_id.id,
                'location_dest_id': self.location_dest_id.id or self.order_id.location_dest_id.id,
                'consume_line_ids': [(6, 0, consumed_lines.ids)],
            })]

    def prepare_moves(self):
        warehouse_id = self.location_dest_id.warehouse_id
        packaging_order_location_id = warehouse_id.packaging_order_location_id
        values = {
            'name': self.product_id.name,
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'origin': self.order_id.name,
            'group_id': self.order_id.group_id.id,
            'location_id': packaging_order_location_id.id,
            'produce_packaging_order_id': self.order_id.id,
            'location_dest_id': self.location_dest_id.id or self.order_id.location_dest_id.id,
            'procure_method': 'make_to_stock',
            'product_uom_qty': self.qty,
            'quantity_done': self.qty,
        }
        if self.product_id.tracking == 'lot':
            move_line_ids = self._prepare_moves_lines()
            values.update({'move_line_ids' : move_line_ids})
        return values

    def action_show_details(self):
        self.ensure_one()
        view = self.env.ref('pways_collection_management.finish_pack_lot_line_form_view')
        lot_lines = []
        for line in self.order_id.pack_lot_ids:
            lot_lines.append((0, 0, {'lot_id': line.lot_id.id}))
        if not self.finish_line_ids:
            self.write({'finish_line_ids': lot_lines})
        return {
            'name': _('Detailed Operations'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'packaging.order.line',
            'views': [(view.id, 'form')],
            'view_id': view.id,
            'target': 'new',
            'res_id': self.id,
            'context': {
                'default_finish_line_ids': lot_lines,
            },
        }

    def action_create_lot_line(self):
        total_qty = sum(self.finish_line_ids.mapped('qty'))
        if self.demand_qty < total_qty:
            raise ValidationError(_('You cannot produce more than initial qunatity.'))
        return True

class PackLotLine(models.Model):
    _name = 'pack.lot.line'
    _description = 'Packaging Lot Line'

    qty = fields.Float('Quantity', digits='Product Unit of Measure')
    order_id = fields.Many2one('packaging.order')
    product_id = fields.Many2one('product.product', related='order_id.product_id')
    move_line_id = fields.Many2one('stock.move.line', copy=False)
    company_id = fields.Many2one(
        'res.company', 'Company', default=lambda self: self.env.company,
        index=True, required=True)
    lot_id = fields.Many2one(
        'stock.lot', 'Lot/Serial Number',
        domain="[('product_id', '=', product_id), ('company_id', '=', company_id)]", check_company=True,
        help="Lot/Serial Number of the product to unbuild.")
    onhand_qty = fields.Float(string="Available Qty", compute='_compute_onhand_qty')

    @api.depends('lot_id', 'qty')
    def _compute_onhand_qty(self):
        for line in self:
            if line.lot_id:
                quants = self.env['stock.quant'].search([('location_id', '=', line.order_id.location_id.id), ('product_id', '=', line.product_id.id), ('lot_id', '=', line.lot_id.id)])
                line.onhand_qty = sum(quants.mapped('quantity')) - sum(quants.mapped('reserved_quantity'))
            else:
                line.onhand_qty = 0.0

    def unlink(self):
        move_line_ids = self.mapped('move_line_id')
        res = super(PackLotLine, self).unlink()
        move_line_ids.unlink()
        return res

    @api.model
    def create(self, vals):
        res = super(PackLotLine, self).create(vals)
        if not res.move_line_id:
            move_line = self.env['stock.move.line'].create({
                'product_id': res.product_id.id,
                'lot_id': res.lot_id.id,
                'qty_done': res.qty,
                # 'product_uom_qty': res.qty,
                'move_id': res.order_id.move_id.id,
                'product_uom_id': res.order_id.move_id.product_id.uom_id.id,
                'location_id': res.order_id.move_id.location_id.id,
                'location_dest_id': res.order_id.move_id.location_dest_id.id,
            })
            res.write({'move_line_id': move_line.id})
            move_line.write({'product_uom_qty': res.qty})
        return res

    def write(self, vals):
        if self.move_line_id:
            qty = vals.get('qty')
            self.move_line_id.write({'product_uom_qty': qty, 'qty_done': qty})
        return super(PackLotLine, self).write(vals)


class FinishPackLotLine(models.Model):
    _name = 'finish.pack.lot.line'
    _description = 'Packaging Lot Line'

    qty = fields.Float('Quantity', digits='Product Unit of Measure')
    line_id = fields.Many2one('packaging.order.line')
    order_id = fields.Many2one('packaging.order', related="line_id.order_id")
    product_id = fields.Many2one('product.product', related='line_id.product_id')
    lot_ids = fields.Many2many('stock.lot', compute='_compute_lot_ids')
    company_id = fields.Many2one(
        'res.company', 'Company', default=lambda self: self.env.company,
        index=True, required=True)
    lot_id = fields.Many2one(
        'stock.lot', 'Lot/Serial Number',
        help="Lot/Serial Number of the product to unbuild.")
    product_uom_id = fields.Many2one('uom.uom', string='UoM', related='order_id.product_uom_id')
    available_qty = fields.Float(compute='_compute_available_qty', digits='Product Unit of Measure')

    @api.onchange('qty')
    def onchange_qty(self):
        if self.available_qty < self.qty:
            raise ValidationError(_('You cannot set more than reserved quantity'))

    @api.depends('lot_id', 'qty')
    def _compute_available_qty(self):
        for line in self:
            available_qty = sum(line.order_id.pack_lot_ids.filtered(lambda x: x.lot_id.id == line.lot_id.id).mapped('qty'))
            reserved_quantity = sum(line.order_id.order_line.finish_line_ids.filtered(lambda x: x.lot_id.id == line.lot_id.id).mapped('qty'))
            line.available_qty = available_qty - reserved_quantity

    def _compute_lot_ids(self):
        for line in self:
            line.lot_ids = line.order_id.pack_lot_ids.mapped('lot_id').ids

    @api.model
    def default_get(self, fields_list):
        rslt = super(FinishPackLotLine, self).default_get(fields_list)
        pack_line = self.env['packaging.order.line'].browse(self.env.context.get('active_id'))
        rslt['lot_ids'] = pack_line.order_id.pack_lot_ids.mapped('lot_id').ids
        return rslt
