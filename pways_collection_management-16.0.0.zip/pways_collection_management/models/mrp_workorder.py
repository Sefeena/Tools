# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class MrpWorkorder(models.Model):
    _inherit = "mrp.workorder"

    pause_reason_ids = fields.One2many('mrp.pause.reason', 'workorder_id')

    def button_pending(self):
        view_id = self.env.ref('pways_collection_management.mrp_pause_wizard_form_view').id
        return {
            'type': 'ir.actions.act_window',
            'name': _('Pause Reason'),
            'res_model': 'mrp.pause.wizard',
            'target': 'new',
            'view_mode': 'form',
            'context': {'default_workorder_id': self.id},
            'views': [[view_id, 'form']],
        }


class MrpWorkcenter(models.Model):
    _inherit = "mrp.workcenter"

    has_roller = fields.Boolean(string="Has Roller")
    processed_qty = fields.Float('Processed Qty')
