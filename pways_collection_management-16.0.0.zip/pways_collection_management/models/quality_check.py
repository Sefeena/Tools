from odoo import api,fields,models,_

class QualityTeaDryLeaf(models.Model):
    _name = "quality.tea.dry.leaf"
    _rec_name = 'code'
    
    desc = fields.Text('Description')
    code = fields.Char('Code')

class QualityTeaInfusionCut(models.Model):
    _name = "quality.tea.infusion.cut"
    _rec_name = 'code'
    
    desc = fields.Text('Description')
    code = fields.Char('Code')

class QualityTeaLiqour(models.Model):
    _name = "quality.tea.liquor"
    _rec_name = 'code'
    
    desc = fields.Text('Description')
    code = fields.Char('Code')

class Grade(models.Model):
    _name = 'grade.grade'

    name = fields.Char('Grade')
    product_id = fields.Many2one('product.product','Product')
    grade_id = fields.Many2one('quality.tea.check')

class Density(models.Model):
    _name = 'density.density'

    name = fields.Char('Density')
    product_id = fields.Many2one('product.product','Product')
    density_id = fields.Many2one('quality.tea.check')

class Dryer(models.Model):
    _name = 'dryer.dryer'

    name = fields.Char('Dryer')
    temp = fields.Selection([('t1','T1'),('t2','T2'),('t3','T3'),('t4','T4')],string="Temp")
    dryer_id = fields.Many2one('quality.tea.check')

class Mc(models.Model):
    _name = 'mc.mc'

    name = fields.Char('Moisture Content')
    mc_type = fields.Selection([('wl','WL'),('dm','DM'),('excfu','EXCFU')],string="Moisture")
    mc_id = fields.Many2one('quality.tea.check')

class QualityTeaCheck(models.Model):
    _name = "quality.tea.check"
    _desc = 'Tea Check'
    # _rec_name = 'quality_check_id'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']

    # quality_check_id = fields.Many2one('quality.tea.check.master','Quality Check')
    name = fields.Char('Name', default="New")
    sorting_order_id = fields.Many2one('sorting.order','Sorting Order')
    workcenter_id = fields.Many2one('mrp.workcenter','Work Center')
    moisture_content = fields.Char('Moisture Content', track_visibility='onchange')
    collected_by_whom = fields.Many2one('res.partner', 'Collected By Whom', track_visibility='onchange')
    given_by_whom = fields.Many2one('res.partner', 'Given By Whom', track_visibility='onchange')
    collection_date = fields.Datetime('Collection Date')
    # remark = fields.Text('Remark', track_visibility='onchange')
    temperature = fields.Char('Temp', track_visibility='onchange')
    type_tea = fields.Selection([('ortho','Orthodox'),('ctc','CTC')],string="Type Tea")
    state = fields.Selection([('draft','Draft'),('done','Done'),('cancel','Cancel')],string='State', default='draft')
    product_id = fields.Many2one('product.product','Product', track_visibility='onchange')
    tested_by_whom = fields.Many2one('res.partner', 'Tested By Whom',track_visibility='onchange')
    grade_ids = fields.One2many('grade.grade','grade_id')
    density_ids = fields.One2many('density.density','density_id')
    dryer_ids = fields.One2many('dryer.dryer','dryer_id')
    mc_ids = fields.One2many('mc.mc','mc_id')
    dry_leaf_id = fields.Many2one('quality.tea.dry.leaf','Dry Leaf Remark')
    infusion_id = fields.Many2one('quality.tea.infusion.cut','Infusion Cut Remark')
    liquour_id = fields.Many2one('quality.tea.liquor','Liquour Remark')
    dry_remark = fields.Text('Dry Leaf Remark')
    infusion_remark = fields.Text('Infusion Remark')
    liquour_remark = fields.Text('Liquour Remark')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('quality.tea.check') or '/'
        return super(QualityTeaCheck, self).create(vals)

    @api.onchange('dry_leaf_id')
    def onchange_dryleaf(self):
        if self.dry_leaf_id:
            self.dry_remark = self.dry_leaf_id.desc

    @api.onchange('infusion_id')
    def onchange_infusion(self):
        if self.infusion_id:
            self.dry_remark = self.infusion_id.desc

    @api.onchange('liquour_id')
    def onchange_liquour(self):
        if self.liquour_id:
            self.dry_remark = self.liquour_id.desc

    def action_cancel(self):
        self.write({'state' : 'cancel'})

    def action_done(self):
        self.write({'state' : 'done'})
        return True

class SortingOrder(models.Model):
    _inherit = "sorting.order"

    def open_quality_tea_check(self):
        ctx = {
         'default_sorting_order_id': self.id,
        }
        return {
            'name': _('Quality Tea Check'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'quality.tea.check',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('sorting_order_id', '=', self.id)],
            'context': ctx,
        }
