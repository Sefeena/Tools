# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class StockProductionLot(models.Model):
    _inherit = 'stock.lot'

    manufacturing_date = fields.Datetime(string='Manufacturing Date', copy=False)
    production_id = fields.Many2one('mrp.production', string="Manufacturing Order", copy=False)

class MrpProduction(models.Model):
    _inherit = "mrp.production"

    out_turn = fields.Float(string='Out Turn(%)', digits='Product Unit of Measure', compute='_compute_out_turn')

    def _compute_out_turn(self):
        for production in self:
            total_leaf = sum(production.move_raw_ids.filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity_done'))
            if total_leaf:
               total_leaf = (production.product_qty / total_leaf) * 100
            production.out_turn = total_leaf

    def button_mark_done(self):
        res = super(MrpProduction, self).button_mark_done()
        # gl_comsumed = sum(self.move_raw_ids.filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity_done'))
        # workcenter_ids = self.workorder_ids.filtered(lambda x: x.workcenter_id.has_roller).mapped('workcenter_id')
        # if workcenter_ids:
        #     processed_qty = gl_comsumed/len(workcenter_ids)
        #     for workcenter in workcenter_ids:
        #         equipment_ids = self.env['maintenance.equipment'].search([('workcenter_id', '=', workcenter.id)])
        #         equipment_ids.write({'processed_qty': processed_qty})
        if self.lot_producing_id and self.date_planned_start:
            self.lot_producing_id.write({'production_id': self.id, 'manufacturing_date': self.date_planned_start})
        return res
