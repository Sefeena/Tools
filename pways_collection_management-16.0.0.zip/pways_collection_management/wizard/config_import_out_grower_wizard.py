# -*- coding: utf-8 -*-
from odoo import models, api, fields, _
import io
import tempfile
import xlrd
import logging
import binascii
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

try:
    import xlwt
except ImportError:
    _logger.debug('Cannot `import xlwt`.')
try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')
try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')

class ImportOutGrower(models.TransientModel):
    _name = 'import.outgrower.data'

    type = fields.Selection([('farmer', 'Out Grower'), ('farm', 'Property')], string="Select Import Type", default="farmer")
    excel_file = fields.Binary('Select File')

    def find_state_id(self, state):
        if state:
            state_id = self.env['res.country.state'].sudo().search([('name', 'ilike', state)], limit=1)
            return state_id.id
        return False

    def find_country_id(self, country):
        if country:
            country_id = self.env['res.country'].sudo().search([('name', 'ilike', country)], limit=1)
            return country_id.id
        return False

    def _prepaire_farmers_vals(self, line):
        type = 'person' if line[1] == 'Individual' else 'company'
        gender = 'male' if line[2] == 'MALE' else 'female'
        code = ''
        national_id = ''
        mobile = ''
        if str(line[13]):
            code = str(line[13]).split('.0')[0]
        if str(line[12]):
            national_id  = str(line[12]).split('.0')[0]
        if str(line[9]):
            mobile  = str(line[9]).split('.0')[0]
        return {
            'contact_name' : line[0],
            'farmer_type' : 'out_grower',
            'company_type' : type,
            'gender' : gender,
            'street' : line[3],
            'city' : line[4],
            'state_id' : self.find_state_id(line[5]),
            'country_id' : self.find_country_id(line[6]),
            'zip' : line[7],
            'phone' : line[8],
            'mobile' : mobile,
            'email' : line[10],
            'bank_ac_no' : line[11],
            'national_id' : national_id,
            'code' : code,
        }

    def import_farmer(self, line):
        farmers_vals = self._prepaire_farmers_vals(line)
        farmer_id = self.env['farmer.registration'].sudo().create(farmers_vals)
        return True

    def find_farmer_regist_id(self, regist_id):
        if regist_id:
            registration_id = self.env['farmer.registration'].sudo().search([('contact_name', '=', regist_id)], limit=1)
            return registration_id.id if registration_id else False
        return False

    def find_route_id(self, route_id):
        if route_id:
            route_id = self.env['routes.routes'].sudo().search([('name', 'ilike', route_id)], limit=1)
            return route_id.id
        return False

    def find_collection_id(self, location_id):
        if location_id:
            location_id = self.env['stock.location'].sudo().search([('name', 'ilike', location_id)], limit=1)
            return location_id.id if location_id else False
        return False

    def find_bank_id(self, bank_name):
        if bank_name:
            bank_id = self.env['res.bank'].sudo().search([('name', 'ilike', bank_name)], limit=1)
            if not bank_id:
                bank_id = self.env['res.bank'].sudo().create({'name' : bank_name})
            return bank_id.id
        return False

    def _prepaire_farm_vals(self, line):
        farm_code = ''
        if str(line[0]):
            farm_code = str(line[0]).split('.0')[0]
        return {
            'farm_code' : farm_code,
            'plot_size' : line[1],
            'plot_number' : line[2],
            'area_under_tea' : line[3],
            'par_year_kg' : line[4],
            'ndarawetta_factory_acres' : line[5],
            'farmer_regist_id' : self.find_farmer_regist_id(line[6]),
            'route_id' : self.find_route_id(line[7]),
            'location_id' : self.find_collection_id(line[8]),
            # 'parcel_number' : line[9],
            # 'farmer_latitude' : line[10],
            # 'farmer_longitude' : line[11],
            'plot_forest_cover' : line[12],
            'extension_contact' : False,
        }

    def _prepaire_bank_details(self, line):
        return [(0, 0,{
                'acc_holder_number' : line[14],
                'acc_holder_name' : line[15],
                'bank_id' : self.find_bank_id(line[16]),
                'branch_id' : line[17]
            })]

    def import_farm(self, line):
        farm_vals = self._prepaire_farm_vals(line)
        farm_id = self.env['farm.info'].sudo().create(farm_vals)
        bank_details_line = self._prepaire_bank_details(line)
        farm_id.write({'farem_bank_ids' : bank_details_line})
        return True


    def import_outgrower_data(self):
        if not self.excel_file:
            raise Warning(_('Please Select a xlsx file.'))
        try:
            fp = tempfile.NamedTemporaryFile(delete= False,suffix=".xlsx")
            fp.write(binascii.a2b_base64(self.excel_file))
            fp.seek(0)
            values = {}
            workbook = xlrd.open_workbook(fp.name)
            sheet = workbook.sheet_by_index(0)
            for row_no in range(sheet.nrows):
                val = {}
                if row_no <= 0:
                    fields = map(lambda row:row.value.encode('utf-8'), sheet.row(row_no))
                else:
                    line = list(map(lambda row:isinstance(row.value, bytes) and row.value.encode('utf-8') or str(row.value), sheet.row(row_no)))
                    if self.type == 'farmer':
                        self.import_farmer(line)
                    if self.type == 'farm':
                        self.import_farm(line)
        except Exception as e:
            raise ValidationError('Error select xlsx file "%s"' % (e,))
