# -*- coding: utf-8 -*-

from odoo import fields, models, _

class TripReason(models.Model):
    _name = "trip.cancel.reason"
    _description = 'Trip Cancel Reason'

    name = fields.Char('Description', required=True, translate=True)