# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    external_repair_id = fields.Many2one('external.repair', copy=False)

    def _action_done(self):
        res = super(StockPicking, self)._action_done()
        for picking in self.filtered(lambda x: x.external_repair_id and x.picking_type_id.code == 'incoming'):
            picking.external_repair_id.write({'state': 'return'})
        return res

class ExternalRepair(models.Model):
    _name = 'external.repair'
    _description = 'External Repair'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']

    name = fields.Char(required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))
    state = fields.Selection([('draft', 'Draft'), ('dispatch', 'Dispatch'), ('return', 'Return'), ('done', 'Done'), ('cancel', 'Cancelled')], default='draft', string='Status', required=True, readonly=True, copy=False, tracking=True)
    dispatch_count = fields.Integer(string='Dispatch', compute='_compute_dispatch_count')
    return_count = fields.Integer(string='Return', compute='_compute_return_count')
    repair_id = fields.Many2one('repair.order', string="Repair Order")
    date = fields.Date('Date', required=True, default=fields.Date.today())
    partner_id = fields.Many2one('res.partner', string='Vendor')
    product_id = fields.Many2one('product.product', string='Product to Repair', required=True, domain="[('type', '!=', 'service')]")
    qty = fields.Float('Qty')
    price = fields.Float('Repair Price')
    dispatch_date = fields.Date('Dispatch Date', readonly=True)
    return_date = fields.Date('Return Date', required=True)
    remarks = fields.Char('Remarks')
    description = fields.Text()

    def _compute_dispatch_count(self):
        for order in self:
            order.dispatch_count = self.env['stock.picking'].search_count([('external_repair_id', '=', order.id), ('picking_type_id.code', '=', 'outgoing')])

    def _compute_return_count(self):
        for order in self:
            order.return_count = self.env['stock.picking'].search_count([('external_repair_id', '=', order.id), ('picking_type_id.code', '=', 'incoming')])

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('external.repair') or '/'
        return super(ExternalRepair, self).create(vals)

    def action_dispatch(self):
        vendor_location_id = self.env['stock.location'].search([('usage', '=', 'supplier'), ('is_collection_center', '=', False)], limit=1)

        out_type_id = self.env['stock.picking.type'].search([('code', '=', 'outgoing'), ('warehouse_id.company_id', '=', self.env.user.company_id.id)], limit=1)
        in_type_id = self.env['stock.picking.type'].search([('code', '=', 'incoming'), ('warehouse_id.company_id', '=', self.env.user.company_id.id)], limit=1)

        if not vendor_location_id or not out_type_id or not in_type_id:
            raise ValidationError(_('Designation location or Operation Type not found!'))
        stv_vals = {
            'partner_id': self.partner_id.id,
            'location_id': self.repair_id.location_id.id,
            'location_dest_id': vendor_location_id.id,
            'picking_type_id': out_type_id.id,
            'origin': self.name,
            'external_repair_id': self.id,
            'scheduled_date': self.dispatch_date,
            'move_lines': [(0, 0, {
                'product_id': self.product_id.id,
                'name': self.product_id.name,
                'origin': self.name,
                'location_id': self.repair_id.location_id.id,
                'location_dest_id': vendor_location_id.id,
                'product_uom_qty': self.qty,
                'quantity_done': self.qty,
                'product_uom': self.product_id.uom_id.id,
            })]
        }
        stv_picking = self.env['stock.picking'].create(stv_vals)
        stv_picking._action_done()

        vts_vals = {
            'partner_id': self.partner_id.id,
            'location_id': vendor_location_id.id,
            'location_dest_id': self.repair_id.location_id.id,
            'picking_type_id': in_type_id.id,
            'origin': 'RETURN - ' + self.name,
            'external_repair_id': self.id,
            'scheduled_date': self.return_date,
            'move_lines': [(0, 0, {
                'product_id': self.product_id.id,
                'name': self.product_id.name,
                'origin': self.name,
                'location_id': vendor_location_id.id,
                'location_dest_id': self.repair_id.location_id.id,
                'product_uom_qty': self.qty,
                'quantity_done': self.qty,
                'product_uom': self.product_id.uom_id.id,
            })]
        }
        vts_picking = self.env['stock.picking'].create(vts_vals)
        vts_picking.action_confirm()
        self.write({
            'dispatch_date': fields.Date.today(),
            'state': 'dispatch',
        })

    def action_open_dispatch(self):
        return {
            'name': _('Repair Dispatch'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('external_repair_id', '=', self.id), ('picking_type_id.code', '=', 'outgoing')],
        }

    def action_open_return(self):
        return {
            'name': _('Repair Return'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('external_repair_id', '=', self.id), ('picking_type_id.code', '=', 'incoming')],
        }

    def action_cancel(self):
        self.write({'state': 'cancel'})

    def action_done(self):
        self.write({'state': 'done'})
