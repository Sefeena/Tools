# -*- coding: utf-8 -*-
from odoo import fields, models, _


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    transfer_id = fields.Many2one('stock.transfer')
    weighment_id = fields.Many2one('grower.weighment', string="Weighment")
    ntfl_type = fields.Selection([
        ('farmer', 'Farmer'),
        ('firewood', 'Firewood'),
        ('general', 'General'),
        ('transporter', 'Transporter'),
        ('delete', 'Delete'),
        ('transfer', 'Transfer'),
        ('auction', 'Auction'),
        ('export', 'Export'),
        ('local', 'Local Sale'),
        ('pos', 'POS')], string="Types", default="general")

    def create_bill(self):
        bill_id = super(StockPicking, self).create_bill()
        if self.purchase_id and self.purchase_id.purchase_type and bill_id:
            ntfl_type = 'firewood' if self.purchase_id.purchase_type == 'firewood' else 'general'
            bill_id.ntfl_type = ntfl_type
        return bill_id

    def prepaire_transpore_rate_line(self):
        product_id = self.env.ref('pways_collection_management.transport_rate_product')
        lines = []
        location_ids = self.weighment_id.weighment_line_ids.mapped('location_id')
        for location_id in location_ids:
            total_quantity = 0.0
            for line in self.weighment_id.weighment_line_ids.filtered(lambda x: x.location_id.id == location_id.id):
                total_quantity = total_quantity + line.net
            lines.append((0, 0, {
                'name': '{}-{}'.format(product_id.name, location_id.name),
                'product_id': product_id.id,
                'price_unit': - float(location_id.transport_rate),
                'account_id': product_id.property_account_income_id.id if product_id.property_account_income_id
                else product_id.categ_id.property_account_income_categ_id.id,
                'tax_ids': [(6, 0, [])],
                'quantity': total_quantity,
            }))
        return lines

    def prepaire_fertilizer_deduction_line(self):
        product_id = self.env.ref('pways_collection_management.fertilizer_deduction_product')
        lines = []
        total_quantity = self.weighment_id.total_net
        lines.append((0, 0, {
            'name': product_id.name,
            'product_id': product_id.id,
            'price_unit': - float(self.partner_id.csr_amount),
            'account_id': product_id.property_account_income_id.id if product_id.property_account_income_id else product_id.categ_id.property_account_income_categ_id.id,
            'tax_ids': [(6, 0, [])],
            'quantity': total_quantity,
        }))
        return lines

    def create_fertilizer_recurring_deduction(self):
        journal_id = int(self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.csr_journal_id')) or False
        credit_account_id = int(self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.csr_credit_account_id')) or False
        debit_account_id = int(self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.csr_debit_account_id')) or False

        total_quantity = self.weighment_id.total_net
        deduction_amount = total_quantity * self.partner_id.csr_amount

        if journal_id and debit_account_id and credit_account_id:
            nhif_move = self.env['account.move'].create({
                'move_type': 'entry',
                'date': fields.Date.today(),
                'journal_id': journal_id,
                'ref': 'FERTILIZER DEDUCTION - ' + self.weighment_id.name,
                'is_csr_recurring': True,
                'partner_id': self.partner_id.id,
                'currency_id': self.env.user.company_id.currency_id.id,
                'line_ids': [
                    (0, 0, {
                        'debit': deduction_amount,
                        'credit': 0.0,
                        'name': 'FERTILIZER DEDUCTION - ' + self.weighment_id.name,
                        'date_maturity': fields.Date.today(),
                        'account_id': debit_account_id,
                        'partner_id': self.partner_id.id,
                    }),
                    (0, 0, {
                        'debit': 0.0,
                        'credit': deduction_amount,
                        'date_maturity': fields.Date.today(),
                        'name': 'FERTILIZER DEDUCTION - ' + self.weighment_id.name,
                        'account_id': credit_account_id,
                        'partner_id': self.partner_id.id,
                    }),
                ],
            })
            nhif_move.action_post()

    def create_bill_weighment(self):
        for picking_id in self:
            invoice_line_list = []
            current_user = self.env.uid
            vendor_journal_id = picking_id.env['ir.config_parameter'].sudo().get_param('pways_collection_management.vendor_journal_id') or False
            if not vendor_journal_id:
                raise UserError(_("Please configure journal in account settings."))
            for move_ids_without_package in picking_id.move_ids_without_package:
                tax_ids = self._get_purchase_tax(move_ids_without_package) or []
                vals = (0, 0, {
                    'name': move_ids_without_package.description_picking,
                    'product_id': move_ids_without_package.product_id.id,
                    'price_unit': move_ids_without_package.product_id.standard_price,
                    'account_id': move_ids_without_package.product_id.property_account_income_id.id if move_ids_without_package.product_id.property_account_income_id
                    else move_ids_without_package.product_id.categ_id.property_account_income_categ_id.id,
                    'tax_ids': [(6, 0, tax_ids)],
                    'quantity': move_ids_without_package.quantity_done,
                })
                invoice_line_list.append(vals)
            lines = self.prepaire_transpore_rate_line()
            invoice_line_list.extend(lines)

            # add fertilizer product on bill if farmer has CSR
            if picking_id.partner_id.csr_deduction and picking_id.partner_id.csr_amount > 0:
                fertilizer_lines = self.prepaire_fertilizer_deduction_line()
                invoice_line_list.extend(fertilizer_lines)
                self.create_fertilizer_recurring_deduction()

            invoice = picking_id.env['account.move'].create({
                'move_type': 'in_invoice',
                'invoice_date': picking_id.weighment_id.weighment_date if picking_id.weighment_id else False,
                'invoice_origin': picking_id.name,
                'invoice_user_id': current_user,
                'narration': picking_id.name,
                'partner_id': picking_id.partner_id.id,
                'currency_id': picking_id.env.user.company_id.currency_id.id,
                'journal_id': int(vendor_journal_id),
                'payment_reference': picking_id.name,
                'picking_id': picking_id.id,
                'ntfl_type': 'farmer',
                'invoice_line_ids': invoice_line_list
            })
            return invoice

    def _prepare_picking_vals(self, partner, picking_type, location_id, location_dest_id):
        res = super(StockPicking, self)._prepare_picking_vals(partner, picking_type, location_id, location_dest_id)
        res.update({'ntfl_type': 'pos'})
        return res


    def _action_done(self):
        res = super(StockPicking, self)._action_done()
        for picking in self:
            if all([picking.state == 'done' for picking in picking.transfer_id.picking_ids]):
                if picking.picking_type_id.code == 'incoming':
                    lots = picking.move_line_ids.mapped('lot_id')
                    # lots.write({'transfer_to_agent': picking.transfer_id.auction_request_id.delivery_id})
                picking.transfer_id.state = 'done'
        return res

    # def _action_set_agrnt_on_lot(self):
    #     picking_ids = self.search([('state', '=', 'done')])
    #     for picking in picking_ids.filtered(lambda x: x.transfer_id and x.transfer_id.auction_request_id):
    #         if picking.picking_type_id.code == 'incoming':
    #             lots = picking.move_line_ids.mapped('lot_id')
    #             lots.write({'transfer_to_agent': picking.transfer_id.auction_request_id.delivery_id})