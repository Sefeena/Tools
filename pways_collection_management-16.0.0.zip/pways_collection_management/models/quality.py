# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools, _
import requests
import json
import logging
_logger = logging.getLogger(__name__)


class QualityCheck(models.Model):
    _inherit = 'quality.check'

    is_firewood_claim = fields.Boolean()
    gate_weighment_id = fields.Many2one('gate.weighment', copy=False)
    partner_id = fields.Many2one('res.partner', related='gate_weighment_id.partner_id', store=True)
    supplier_claim = fields.Float('Supplier Claim')
    wood_l = fields.Float(string='L')
    wood_b = fields.Float(string='B')
    wood_h = fields.Float(string='H')
    wood_total = fields.Float('Total', compute='_compute_wood_total', store=True)
    weighment_weight = fields.Float('Weighment Weight', related="gate_weighment_id.net_weight")
    weighment_moisture = fields.Integer('Weighment Moisture(Kgs)', related="gate_weighment_id.moisture")

    @api.depends('wood_l', 'wood_b', 'wood_h')
    def _compute_wood_total(self):
        for check in self:
            check.wood_total = check.wood_l * check.wood_b * check.wood_h

    @api.model
    def default_get(self, fields):
        result = super(QualityCheck, self).default_get(fields)
        if result.get('is_firewood_claim'):
            product_id = self.env['product.product'].search([('firewood_ok', '=', True)], limit=1)
            result.update({'product_id': product_id.id})
        return result

    def do_pass(self):
        res = super(QualityCheck, self).do_pass()
        if self.is_firewood_claim and self.gate_weighment_id:
            self.gate_weighment_id.write({
                'supplier_claim': self.supplier_claim,
                'wood_total': self.wood_total,
                'is_quality_check': True
            })
            if not self.env.user.company_id.firewood_qc_msg and not self.gate_weighment_id or not self.partner_id:
                return res
            url = self._prepare_url()
            company_id = self.env.company
            response = requests.get(url, auth=(company_id.account_id, company_id.secret))
            log_id = self.smsleopard_log_create(json.loads(response.text))
            try:
                if response.status_code not in [200, 201]:
                    _logger.info("Wrong Data Found {0}".format(response.text))
                else:
                    _logger.info("Message has been sent {0}".format(response.text))
            except Exception as e:
                _logger.info("RESPONSE IS: {0}".format(e))
        return res

    def _get_message(self):
        message = " "
        template = self.env.ref('pways_collection_management.sms_firewood_qc', raise_if_not_found=False)
        if template and template.body_html:
            template_body = template._render_template(template.body_html, 'quality.check', self.ids)
            message = tools.html2plaintext(template_body.get(self.id)).replace("*", "")
        return message

    def _prepare_url(self):
        smsleopard_url = 'https://api.smsleopard.com/v1/sms/send?'
        company_id = self.env.company
        get_message = self._get_message()
        if not company_id.source or not company_id.source:
            raise ValidationError(_("Please set smsleopard configureration in compnay then after send sms...!"))
        if get_message and self.partner_id.mobile and company_id.source:
            full_url = smsleopard_url+'message='+get_message+'&destination='+self.partner_id.mobile+'&source='+company_id.source
        return full_url

    def smsleopard_log_create(self, values):
        recipients = values.get('recipients')
        message_id = ' '
        status = ' '
        if isinstance(recipients, list):
            message_id = recipients[0].get('id') if recipients[0] and recipients[0].get('id') else ' '
            status = recipients[0].get('status') if recipients[0] and recipients[0].get('status') else ' '
        log_id = self.env['smsleopard.log'].create({
            'success' : values.get('success', False),
            'smsleopard_number' : self.partner_id.mobile,
            'massage_id' : message_id,
            'message' : values.get('message', ' '),
            'status' : status,
        })
        return log_id
