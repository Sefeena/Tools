# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class MrpPauseReason(models.Model):
    _name = "mrp.pause.reason"

    name = fields.Text('Reason', required=True)
    workorder_id = fields.Many2one('mrp.workorder')
