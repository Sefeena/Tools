# -*- coding: utf-8 -*-

from . import installment_payment
