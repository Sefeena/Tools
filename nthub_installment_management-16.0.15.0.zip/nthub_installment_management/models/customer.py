# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_


class Customer(models.Model):
    _name = 'installment.customer'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Customer'
    _rec_name = 'name'

    name = fields.Char(string=_('Name'))
    company_type = fields.Selection([('individual', 'Individual'),
                                     ('company', 'Company')], default='company')
    address = fields.Char(string=_('Address'))
    street = fields.Char(string=_('Street'))
    street2 = fields.Char(string=_('Street2'))
    city = fields.Char(string=_('City'))
    country_id = fields.Many2one('res.country')
    zip = fields.Char(string=_('Zip'))
    state_id = fields.Many2one('res.country.state')
    phone = fields.Char(string=_('Phone'))
    mobile = fields.Char(string=_('Mobile'))
    email = fields.Char(string=_('Email'))
    image = fields.Image(string=_("Image"))
    national_id = fields.Binary(string=_('National ID'))
    rental_contract = fields.Binary(string=_('Rental Contract'))
    ownership_contract = fields.Binary(string=_('Ownership Contract'))
    salary_components = fields.Binary(string=_('Salary Components'))
    bank_statement = fields.Binary(string=_('Bank Statement'))
    bank_rate_letter = fields.Binary(string=_('Bank Rate Letter'))
    internal_notes = fields.Html(string=_("Internal Notes"))
    attachment = fields.Char(string=_('Attachment'))
    national = fields.Char(string=_("National ID"))
    total_amount = fields.Float(string=_("Total Amount"), compute="compute_installment")
    total_paid_amount = fields.Float(string=_("total Paid"), compute="compute_installment")
    balance_amount = fields.Float(string=_("total Balance"), compute="compute_installment")
    installment_count = fields.Float(string=_("Installment Count"), compute="compute_installment")
    currency_id = fields.Many2one('res.currency', string=_('Currency'), required=True,
                                  default=lambda self: self.env.user.company_id.currency_id)

    @api.depends('total_amount', 'total_paid_amount', 'balance_amount', 'installment_count')
    def compute_installment(self):
        installment = self.env['installment.installment'].search([])
        for record in self:
            record.total_amount = sum(installment.mapped('total_amount'))
            record.total_paid_amount = sum(installment.mapped('total_paid_amount'))
            record.balance_amount = sum(installment.mapped('balance_amount'))
            record.installment_count = len(installment)

    def get_installment(self):
        current_customer_id = self.id
        return {
            'type': 'ir.actions.act_window',
            'name': 'Installment',
            'view_mode': 'tree,form',
            'target': 'current',
            'domain': [('customer_id', '=', current_customer_id)],
            'res_model': 'installment.installment',
        }


