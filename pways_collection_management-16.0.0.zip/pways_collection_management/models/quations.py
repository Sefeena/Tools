# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Quations(models.Model):
    _name = "res.quations"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Question")
