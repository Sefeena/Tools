# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime
import json
import io
from odoo.http import request
from odoo.tools import date_utils
import pytz

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter

class FarmerPaymentSummaryWizard(models.TransientModel):
    _name = "farmer.payment.summary.wizard"
    _description = "Farmer Payment Summary Wizard"

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    bank_ids = fields.Many2many('res.bank', string='Bank')
    partner_ids = fields.Many2many('res.partner', string="Out Grower")
    payment_type = fields.Selection([('paid', 'Paid'), ('unpaid', 'Unpaid')], default='paid', required=True)

    @api.constrains('date_from', 'date_to')
    def _check_date(self):
        if self.date_from and self.date_to and self.date_from > self.date_to:
            raise ValidationError('To date must be greater then from date')

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'bank_ids': self.bank_ids.ids,
            'payment_type': self.payment_type,
            'partner_ids':self.partner_ids.ids,
        }
        return self.env.ref('pways_collection_management.action_farmer_payment_summary_report').report_action(self, data=data)

    def print_report_xls(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'partner_ids':self.partner_ids.ids,
            'bank_ids': self.bank_ids.ids,
            'payment_type': self.payment_type,
            'report_header': 'Date From ' + self.date_from.strftime("%d/%m/%Y") + ' To '+self.date_to.strftime("%d/%m/%Y"),
        }
        return {
            'type': 'ir.actions.report',
            'data': {
                'model': 'farmer.payment.summary.wizard',
                'options': json.dumps(data, default=date_utils.json_default),
                'output_format': 'xlsx',
                'report_name': 'Farmer Payment Report',
            },
            'report_type': 'xlsx'
        }

    def _get_group_by_partner(self, bill_ids):
        group_by_partner_id  = {}
        for bill in bill_ids:
            partner_id = bill.partner_id
            if partner_id not in group_by_partner_id:
                group_by_partner_id[partner_id] = bill
            else:
                group_by_partner_id[partner_id] |= bill
        return group_by_partner_id

    def get_xlsx_report(self, data, response, partner_ids=None):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        date_from = data.get('date_from')
        date_to = data.get('date_to')
        partner_ids = data.get('partner_ids')
        report_header = data.get('report_header')
        bank_ids = data.get('bank_ids')
        payment_type = data.get('payment_type')
        sheet = workbook.add_worksheet("payment Report")
        format1 = workbook.add_format({'font_size': 15})
        format2 = workbook.add_format({'font_size': 10, 'bold': True, 'bg_color': '#D3D3D3'})
        format3 = workbook.add_format({'font_size': 10})
        format5 = workbook.add_format({'font_size': 10})
        format4 = workbook.add_format({'font_size': 10, 'top': 1, 'bottom': 6})
        format1.set_align('center')
        format5.set_align('center')

        sheet.merge_range('A1:O2', 'Farmer Payment Summary Report', format1)
        headers = ['Farmer Code', 'Farmer Name', 'ID No', 'Contact No', 'Account', 'Bank Name', 'Branch', 'Bank Code', 'Branch Code', 'Net Wt', 'Amount', 'Advance', 'KES 2 Fertilizer', 'NHIF', 'Payable']
        row = 3
        col = 0
        for header in headers:
            sheet.set_column(col, 1, 13)
            sheet.write(row, col, header, format2)
            col += 1
        sheet.merge_range('A3:O3', report_header, format5)
        domain = [('partner_id.is_farmer', '=', True), ('state', '=', 'posted'), ('invoice_date', '>=', date_from), ('invoice_date', '<=', date_to)]
        if payment_type == 'unpaid':
            domain.append(('payment_state', 'in', ['not_paid','partial']))
        else:
            domain.append(('payment_state', '=', 'paid'))
        if partner_ids:
            domain.append(('partner_id', 'in', partner_ids))
        bill_ids = self.env['account.move'].search(domain)
        group_by_partner_id = self._get_group_by_partner(bill_ids)
        lines = []

        total_netwt = 0.0
        amount_total = 0.0
        for partner_id, bill_ids in group_by_partner_id.items():
            partner_bank_id = partner_id.bank_ids and partner_id.bank_ids[0]
            if not bank_ids or (partner_bank_id.bank_id.id in bank_ids):
                line_ids = bill_ids.mapped('invoice_line_ids')
                netwt = sum(line_ids.filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity'))
                amount = sum(bill_ids.mapped('amount_residual'))
                total_netwt += netwt
                amount_total += amount

                lines.append({
                    'farmer_code': partner_id.code or '',
                    'farmer_name': partner_id.display_name or '',
                    'national_id': partner_id.national_id or '',
                    'contact_no': partner_id.mobile or '',
                    'account_no': partner_bank_id.acc_number or '',
                    'bank_id': partner_bank_id.bank_id.name or '',
                    'branch_id': partner_bank_id.branch_id.branch_name or '',
                    'bank_code': partner_bank_id.bank_id.bic or '',
                    'branch_code': partner_bank_id.branch_id.branch_code or '',
                    'netwt': netwt,
                    'amount': amount,
                })
        row = 4
        col = 0
        for val in lines:
            sheet.write(row, col+0, val['farmer_code'], format3)
            sheet.write(row, col+1, val['farmer_name'], format3)
            sheet.write(row, col+2, val['national_id'], format3)
            sheet.write(row, col+3, val['contact_no'], format3)
            sheet.write(row, col+4, val['account_no'], format3)
            sheet.write(row, col+5, val['bank_id'], format3)
            sheet.write(row, col+6, val['branch_id'], format3)
            sheet.write(row, col+7, val['bank_code'], format3)
            sheet.write(row, col+8, val['branch_code'], format3)
            sheet.write(row, col+9, val['netwt'], format3)
            sheet.write(row, col+10, val['amount'], format3)
            row += 1

        # Sheet Total
        row += 1
        sheet.write(row, col+0, 'Total', format3)
        sheet.write(row, col+9, total_netwt, format4)
        sheet.write(row, col+10, amount_total, format4)

        workbook.close()
        output.seek(0)
        response.stream.write(output.read())

        output.close()
