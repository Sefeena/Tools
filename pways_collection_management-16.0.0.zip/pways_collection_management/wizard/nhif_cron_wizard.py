# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar


class NhifCronWizard(models.TransientModel):
    _name = "nhif.cron.wizard"
    _description = "NHIF Cron Wizard"

    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    nhif_journal_id = fields.Many2one('account.journal', related='company_id.nhif_journal_id', string="Journal", required=True, readonly=False)
    nhif_credit_account_id = fields.Many2one('account.account', related='company_id.nhif_credit_account_id', string="Credit Account", required=True, readonly=False)
    nhif_debit_account_id = fields.Many2one('account.account', related='company_id.nhif_debit_account_id', string="Debit Account", required=True, readonly=False)
    force_date = fields.Date('NHIF Backdate')

    def action_run_nhif_cron(self):
        cron_id = self.env.ref('pways_collection_management.ir_cron_nhif_deduction')
        if not cron_id:
            raise ValidationError(_('NHIF Cron Job not Found !'))
        cron_id.with_context({'force_date': self.force_date}).method_direct_trigger()

        today = date.today() - relativedelta(months=1)
        if self.force_date:
            today = self.force_date
        last_day = calendar.monthrange(today.year, today.month)[1]
        date_from = today.replace(day=1).strftime("%Y-%m-%d")
        date_to = today.replace(day=last_day).strftime("%Y-%m-%d")

        domain = [
            ('move_type', '=', 'entry'),
            ('is_nhif_deduction', '=', True),
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('state', '!=', 'cancel'),
        ]

        return {
            'name': _('Journal Entry'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'views': [(self.env.ref('account.view_move_tree').id, 'tree'), (False, 'form')],
            'type': 'ir.actions.act_window',
            'domain': domain,
        }
