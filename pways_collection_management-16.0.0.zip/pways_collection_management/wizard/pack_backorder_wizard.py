# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class PackBackorderBackorderWizard(models.TransientModel):
    _name = 'pack.backorder.wizard'
    _description = 'Packaging Order Backorder Wizard'

    def action_create_backorder(self):
        active_id = self.env.context.get('active_id')
        packaging_order = self.env['packaging.order'].browse(active_id)
        todo_qty = packaging_order.product_qty - packaging_order.process_qty
        return_sort_order = packaging_order.copy({
            'product_qty': todo_qty,
            'product_id': packaging_order.product_id.id,
            'template_id': packaging_order.template_id.id,
            'backorder_id': packaging_order.id,
            'move_id': False,
        })
        for line in packaging_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        packaging_order.move_id.write({'quantity_done': packaging_order.process_qty})
        back_move = packaging_order.move_id._action_done(cancel_backorder=False)
        packaging_order.write({'state': 'done'})
        return_sort_order.onchange_template_id()
        return_sort_order.write({'move_id': back_move.id})
        return True

    def action_no_create_backorder(self):
        stock_move = self.env['stock.move']
        active_id = self.env.context.get('active_id')
        packaging_order = self.env['packaging.order'].browse(active_id)
        packaging_order.write({'product_qty': packaging_order.process_qty})
        for line in packaging_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        packaging_order.move_id.write({'quantity_done': packaging_order.product_qty})
        packaging_order.move_id._action_done(cancel_backorder=True)
        packaging_order.write({'state': 'done'})
        return True
