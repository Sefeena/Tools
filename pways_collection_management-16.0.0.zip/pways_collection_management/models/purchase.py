# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

class Purchase(models.Model):
    _inherit = "purchase.order"

    # is_firewood = fields.Boolean(string="Firewood Product")
    purchase_type = fields.Selection([
        ('firewood', 'Firewood'),
        ('general_purchase', 'General Purchase'),
    ], required=True, default='firewood',
        help="The 'purchase_type Type' is used for features available on "\
        "different types of purchase order")
    expiry_date = fields.Date(string="Expiry Date")
    po_status = fields.Selection([('open', 'Open'), ('closed', 'Closed')], string='PO Status', compute='_compute_po_status', store=True)
    weighment_line_ids = fields.One2many('firewood.purchase.line', 'order_id')

    @api.depends('picking_ids.state')
    def _compute_po_status(self):
        for order in self:
            if order.state in ('done', 'purchase') and order.picking_ids.filtered(lambda x: x.state != 'cancel'):
                if all(picking.state == 'done' for picking in order.picking_ids):
                    order.po_status = 'closed'
                else:
                    order.po_status = 'open'
            else:
                order.po_status = ''

    @api.onchange('purchase_type')
    def _onchange_purchase_type(self):
        # self.is_firewood = True if self.purchase_type == 'firewood' else False
        domain = []
        if self.purchase_type == 'general_purchase':
            domain += [('is_farmer', '=', False), ('supplier_rank', '=', 1)]
        partner_ids = self.env['res.partner'].search(domain)
        return {'domain': {'partner_id': [('id', 'in', partner_ids.ids)]}}

    def _prepare_invoice(self):
        bill_vals = super(Purchase, self)._prepare_invoice()
        if self.purchase_type:
            ntfl_type = 'firewood' if self.purchase_type == 'firewood' else 'general'
            bill_vals.update({'ntfl_type': ntfl_type})
        return bill_vals

    @api.model
    def _prepare_picking(self):
        res = super(Purchase, self)._prepare_picking()
        if self.purchase_type:
            ntfl_type = 'firewood' if self.purchase_type == 'firewood' else 'general'
            res.update({'ntfl_type': ntfl_type})
        return res

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    last_purchase_price = fields.Float(string='Last Purchase Price', compute='_compute_last_purchase_price', store=True)

    @api.depends('product_id')
    def _compute_last_purchase_price(self):
        for line in self:
            last_line_id = self.env['purchase.order.line'].search([('order_id.state', 'in', ('done', 'purchase')), ('product_id', '=', line.product_id.id)], limit=1)
            line.last_purchase_price = last_line_id.price_unit

class FirewoodPurchaseLine(models.Model):
    _name = 'firewood.purchase.line'

    order_id = fields.Many2one('purchase.order', copy=False)
    gate_weighment_id = fields.Many2one('gate.weighment', string='Weighment')
    qty = fields.Float('Quantity')

class ProductCategory(models.Model):
    _inherit = 'product.category'

    is_tea_product = fields.Boolean('Is Tea Product')


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    crate_ok = fields.Boolean(
        string="Is Crate",
        help="Allow product as Crate")
    green_leaf_ok = fields.Boolean(
        string="Is Green Leaf",
        help="Allow product as Green Leaf")
    fertilizer_ok = fields.Boolean(
        string="Is Fertilizer",
        help="Allow product as Fertilizer")
    firewood_ok = fields.Boolean(
        string="Is Firewood",
        help="Allow Product as Firewood")
    category_id = fields.Many2one('uom.category', related='uom_id.category_id')
    display_uom_id = fields.Many2one('uom.uom', string="Display Unit Of Measure")

    @api.onchange('uom_id')
    def _onchange_uom_id(self):
        if self.uom_id:
            self.display_uom_id = self.uom_id.id


class AccountMove(models.Model):
    _inherit = "account.move"

    ntfl_type = fields.Selection([
        ('farmer', 'Farmer'),
        ('firewood', 'Firewood'),
        ('general', 'General'),
        ('transporter', 'Transporter'),
        ('delete', 'Delete'),
        ('transfer', 'Transfer'),
        ('nhif', 'NHIF'),
        ('auction', 'Auction'),
        ('export', 'Export'),
        ('local', 'Local Sale'),
        ('pos', 'POS')
        ], string="Types", default="general")
    ntfl_move_type = fields.Selection([('farmer', 'Farmer'), ('auction', 'Auction'), ('general', 'General')], string="Types", default="general")
    # auction_no = fields.Char(string='Auction No')
    # auction_date = fields.Date(string='Auction Date')
    prompt_date = fields.Date(string='Prompt Date')
    account_sale_no = fields.Char(string='Account Sale No')
    total_green_leaves = fields.Float(string='Net Weight', compute='_compute_total_green_leaves', store=True)
    is_nhif_deduction = fields.Boolean('NHIF Deduction')
    is_csr_recurring = fields.Boolean('Fertilizer Recurring')
    nhif_reconciled = fields.Boolean()
    supplier_payment_term_id = fields.Many2one('account.payment.term', string='Payment Term', compute='_compute_supplier_payment_term_id', store=True)

    def _compute_supplier_payment_term_id(self):
        for bill in self:
            if bill.move_type in ('in_invoice', 'in_refund'):
                bill.supplier_payment_term_id = bill.partner_id.property_supplier_payment_term_id.id
            else:
                bill.supplier_payment_term_id = False

    @api.depends('invoice_line_ids', 'invoice_line_ids.quantity')
    def _compute_total_green_leaves(self):
        for move in self:
            total_green_leaves = sum(move.invoice_line_ids.filtered(lambda x: x.product_id.green_leaf_ok == True).mapped('quantity'))
            if move.move_type == 'in_refund':
                total_green_leaves = -(total_green_leaves)
            move.total_green_leaves = total_green_leaves

    @api.model
    def default_get(self, fields):
        vals = super(AccountMove, self).default_get(fields)
        vals['invoice_date'] = vals.get('date')
        return vals

    def create_nhif_deduction(self):
        farmer_ids = self.env['res.partner'].search([('nhif_deduction', '=', True), ('nhif_amount', '>', 0)])
        today = date.today() - relativedelta(months=1)
        force_date = self.env.context.get('force_date')
        if force_date:
            today = force_date
        last_day = calendar.monthrange(today.year, today.month)[1]
        date_from = today.replace(day=1).strftime("%Y-%m-%d")
        date_to = today.replace(day=last_day).strftime("%Y-%m-%d")
        month = today.replace(day=1).strftime("%b-%Y")
        move_ids = self.env['account.move'].search([
            ('move_type', '=', 'entry'),
            ('partner_id', 'in', farmer_ids.ids),
            ('is_nhif_deduction', '=', True),
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('state', '!=', 'cancel'),
        ])
        todo_farmer_ids = farmer_ids - move_ids.mapped('partner_id')
        journal_id = self.env.user.company_id.nhif_journal_id
        debit_account_id = self.env.user.company_id.nhif_debit_account_id
        credit_account_id = self.env.user.company_id.nhif_credit_account_id
        if journal_id and debit_account_id and credit_account_id and todo_farmer_ids:
            for farmer in todo_farmer_ids:
                bill_ids = self.env['account.move'].search([
                    ('move_type', '=', 'in_invoice'),
                    ('partner_id', '=', farmer.id),
                    ('date', '>=', date_from),
                    ('date', '<=', date_to),
                    ('state', '!=', 'cancel'),
                    ('payment_state', '!=', 'paid'),
                ])
                outstanding_amount = sum(bill_ids.mapped('amount_residual'))
                deduction_amount = farmer.nhif_amount
                if outstanding_amount >= deduction_amount:
                    nhif_move = self.env['account.move'].create({
                        'move_type': 'entry',
                        'date': date_to,
                        'journal_id': journal_id.id,
                        'ref': 'NHIF DEDUCTION ('+farmer.national_id +') ' + month,
                        'is_nhif_deduction': True,
                        'ntfl_type': 'nhif',
                        'partner_id': farmer.id,
                        'currency_id': self.env.user.company_id.currency_id.id,
                        'line_ids': [
                            (0, 0, {
                                'debit': deduction_amount,
                                'credit': 0.0,
                                'name': 'NHIF DEDUCTION ('+farmer.national_id +') ' + month,
                                'date_maturity': date_to,
                                'account_id': debit_account_id.id,
                                'partner_id': farmer.id,
                            }),
                            (0, 0, {
                                'debit': 0.0,
                                'credit': deduction_amount,
                                'date_maturity': date_to,
                                'name': 'NHIF DEDUCTION ('+farmer.national_id +') ' + month,
                                'account_id': credit_account_id.id,
                                'partner_id': farmer.id,
                            }),
                        ],
                    })
                    nhif_move.action_post()

    def reconcile_farmer_bills(self):
        if any(bill.state != 'posted' for bill in self):
            raise ValidationError(_('Please select only posted vendor bills.'))
        if any(bill.move_type != 'in_invoice' for bill in self):
            raise ValidationError(_('This action is only possible for Vendor Bills.'))

        for bill in self:
            je_ids = self.env['account.move.line'].search([('reconciled', '=', False), ('move_id.move_type', '=', 'entry'), ('move_id.state', '=', 'posted'), ('partner_id', '=', bill.partner_id.id), ('account_id.internal_type', 'in', ('payable', 'receivable'))])
            reconcile_ids = bill.mapped('line_ids').filtered(lambda r: not r.reconciled and r.account_id.internal_type in ('payable', 'receivable'))
            reconcile_ids |= je_ids
            reconcile_ids.reconcile()
        return True
