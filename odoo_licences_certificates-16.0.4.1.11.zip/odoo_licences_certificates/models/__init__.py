# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd.
# See LICENSE file for full copyright and licensing details.
from . import licences_certificate
from . import licences_certificate_type
from . import res_partner
from . import hr_employee_inherited
from . import res_user_inherited
from . import record_licences
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
