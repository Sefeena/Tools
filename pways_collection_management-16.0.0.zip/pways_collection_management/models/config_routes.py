# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Routes(models.Model):
    _name = 'routes.routes'
    _inherit = ['format.address.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Routes"

    name = fields.Char(string="Route Name", copy=False, required=True)
    location_ids = fields.Many2many('stock.location', relation='routes_routes_location_rel', string="Locations")
    # is_firewood = fields.Boolean('Firewood')
    is_for_billing = fields.Boolean('Billing')


