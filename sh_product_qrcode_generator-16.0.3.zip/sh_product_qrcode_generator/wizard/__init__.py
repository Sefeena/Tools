# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from . import sh_product_qrcode_generator_label_layout
from . import sh_qr_generator
