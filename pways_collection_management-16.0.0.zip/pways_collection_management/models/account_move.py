from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    picking_id = fields.Many2one('stock.picking', string='Picking')
    trip_id = fields.Many2one('trip.trip', string="Trip")
    log_fuel_id = fields.Many2one('fleet.vehicle.log.fuel', string="Fleet Vehicle Log Fuel")
    vehicle_id = fields.Many2one('fleet.vehicle', readonly=True)
    out_grower_loan_id = fields.Many2one('out.grower.loan', string="Loan")
