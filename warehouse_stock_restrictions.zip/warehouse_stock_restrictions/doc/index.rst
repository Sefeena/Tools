Warehouse Restriction
========================
- This module will add Warehouse and Stock Location Restriction on Users

Installation
============
- Install the module normally like other modules.

Configuration
=============
- Add Default Warehouse Opertions and Allowed Stock Locations and you are ready to go.

Note
====
- This restrictions are created using rule and access rights, so it will have no effect on the Adminstrator.