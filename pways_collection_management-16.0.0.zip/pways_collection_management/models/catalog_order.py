# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import timedelta, datetime
from odoo.exceptions import UserError, ValidationError

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    is_sold = fields.Boolean()

class AccountMove(models.Model):
    _inherit = 'account.move'

    catalog_id = fields.Many2one('catalog.order')

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    packaging_order_id = fields.Many2one('packaging.order', string='INV No')

class StockProductionLot(models.Model):
    _inherit = 'stock.lot'

    rate = fields.Float('Rate', copy=False)

class CatalogOrder(models.Model):
    _name = 'catalog.order'
    _description = 'Catalog Order'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _order = 'id desc'

    name = fields.Char(default='New', readonly=True, string="Approvel Subject", copy=False)
    catalog_date = fields.Datetime('Date')
    partner_id = fields.Many2one('res.partner', string='Agent', domain=[('is_agent', '=', True)], required=True)
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirmed'), ('close', 'Closed')], default='draft')
    line_ids = fields.One2many('catalog.order.line', 'order_id', ondelete='cascade')
    invoice_count = fields.Integer(compute='_compute_invoice_count')
    warehouse_id = fields.Many2one('stock.warehouse', string='Warehouse', required=True,) #domain=[('is_auction', '=', True)],)
    location_id = fields.Many2one("stock.location")
    prompt_date = fields.Datetime('Prompt Date')
    account_sale_no = fields.Char('Account Sale No')

    def _compute_invoice_count(self):
        for catalog in self:
            catalog.invoice_count = self.env['account.move'].search_count([('catalog_id', '=', catalog.id)])

    @api.onchange('warehouse_id')
    def _onchange_warehouse_id(self):
        self.location_id = self.warehouse_id.lot_stock_id

    @api.onchange('catalog_date', 'location_id')
    def _onchange_catalog_date(self):
        lines = [(5, 0, 0)]
        if self.catalog_date:
            line_ids = self.env['catalog.order.line'].search([('status', 'in', ('in_progress', 'sold'))])
            move_lines = self.env['stock.move.line'].search([
                ('date', '<=', self.catalog_date),
                ('location_id.usage', '=', 'transit'),
                ('location_dest_id', '=', self.location_id.id),
                ('location_dest_id.usage', '=', 'internal'),
                ('picking_id.transfer_id', '!=', False),
                ('state', '=', 'done'),
                ('lot_id.transfer_to_agent', '=', self.partner_id.id),
                ('is_sold', '=', False),
                ('id', 'not in', line_ids.mapped('move_line_ids').ids),
            ])
            group_by_lot = {}
            for line in move_lines:
                if line.lot_id.id in group_by_lot:
                    group_by_lot[line.lot_id.id] |= line
                else:
                    group_by_lot[line.lot_id.id] = line
            for lot, move_lines in group_by_lot.items():
                quants = self.env['stock.quant'].search([
                    ('product_id', '=', move_lines and move_lines[0].product_id.id),
                    ('location_id', '=', move_lines and move_lines[0].location_dest_id.id),
                    ('lot_id', '=', lot),
                    ('available_quantity', '>', 0),
                ])
                qty_available = sum(quants.mapped('available_quantity'))
                done_qty = sum(move_lines.mapped('qty_done'))
                if qty_available < done_qty:
                    done_qty = qty_available
                if done_qty:
                    lines.append((0, 0, {
                        'lot_id': lot,
                        'move_line_ids': move_lines.ids,
                        'quantity': done_qty,
                    }))
        self.line_ids = lines

    def action_confirm(self):
        if any([line.is_sold for line in self.line_ids.mapped('move_line_ids')]):
            raise ValidationError(_('Please refresh the order, There are some lots are already used in other catalog !'))
        if not self.line_ids:
            raise ValidationError(_('There are no lots to confirm!'))

        virtual_location_id = self.env['stock.location'].search([('usage', '=', 'inventory')], limit=1)
        for line in self.line_ids:
            sample_lot_id = self.env['stock.lot'].search([('name', '=', line.lot_id.name), ('product_id', '=', line.lot_id.product_id.sample_product_id.id)])
            quants = self.env['stock.quant'].search([('location_id', 'in', line.move_line_ids.mapped('location_dest_id').ids), ('lot_id.name', '=', line.lot_id.name), ('product_id', '=', line.lot_id.product_id.sample_product_id.id)])
            sample_product_id = line.lot_id.product_id.sample_product_id
            avelabal_quantity = sum(quants.mapped('available_quantity'))
            if avelabal_quantity > 0:
                out_move = self.env['stock.move'].create({
                    'name': sample_product_id.name,
                    'location_id': line.move_line_ids and  line.move_line_ids[0].location_dest_id.id,
                    'location_dest_id': virtual_location_id.id,
                    'product_id': sample_product_id.id,
                    'product_uom': sample_product_id.uom_id.id,
                    'product_uom_qty': avelabal_quantity,
                })
                self.env['stock.move.line'].create({
                    'move_id': out_move.id,
                    'lot_id': sample_lot_id.id,
                    'qty_done': avelabal_quantity,
                    'product_id': sample_product_id.id,
                    'product_uom_id': sample_product_id.uom_id.id,
                    'location_id': line.move_line_ids and line.move_line_ids[0].location_dest_id.id,
                    'location_dest_id': virtual_location_id.id,
                })
                out_move._action_done()
            else:
                vals = {
                'lot_id': line.lot_id.id,
                'catalog_id': self.id,
                'sample_product_id': sample_product_id.id,
                'sample_product_uom': sample_product_id.uom_id.id,
                'sample_product_qty': 1}
                recatalog_line = self.env['recatalog.lot.line'].create(vals)
                if recatalog_line:
                    line.net_kg = line.net_kg - line.lot_id.extra_net_kg

        self.write({'state': 'confirm'})
        self.line_ids.write({'status': 'in_progress'})
        return True

    def create_invoice(self):
        journal_domain = [
            ('type', '=', 'sale'),
            ('company_id', '=', self.env.user.company_id.id),
        ]
        customer_journal_id = self.env['account.journal'].search(journal_domain, limit=1)
        invoice_line_list = []
        if not customer_journal_id:
            raise UserError(_("Please configure journal in account settings"))
        for line in self.line_ids.filtered(lambda x: x.status == 'sold'):
            product_id = line.lot_id.product_id
            vals = (0, 0, {
                'name': product_id.name,
                'product_id': product_id.id,
                'price_unit': line.rate,
                'account_id': product_id.property_account_income_id.id if product_id.property_account_income_id else product_id.categ_id.property_account_income_categ_id.id,
                # 'tax_ids': [(6, 0, tax_ids)],
                'quantity': line.net_kg,
                'packaging_order_id': line.packaging_order_id.id,
            })
            invoice_line_list.append(vals)
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'invoice_origin': self.name,
            'invoice_user_id': self.env.uid,
            'partner_id': self.partner_id.id,
            'currency_id': self.env.user.company_id.currency_id.id,
            'journal_id': customer_journal_id.id,
            'payment_reference': self.name,
            'ntfl_type': 'auction',
            'catalog_id': self.id,
            'invoice_line_ids': invoice_line_list,
            # 'auction_no': self.auction_no,
            # 'auction_date': self.auction_date,
            'prompt_date': self.prompt_date,
            'account_sale_no': self.account_sale_no,
        })
        return True

    def open_invoice(self):
        return {
            'name': _('Customer Invoice'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('catalog_id', '=', self.id)],
        }

    def action_close(self):
        self.line_ids.filtered(lambda x: x.status != 'sold').write({'status': 'unsold'})
        if sum(self.line_ids.mapped('total')) > 0:
            self.create_invoice()
        self.write({'state': 'close'})
        return True

    def action_refresh(self):
        self._onchange_catalog_date()
        return True

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('catalog.order') or '/'
        return super(CatalogOrder, self).create(vals)


class CatalogOrderLine(models.Model):
    _name = 'catalog.order.line'
    _description = 'Catalog Order Lines'

    order_id = fields.Many2one('catalog.order')
    move_line_ids = fields.Many2many('stock.move.line')
    product_id = fields.Many2one('product.product')
    lot_id = fields.Many2one('stock.lot', domain="[('product_id', '=', product_id)]", required=True)
    quantity = fields.Float('Quantity')
    uom_id = fields.Many2one('uom.uom', related='product_id.uom_id', string="Unit of Measure")
    rate = fields.Float('Rate', tracking=True)
    net_kg = fields.Float(string='Net KG', compute='_compute_net_kg', digits='Product Unit of Measure', store=True)
    state = fields.Selection(related='order_id.state', store=True)
    total = fields.Float(compute='_compute_total', string='Total')
    status = fields.Selection([('draft', 'Draft'), ('in_progress', 'In Progress'), ('sold', 'Sold'), ('unsold', 'Un sold')], default='draft')

    @api.depends('product_id', 'uom_id', 'quantity', 'lot_id.recatlog_lot_line_ids')
    def _compute_net_kg(self):
        for line in self:
            parent_uom = self.env['uom.uom'].search([('category_id', '=', line.product_id.uom_id.category_id.id), ('uom_type', '=', 'reference')], limit=1)
            line.net_kg = line.uom_id._compute_quantity(line.quantity, parent_uom, rounding_method='HALF-UP')

    @api.depends('rate', 'quantity', 'lot_id')
    def _compute_total(self):
        for line in self:
            line.total = line.net_kg * line.rate

    def action_sold(self):
        self.lot_id.write({'rate': self.rate})
        location_dest_id = self.move_line_ids and self.move_line_ids[0].location_dest_id
        virtual_location_id = self.env['stock.location'].search([('usage', '=', 'inventory')], limit=1)
        quants = self.env['stock.quant'].search([('location_id', '=', location_dest_id.id), ('lot_id.name', '=', self.lot_id.name), ('product_id', '=', self.lot_id.product_id.id)])
        avelabal_quantity = sum(quants.mapped('available_quantity'))
        if avelabal_quantity > 0:
            out_move = self.env['stock.move'].create({
                'name': self.lot_id.product_id.name,
                'location_id': location_dest_id.id,
                'location_dest_id': virtual_location_id.id,
                'product_id': self.lot_id.product_id.id,
                'product_uom': self.lot_id.product_id.uom_id.id,
                'product_uom_qty': avelabal_quantity,
            })
            self.env['stock.move.line'].create({
                'move_id': out_move.id,
                'lot_id': self.lot_id.id,
                'qty_done': avelabal_quantity,
                'product_id': self.lot_id.product_id.id,
                'product_uom_id': self.lot_id.product_id.uom_id.id,
                'location_id': location_dest_id.id,
                'location_dest_id': virtual_location_id.id,
            })
            out_move._action_done()
        self.status = 'sold'
        self.move_line_ids.write({'is_sold': True})

    def action_unsold(self):
        self.status = 'unsold'
