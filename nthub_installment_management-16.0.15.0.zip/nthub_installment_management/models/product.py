# -*- coding: utf-8 -*-

from odoo import models, fields, api,_


class Product(models.Model):
    _name = 'installment.product'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "product"
    _rec_name = "name"

    name = fields.Char(string=_("Name"))
    priority = fields.Selection([("0", "normal"), ("1", "low")])
    image = fields.Image(_("Image"))
    description = fields.Char(string=_("Description"))
    quantity = fields.Float(string=_("Quantity"), default=0.0)
    cost_price = fields.Float(string=_("Cost Price"))
    sale_price = fields.Float(string=_("Sale Price"))
    category_id = fields.Many2one("installment.category", string=_("Product Category"))
    internal_note = fields.Text(string=_("internal_note"))
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.user.company_id.currency_id)
    internal_serial = fields.Char(string=_('Internal Reference'))

    def get_quantity(self):
        self.quantity = self.quantity

