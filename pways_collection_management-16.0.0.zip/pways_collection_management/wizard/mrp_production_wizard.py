# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class MrpProductionWizard(models.TransientModel):
    _name = "mrp.production.wizard"
    _description = "Production Report Wizard"

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)

    @api.constrains('date_from', 'date_to')
    def _check_date(self):
        if self.date_from and self.date_to and self.date_from > self.date_to:
            raise ValidationError('To date must be greater then from date')

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
        }
        return self.env.ref('pways_collection_management.action_mrp_production_report').report_action(self, data=data)

class MrpProductionReport(models.AbstractModel):
    _name = 'report.pways_collection_management.mp_report_template'

    def _get_group_by_planned_date(self, mo_ids):
        group_by_date  = {}
        for mo in mo_ids:
            planned_date = mo.date_planned_start.date()
            if planned_date not in group_by_date:
                group_by_date[planned_date] = mo
            else:
                group_by_date[planned_date] |= mo
        return group_by_date

    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_from = data.get('date_from')
        date_to = data.get('date_to')
        lines = []
        mo_ids = self.env['mrp.production'].search([
            ('state','=','done'),
            ('date_planned_start', '>=', date_from),
            ('date_planned_start', '<=', date_to),
        ])
        group_by_date = self._get_group_by_planned_date(mo_ids)
        green_leaf_total = 0.0
        made_tea_total = 0.0
        electric_qty_total = 0.0
        firewood_price_total = 0.0
        firewood_qty_total = 0.0
        for planned_date, mo_ids in group_by_date.items():
            green_leaf_qty = sum(mo_ids.mapped('move_raw_ids').filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity_done'))
            made_tea_qty = sum(mo_ids.mapped('product_qty'))
            made_tea_price = made_tea_qty * sum(mo_ids.mapped('product_id.standard_price'))
            electric_qty = sum(mo_ids.mapped('costing_line_ids').filtered(lambda x: x.costing_type_id.is_electric).mapped('quantity'))
            product_id = mo_ids.mapped('costing_line_ids').filtered(lambda x: x.costing_type_id.is_material)
            is_firewood =  product_id.filtered(lambda x: x.product_id.firewood_ok)
            firewood_price = sum(rec.unit_price for rec in is_firewood)
            firewood_qty = sum(rec.quantity for rec in is_firewood)
            green_leaf_total += green_leaf_qty
            made_tea_total += made_tea_qty
            electric_qty_total += electric_qty
            firewood_price_total = firewood_price
            firewood_qty_total = firewood_qty
            out_turn = 0.0
            total_kwh = 0.0 
            total_cost = 0.0 
            if green_leaf_qty != 0:
                out_turn = made_tea_qty / green_leaf_qty * 100
            if made_tea_qty != 0:
                total_kwh = electric_qty / made_tea_qty
                total_cost = firewood_qty / made_tea_qty * firewood_price
            lines.append({
                'date': planned_date,
                'green_leafs': green_leaf_qty,
                'made_tea': made_tea_qty,
                'out_turn': out_turn,
                'electric_qty': electric_qty,
                'kwh': total_kwh,
                'firewood_qty': firewood_qty,
                'firewood_price': firewood_price,
                'firewood_cost': total_cost,
            })
        return {
            'docs' : docs,
            'lines': lines,
            'leaf_total': green_leaf_total,
            'tea_total': made_tea_total,
            'out_turn_total': int(made_tea_total / green_leaf_total * 100) if green_leaf_total != 0 else 0.0,
            'electric_total': electric_qty_total,
            'kwh_total' : electric_qty_total / made_tea_total if made_tea_total != 0 else 0.0,
            'firewood_qty_total': firewood_qty_total,
            'firewood_price_total' : firewood_price_total ,
            'firewood_cost_total': firewood_qty_total / made_tea_total * firewood_price_total if made_tea_total != 0 else 0.0 ,
        }
# access_mrp_production_wizard,access_mrp_production_wizard,model_mrp_production_wizard,base.group_user,1,1,1,1