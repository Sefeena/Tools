# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime


class QualityReportWizard(models.TransientModel):
    _name = "quality.report.wizard"

    date_from = fields.Date(string='Date from', required=True)
    date_to = fields.Date(string='Date to', required=True)
    clerk_id = fields.Many2one('res.partner', string='Clerk', domain="[('is_clerk', '=', True)]")
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    report_type = fields.Selection([('clerk', 'Responsible'), ('vehicle', 'Vehicle')], default='clerk', required=True)

    @api.onchange('report_type')
    def _onchange_vehicle(self):
        if self.report_type == 'clerk':
            self.vehicle_id = False
        if self.report_type == 'vehicle':
            self.clerk_id = False

    def action_print_report(self):
        data = {
            'date_from': self.date_from,
            'date_to': self.date_to,
            'report_type': self.report_type,
            'clerk_id': self.clerk_id.id or False,
            'vehicle_id': self.vehicle_id.id or False,
        }
        return self.env.ref('pways_collection_management.quality_sheet_report').report_action(self, data=data)

class QualitySheetReport(models.AbstractModel):
    _name = 'report.pways_collection_management.qs_report_template'

    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_from = data['date_from']
        date_to = data['date_to']
        report_type = data['report_type']
        clerk_id = data.get('clerk_id')
        vehicle_id = data.get('vehicle_id')

        domain = [('trip_id.trip_date', '>=', date_from), ('trip_id.trip_date', '<=', date_to), ('quality_type', '=', 'kgs')]
        if report_type == 'clerk' and clerk_id:
            domain.append(('trip_id.clerk_id', '=', clerk_id))
        if report_type == 'vehicle' and vehicle_id:
            domain.append(('trip_id.vehicle_id', '=', vehicle_id))
        sheet_ids = self.env['quality.sheet'].search(domain)

        # sheet_by_center = {}
        # for sheet in sheet_ids:
        #     if sheet.location_id.id in sheet_by_center:
        #         sheet_by_center[sheet.location_id.id] |= sheet
        #     else:
        #         sheet_by_center[sheet.location_id.id] = sheet
        report_lines = []

        total_daily_collection = 0.0
        total_a_bud = 0.0
        total_leaf_1 = 0.0
        total_leaf_2 = 0.0
        total_soft_bhanji = 0.0
        total_leaf_3 = 0.0
        total_hard_bhanji = 0.0
        total_looses = 0.0
        total_damage_leaf = 0.0
        total_total_good = 0.0
        total_total_bad = 0.0
        total_good_per = 0.0
        total_bad_per = 0.0

        for sheet in sheet_ids:
            # location = self.env['stock.location'].browse(location_id)
            daily_collection = sheet.daily_collection or 0.0
            a_bud = sheet.a_bud
            leaf_1 = sheet.leaf_1
            leaf_2 = sheet.leaf_2
            soft_bhanji = sheet.soft_bhanji
            leaf_3 = sheet.leaf_3
            hard_bhanji = sheet.hard_bhanji
            looses = sheet.looses
            damage_leaf = sheet.damage_leaf
            total_good = a_bud + leaf_1 + leaf_2 + soft_bhanji
            total_bad = leaf_3 + hard_bhanji + looses + damage_leaf
            good_per = daily_collection and (100 / daily_collection) * total_good or 0.0
            bad_per = daily_collection and (100 / daily_collection) * total_bad or 0.0

            total_daily_collection += daily_collection
            total_a_bud += a_bud
            total_leaf_1 += leaf_1
            total_leaf_2 += leaf_2
            total_soft_bhanji += soft_bhanji
            total_leaf_3 += leaf_3
            total_hard_bhanji += hard_bhanji
            total_looses += looses
            total_damage_leaf += damage_leaf
            total_total_good += total_good
            total_total_bad += total_bad
            total_good_per += good_per
            total_bad_per += bad_per

            report_lines.append({
                'trip': sheet.trip_id.name,
                'trip_date': sheet.trip_id.trip_date and sheet.trip_id.trip_date.strftime('%d-%m-%Y') or '',
                'collection_center': sheet.trip_id.route_id.name,
                'daily_collection': round(daily_collection, 2),
                'a_bud': round(a_bud, 2),
                'leaf_1': round(leaf_1, 2),
                'leaf_2': round(leaf_2, 2),
                'soft_bhanji': round(soft_bhanji, 2),
                'total_good': round(total_good, 2),
                'good_per': round(good_per, 2),
                'leaf_3': round(leaf_3, 2),
                'hard_bhanji': round(hard_bhanji, 2),
                'looses': round(looses, 2),
                'damage_leaf': round(damage_leaf, 2),
                'total_bad': round(total_bad, 2),
                'bad_per': round(bad_per, 2),
            })
        footer_total = {
            'total_daily_collection': round(total_daily_collection, 2),
            'total_a_bud': round(total_a_bud, 2),
            'total_leaf_1': round(total_leaf_1, 2),
            'total_leaf_2': round(total_leaf_2, 2),
            'total_soft_bhanji': round(total_soft_bhanji, 2),
            'total_leaf_3': round(total_leaf_3, 2),
            'total_hard_bhanji': round(total_hard_bhanji, 2),
            'total_looses': round(total_looses, 2),
            'total_damage_leaf': round(total_damage_leaf, 2),
            'total_total_good': round(total_total_good, 2),
            'total_total_bad': round(total_total_bad, 2),
            'total_good_per': sheet_ids and round(total_good_per / len(sheet_ids.filtered(lambda x: x.trip_id.total_net > 0)), 2) or 0.0,
            'total_bad_per': sheet_ids and round(total_bad_per / len(sheet_ids.filtered(lambda x: x.trip_id.total_net > 0)), 2) or 0.0,
        }
        return {
            'docs': docs,
            'lines': report_lines,
            'footer_total': footer_total,
        }
