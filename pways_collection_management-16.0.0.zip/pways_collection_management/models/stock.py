# -*- coding: utf-8 -*-
from odoo import fields, models, _
from odoo.exceptions import UserError


class StockMove(models.Model):
    _inherit = 'stock.move'

    pick_id = fields.Many2one('stock.picking')
    # agent_id = fields.Many2one('res.partner', related="picking_id.agent_id", store=True)

    def _get_new_picking_values(self):
        res = super(StockMove, self)._get_new_picking_values()
        if self.mapped('group_id').sale_id:
            res.update({'ntfl_type': self.mapped('group_id').sale_id.sale_type})
        return res

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    sample_move_ids = fields.One2many('stock.move', 'pick_id')
    visible_catalog = fields.Boolean(compute='compute_visible_catalog')
    # auction_request_id = fields.Many2one('auction.request')
    # agent_id = fields.Many2one('res.partner', string="Brocker/Agent", related="auction_request_id.delivery_id", store=True)

    def compute_visible_catalog(self):
        for picking in self:
            if picking.transfer_id and picking.location_id.usage == 'transit' and picking.state == 'done':
                picking.visible_catalog = True
            else:
                picking.visible_catalog = False

    def _action_done(self):
        res = super(StockPicking, self)._action_done()
        for picking in self.filtered(lambda x: x.location_dest_id.usage == 'transit' and x.state == 'done'):
            for line in picking.move_line_ids:
                if not line.product_id.sample_product_id:
                    raise UserError(_('Please set sample product.'))
                quant = self.env['stock.quant'].search([('location_id', '=', picking.location_id.id), ('product_id', '=', line.product_id.sample_product_id.id), ('lot_id.name', '=', line.lot_id.name)], limit=1)
                if not quant or quant.quantity < 1:
                    raise UserError(_('Sample product not available for the product %s ' % line.product_id.name ))
                sample_product_id = line.product_id.sample_product_id
                out_move = self.env['stock.move'].create({
                    'name': line.product_id.name,
                    'pick_id': picking.id,
                    'location_id': picking.location_id.id,
                    'location_dest_id': picking.location_dest_id.id,
                    'product_id': sample_product_id.id,
                    'product_uom': sample_product_id.uom_id.id,
                    'product_uom_qty': 1.0,
                })
                self.env['stock.move.line'].create({
                    'move_id': out_move.id,
                    'lot_id': quant.lot_id.id,
                    'qty_done': 1.0,
                    'product_id': sample_product_id.id,
                    'product_uom_id': sample_product_id.uom_id.id,
                    'location_id': picking.location_id.id,
                    'location_dest_id': picking.location_dest_id.id,
                })
                in_picking = line.move_id.move_dest_ids.mapped('picking_id')
                in_move = self.env['stock.move'].create({
                    'name': line.product_id.name,
                    'pick_id': in_picking.id,
                    'location_id': in_picking.location_id.id,
                    'location_dest_id': in_picking.location_dest_id.id,
                    'product_id': sample_product_id.id,
                    'product_uom': sample_product_id.uom_id.id,
                    'product_uom_qty': 1.0,
                    'move_orig_ids': [(4, out_move.id, 0)],
                })
                out_move._action_done()
                quant = self.env['stock.quant'].search([('location_id', '=', picking.location_dest_id.id), ('product_id', '=', line.product_id.sample_product_id.id), ('lot_id.name', '=', line.lot_id.name)], limit=1)
                self.env['stock.move.line'].create({
                    'move_id': in_move.id,
                    'lot_id': quant.lot_id.id,
                    'product_id': sample_product_id.id,
                    'product_uom_id': sample_product_id.uom_id.id,
                    'location_id': in_picking.location_id.id,
                    'location_dest_id': in_picking.location_dest_id.id,
                })
                # in_move._action_confirm()
                # in_move._action_assign()
        for picking in self.filtered(lambda x: x.sample_move_ids and x.location_id.usage == 'transit'):
            for move in picking.sample_move_ids:
                move.write({'quantity_done': 1.0})
            picking.sample_move_ids._action_done()
        return res


    def get_report_data(self):
        data = []
        picking_id = self.state == 'done' and self.picking_type_code == 'outgoing'
        if picking_id:
            sam_move_line_ids = self.mapped('sample_move_ids').mapped('move_line_ids')
            for line in self.mapped('move_line_ids'):
                fil_sam_lines = sam_move_line_ids.filtered(lambda x: x.lot_id.name == line.lot_id.name)
                sample_qty = sum(fil_sam_lines.mapped('qty_done'))
                total = line.qty_done * line.product_id.uom_id.factor_inv
                data.append({
                    'lot_id': line.lot_id.packaging_ref.split('/')[-1:][0] if line.lot_id.packaging_ref else '',
                    'product_id': line.product_id.display_name if line.product_id else False,
                    'qty_done': line.qty_done,
                    'net_wt': round(line.product_id.uom_id.factor_inv, 2) if line.product_id else 0.0,
                    'sample_qty': round(sample_qty * line.product_id.sample_product_id.uom_id.factor_inv, 2),
                    'total_wt': round(total, 2) if total else 0.0,
                    'prod_date': line.lot_id.create_date if line.lot_id else False,
                })
        return data

    def get_report_data_line(self):
        data_line = []
        for line in self.mapped('move_line_ids'):
            total = line.qty_done * line.product_id.uom_id.factor_inv
            data_line.append({
                'lot_id': line.lot_id.name if line.lot_id else '',
                'product_id': line.product_id.display_name if line.product_id else False,
                'qty_done': line.qty_done,
                'net_wt': round(line.product_id.uom_id.factor_inv, 2) if line.product_id else 0.0,
                'total_wt': round(total, 2) if total else 0.0,
                'prod_date': line.lot_id.create_date if line.lot_id else False,
            })
        return data_line


    def get_report_data_private(self):
        data = []
        sale_id = self.group_id.sale_id
        request_id = sale_id.request_id
        dispatch_type = {'auction': 'For Auction', 'private': 'For Private', 'other': 'Other'}
        grade_list = {'ctc_tea': 'CTC TEA', 'orthodox_tea': 'Orthodox TEA'}
        if sale_id and request_id and request_id.dispatch_type == 'private' and self.state == 'done':
            data.append({
                'driver_name': request_id.driver_name or '',
                'phone': request_id.phone or '',
                'driver_id': request_id.driver_id or '',
                'warehouse_id': request_id.warehouse_id.display_name or '',
                'wr_street_name': request_id.warehouse_id.partner_id.street_name or '',
                'wr_street_number': request_id.warehouse_id.partner_id.street_name or '',
                'wr_street2': request_id.warehouse_id.partner_id.street2 or '',
                'wr_city': request_id.warehouse_id.partner_id.city or '',
                'wr_state_id': request_id.warehouse_id.partner_id.state_id.display_name or '', 
                'wr_country_id': request_id.warehouse_id.partner_id.country_id.display_name or '',
                'dispatch_type': dispatch_type.get(request_id.dispatch_type) or '',
                'grade': grade_list.get(request_id.grade) or '',
                'trailer_no': request_id.trailer_no or '',
                'vehicle_no': request_id.vehicle_no or '',
                'transfer_id': request_id.transporter_id.display_name or '',
                'street_name': request_id.transporter_id.street_name or '',
                'street_number': request_id.transporter_id.street_number or '',
                'street_number2': request_id.transporter_id.street_number2 or '',
                'street2': request_id.transporter_id.street2 or '',
                'city': request_id.transporter_id.city or '',
                'state_id': request_id.transporter_id.state_id.display_name or '', 
                'country_id': request_id.transporter_id.country_id.display_name or '',
            })
        return data

# class StockTransfer(models.Model):
#     _inherit = 'stock.transfer'

    # auction_request_id = fields.Many2one('auction.request')


# class StockWarehouse(models.Model):
#     _inherit = 'stock.warehouse'

#     is_auction = fields.Boolean(string='Is Auction')

# class StockMoveLineInherit(models.Model):
#     _inherit = 'stock.move.line'

    # agent_id = fields.Many2one('res.partner', related="picking_id.agent_id", store=True)

