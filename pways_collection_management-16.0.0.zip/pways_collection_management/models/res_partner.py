# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    farmer_id = fields.Many2one('farmer.registration', string="Out Grower Registration")
    is_clerk = fields.Boolean(string="Responsible")
    is_farmer = fields.Boolean(string="Out Grower")
    # is_agent = fields.Boolean(string="Tea Broker")
    national_id =  fields.Char(related='farmer_id.national_id', store=True)
    code =  fields.Char(related='farmer_id.code', store=True)
    uuid_random =  fields.Char(related='farmer_id.uuid_random', store=True)
    clark_id = fields.Many2one("res.partner", "Responsible")
    clark_mobile_user    = fields.Char(string="Mobile User")
    clark_mobile_password = fields.Char(string="Mobile Password")
    farm_ids = fields.One2many('farm.info', 'farm_partner_id', string="Farms ids")
    bank_ac_no = fields.Char("Bank Account No")
    nhif_deduction = fields.Boolean(string='NHIF Deduction')
    nhif_amount = fields.Float(string='NHIF Amount')
    csr_deduction = fields.Boolean(string='Fertilizer Deduction')
    csr_amount = fields.Float(string='Fertilizer Amount')

    def name_get(self):
        res_list = []
        for rec in self:
            rec_name = rec.name
            if rec.name and rec.code:
                rec_name = rec.code +' - '+ rec.name
            if rec.name and rec.national_id:
                rec_name = rec_name +' - '+ rec.national_id
            res_list.append((rec.id, rec_name))
        return res_list

