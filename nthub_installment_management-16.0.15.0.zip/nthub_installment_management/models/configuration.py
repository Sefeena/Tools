# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    #installment required fields

    max_duration = fields.Float(string=_('Max Duration'), config_parameter='nthub_installment_management.max_duration')
    annual_rate_percentage = fields.Float(string=_('Annual Rate Percentage'), config_parameter='nthub_installment_management.annual_rate_percentage')
    administrative_expenses = fields.Float(string=_('Administrative Expenses Percentage'), config_parameter='nthub_installment_management.administrative_expenses')
    down_payment = fields.Float(string=_('Down Payment Percentage'), config_parameter='nthub_installment_management.down_payment')
    delay_penalty = fields.Float(string=_('Delay Penalty Percentage'), config_parameter='nthub_installment_management.delay_penalty')
    delay_process = fields.Float(string=_('Delay Penalty Process'), config_parameter='nthub_installment_management.delay_process')

    #needed documents

    nid = fields.Boolean(string=_('Nid'), config_parameter='nthub_installment_management.nid')
    salary_components = fields.Boolean(string=_('Salary Components'), config_parameter='nthub_installment_management.salary_components')
    bank_statement = fields.Boolean(string=_('Bank Statement'), config_parameter='nthub_installment_management.bank_statement')
    bank_rate_letter = fields.Boolean(string=_('Bank Rate Letter'), config_parameter='nthub_installment_management.bank_rate_letter')
    rental_contract = fields.Boolean(string=_('Rental Contract'), config_parameter='nthub_installment_management.rental_contract')
    ownership_contract = fields.Boolean(string=_('Ownership Contract'), config_parameter='nthub_installment_management.ownership_contract')

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.max_duration",
                                                         self.max_duration)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.annual_rate_percentage",
                                                         self.annual_rate_percentage)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.administrative_expenses",
                                                         self.administrative_expenses)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.down_payment",
                                                         self.down_payment)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.delay_penalty",
                                                         self.delay_penalty)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.delay_process",
                                                         self.delay_process)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.nid",
                                                         self.nid)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.salary_components",
                                                         self.salary_components)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.bank_statement",
                                                         self.bank_statement)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.bank_rate_letter",
                                                         self.bank_rate_letter)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.rental_contract",
                                                         self.rental_contract)
        self.env['ir.config_parameter'].sudo().set_param("nthub_installment_management.ownership_contract",
                                                         self.ownership_contract)

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        res['max_duration'] = float(get_param('nthub_installment_management.max_duration'))
        res['annual_rate_percentage'] = float(get_param('nthub_installment_management.annual_rate_percentage'))
        res['administrative_expenses'] = float(get_param('nthub_installment_management.administrative_expenses'))
        res['down_payment'] = float(get_param('nthub_installment_management.down_payment'))
        res['delay_penalty'] = float(get_param('nthub_installment_management.delay_penalty'))
        res['delay_process'] = float(get_param('nthub_installment_management.delay_process'))
        res['nid'] = get_param('nthub_installment_management.nid')
        res['salary_components'] = get_param('nthub_installment_management.salary_components')
        res['bank_statement'] = get_param('nthub_installment_management.bank_statement')
        res['bank_rate_letter'] = get_param('nthub_installment_management.bank_rate_letter')
        res['rental_contract'] = get_param('nthub_installment_management.rental_contract')
        res['ownership_contract'] = get_param('nthub_installment_management.ownership_contract')
        return res


