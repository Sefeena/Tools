# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class PackagingTemplate(models.Model):
    _name = 'packaging.order.template'
    _description = 'Packaging Order Template'

    name = fields.Char(required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    product_uom_id = fields.Many2one(related='product_id.uom_id')
    packaging_order_line = fields.One2many('packaging.order.template.line', 'template_id', string="Packaging Lines")
    location_id = fields.Many2one('stock.location', string='Source', domain="[('is_collection_center', '=', False)]")
    location_dest_id = fields.Many2one('stock.location', string='Destination', domain="[('is_collection_center', '=', False)]")
    packing_type = fields.Selection([('pos', 'POS'), ('auction', 'Auction'), ('export', 'Export'), ('local', 'Local'), ('other', 'Other')], string='Packing Type', default='local')
    packing_total_qty = fields.Float(string='Total Qty', compute="_compute_packing_total_qty", digits='Product Unit of Measure')

    @api.depends('packaging_order_line.product_qty')
    def _compute_packing_total_qty(self):
        for rec in self:
            total_qty = 0.0
            for line in rec.packaging_order_line:
                total_qty += line.demand_qty
            rec.packing_total_qty = total_qty


class PackagingTemplate(models.Model):
    _inherit = 'packaging.order.template'

    costing_line_ids = fields.One2many('costing.line', 'packaging_template_id', string="Costing lines")
    total_amount = fields.Float(string='Total Costing', compute="_compute_total_costing")

    @api.depends('costing_line_ids.price_subtotal', 'costing_line_ids.quantity', 'costing_line_ids.unit_price')
    def _compute_total_costing(self):
        for rec in self:
            total_costing_amount = 0.0
            for line in rec.costing_line_ids:
                total_costing_amount += line.price_subtotal
            rec.total_amount = total_costing_amount

class PackagingTemplateLine(models.Model):
    _name = 'packaging.order.template.line'
    _description = 'Packaging Order Template Lines'

    product_id = fields.Many2one('product.product', string="Product")
    product_uom_id = fields.Many2one(related='product_id.uom_id')
    product_qty = fields.Float(string='Quantity', default=1.0)
    demand_qty = fields.Float('Demand', compute="_compute_total_demand_qty", digits='Product Unit of Measure')
    template_id = fields.Many2one('packaging.order.template')

    def _compute_total_demand_qty(self):
        for line in self:
            if line.template_id.product_uom_id.category_id == line.product_uom_id.category_id:
                line.demand_qty = line.product_uom_id._compute_quantity(line.product_qty,line.template_id.product_uom_id)
            else:
                line.demand_qty = 0
