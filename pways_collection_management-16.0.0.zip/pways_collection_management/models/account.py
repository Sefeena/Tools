# -*- coding: utf-8 -*-

from odoo import models,fields,api

class AccountBankStatementLine(models.Model):
    _inherit = "account.bank.statement.line"

    property_account_expense_id = fields.Many2one('account.account', 'Expense Account', domain="[]")

    def _seek_for_lines(self, counterpart_account_id=None):
        accounts = super(AccountBankStatementLine, self)._seek_for_lines()
        if self.property_account_expense_id:
            accounts[1].write({'account_id': self.property_account_expense_id.id})
        return accounts