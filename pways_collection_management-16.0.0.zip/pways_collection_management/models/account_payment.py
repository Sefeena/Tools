# -*- coding: utf-8 -*-
from odoo import api, fields, models


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    farmer_advance = fields.Boolean('Out Grower Advance')
    loan_id = fields.Many2one('out.grower.loan', "loan", readonly=True, states={'draft': [('readonly', False)]})
