# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class SortingTemplate(models.Model):
    _name = 'sorting.template'
    _description = 'Sorting Template'

    name = fields.Char(required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    product_uom_id = fields.Many2one(related='product_id.uom_id')
    sorting_line = fields.One2many('sorting.template.line', 'template_id', string="Sorting Lines")
    location_id = fields.Many2one('stock.location', string='Source', domain="[('is_collection_center', '=', False)]")
    location_dest_id = fields.Many2one('stock.location', string='Destination', domain="[('is_collection_center', '=', False)]")
    sorting_total_qty = fields.Float(string='Total Qty', compute="_compute_sorting_total_qty", digits='Product Unit of Measure')

    @api.depends('sorting_line.product_qty')
    def _compute_sorting_total_qty(self):
        for rec in self:
            total_qty = 0.0
            for line in rec.sorting_line:
                total_qty += line.demand_qty
            rec.sorting_total_qty = total_qty

class SortingTemplateLine(models.Model):
    _name = 'sorting.template.line'
    _description = 'Sorting Template Lines'

    product_id = fields.Many2one('product.product', string="Product")
    product_uom_id = fields.Many2one(related='product_id.uom_id')
    demand_qty = fields.Float('Demand', compute="_compute_total_demand_qty", digits='Product Unit of Measure')
    product_qty = fields.Float(string='Quantity', default=1.0)
    template_id = fields.Many2one('sorting.template')

    def _compute_total_demand_qty(self):
        for line in self:
            if line.template_id.product_uom_id.category_id == line.product_uom_id.category_id:
                line.demand_qty = line.product_uom_id._compute_quantity(line.product_qty,line.template_id.product_uom_id)
            else:
                line.demand_qty = 0
