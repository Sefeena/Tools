from odoo import models, fields, api, _

class FleetInvoiceWizard(models.TransientModel):
    _name = 'fleet.invoice.wizard'

    date_from = fields.Date(string="Date From")
    date_to = fields.Date(string="Date To")
    vehicle_ids = fields.Many2many('fleet.vehicle','fleet_rel_invoice_wizard','vehicle_id','fleet_id')

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'vehicle_ids': self.vehicle_ids.ids,
            }
        return self.env.ref('pways_collection_management.fleet_invoice_report').report_action(self, data=data)


class FleetTemplateReport(models.AbstractModel):
    _name = 'report.pways_collection_management.fleet_template'

    def _prepare_report_lines(self,vehicle_ids):
        values = []
        for vehicle in vehicle_ids:
            vehicle = self.env['fleet.vehicle'].browse(vehicle)
            res = {
              'vehicle':vehicle.name,
              'vendor': '',
              'account_lines': [{
                       'bill_date': '',
                       'bill_no': '',
                       'gateway_no': '',
                       'trip':'',
                       'weight':0,
                       'rate':'',
                       'total': '',
                       }]

            }
            values.append(res)
        return values



    def get_domain(self, data):
        domain = []
        # route_id = self.env['account.move'].browse(data.get('route_id'))
        if data.get('date_from') and data.get('date_to'):
             domain += [('weighment_date', '>=', data.get('date_from')), ('weighment_date', '<=', data.get('date_to'))]
        return domain


    @api.model
    def _get_report_values(self, docids, data=None):
        # import pdb;pdb.set_trace();
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        vehicle_ids = data.get('vehicle_ids')
        domain = self.get_domain(data)
        weighment_ids = self.env['grower.weighment'].search(domain)
        lines = self._prepare_report_lines(vehicle_ids)
        


        # domain = self.get_domain(data)
        # location = data.get('location_id')
        # weighment_ids = self.env['grower.weighment'].search(domain)
        # lines = self._prepare_report_lines(weighment_ids, location)
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date_from' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'lines': lines,
        }  