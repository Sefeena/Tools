# -*- coding: utf-8 -*-

from odoo import fields, models, _

class VehicleType(models.Model):
    _name = "vehicle.type.outgrower"

    name = fields.Char('Name', required=True, copy=False)

class FuelType(models.Model):
    _name = "fuel.type.outgrower"

    name = fields.Char('Name', required=True, copy=False)

class FleetVehicle(models.Model):
    _inherit = "fleet.vehicle"

    fuel_type_id = fields.Many2one("fuel.type.outgrower", string="Fuel Type")
    vehicle_capacity = fields.Char(string="Vehicle Capacity", copy=False)


class FleetVehicleModel(models.Model):
    _inherit = 'fleet.vehicle.model'

    vehicle_type_id = fields.Many2one("vehicle.type.outgrower", string="Vehicle Type")