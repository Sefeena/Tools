# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class MiscellaneousBillWizard(models.TransientModel):
    _name = "miscellaneous.bill.wizard"
    _description = "Miscellaneous Bill Wizard"

    def action_create_bill(self):
        gate_weighment_ids = self.env['gate.weighment'].browse(self.env.context.get('active_ids'))
        if gate_weighment_ids and any(not w.is_for_billing for w in gate_weighment_ids):
            raise ValidationError(_('You can only create bill for allowed is billing routes!'))
        if gate_weighment_ids and any(w.bill_created for w in gate_weighment_ids):
            raise ValidationError(_('Bill already created for these weighments!'))

        partner_ids = gate_weighment_ids.mapped('partner_id')

        vendor_journal_id = self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.vendor_journal_id') or False
        if not vendor_journal_id:
            raise UserError(_("Please configure journal in account settings."))
        bill_ids = self.env['account.move']
        product_id = self.env.ref('pways_collection_management.transport_rate_product')
        if not product_id:
            raise ValidationError(_('Transport Rate product not found'))
        for partner in partner_ids:
            weigh_ids = gate_weighment_ids.filtered(lambda x: x.partner_id.id == partner.id)
            bill_id = self.env['account.move'].create({
                'move_type': 'in_invoice',
                'invoice_origin': ', '.join(weigh_ids.mapped('weighment_no')),
                'invoice_user_id': self.env.user.id,
                'partner_id': partner.id,
                'currency_id': self.env.user.company_id.currency_id.id,
                'journal_id': int(vendor_journal_id),
                'payment_reference': ', '.join(weigh_ids.mapped('weighment_no')),
                'ntfl_type': 'firewood',
                'invoice_line_ids': [(0, 0, {
                    'name': 'Miscellaneous Bill',
                    'product_id': product_id.id,
                    'price_unit': product_id.lst_price,
                    'account_id': product_id.property_account_income_id.id if product_id.property_account_income_id
                    else product_id.categ_id.property_account_income_categ_id.id,
                    'tax_ids': [(6, 0, [])],
                    'quantity': sum([int(qty) for qty in weigh_ids.mapped('boiler_cubic')]),
                })],
            })
            bill_ids |= bill_id
            weigh_ids.write({'bill_created': True})

        return {
            'name': _('Transfer Bills'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'views': [(self.env.ref('account.view_move_tree').id, 'tree'), (False, 'form')],
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', bill_ids.ids)],
        }
