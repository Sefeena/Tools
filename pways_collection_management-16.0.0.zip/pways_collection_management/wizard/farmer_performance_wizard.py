from odoo import models, fields, api, _
import calendar
import datetime
li = [(str(i),calendar.month_name[i]) for i in range(1,12)]

class Year(models.Model):
    _name = 'year.year'

    name = fields.Char('Year',required=True)

class FfPerfromanceWizard(models.TransientModel):
    _name = 'ff.performance.wizard'

    type_report = fields.Selection([('year','Yearly'),('custom','Monthly')], string="Duration", default='custom', required=True)
    farmer_id = fields.Many2one('res.partner', string="Out Grower", domain=[('is_farmer', '=', True)], required=True)
    year = fields.Many2one('year.year',string="Year")
    month = fields.Selection(li, string="Month")
    date_from = fields.Date(string="Date From")
    date_to = fields.Date(string="Date To")

    @api.onchange('month')
    def onchange_month(self):
        if self.month:
            from calendar import monthrange
            from datetime import date
            current_year = fields.Datetime.today().year
            mdays = monthrange(current_year,int(self.month))[1]
            self.date_from = date(current_year,int(self.month), 1)
            self.date_to = date(current_year,int(self.month),mdays)

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'type_report': self.type_report,
            'farmer_id': self.farmer_id.id,
            'year': self.year.id,
        }
        return self.env.ref('pways_collection_management.ff_performance_report').report_action(self, data=data)


class FfPerfromanceWizardReport(models.AbstractModel):
    _name = 'report.pways_collection_management.ff_performance_template'

    def _prepare_report_yearly_lines(self, weighment_ids,year):
        vals = []
        group_by_location = {}
        # current_year = fields.Datetime.today().year
        weighment_line_ids =  weighment_ids.mapped('weighment_line_ids')
        for line in weighment_line_ids:
            if line.weighment_id.weighment_date.year == int(year):
                Month = calendar.month_name[line.weighment_id.weighment_date.month]
                if Month in group_by_location:
                    group_by_location[Month] |= line
                else:
                  group_by_location[Month] = line
        for month, lines in group_by_location.items():
            net_weight = sum(lines.mapped('net'))
            vals.append({
                 'month': month,
                 'net_weight': round(net_weight, 2) or 0.0,
            })

        return vals

    def _prepare_report_lines(self, weighment_ids):
        vals = []
        group_by_location = {}
        weighment_line_ids =  weighment_ids.mapped('weighment_line_ids')
        for line in weighment_line_ids:
            if (line.weighment_id.weighment_date) in group_by_location:
                group_by_location[(line.weighment_id.weighment_date)] |= line
            else:
              group_by_location[(line.weighment_id.weighment_date)] = line
        for weighment_date, lines in group_by_location.items():
            net_weight = sum(lines.mapped('net'))
            vals.append({
                 'date': weighment_date,
                 'net_weight': round(net_weight, 2) or 0.0,
            })

        return vals

    def get_domain(self, data):
        domain = []
        farmer = self.env['res.partner'].browse(data.get('farmer_id'))
        if data.get('type_report') == 'custom':
            if data.get('date_from') and data.get('date_to'):
                 domain += [('weighment_date', '>=', data.get('date_from')), ('weighment_date', '<=', data.get('date_to'))]
        if farmer:
            domain += [('farmer_id', '=', farmer.id)]
        return domain


    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        farmer_name = self.env['res.partner'].browse(data.get('farmer_id'))
        year = self.env['year.year'].browse(data.get('year'))
        domain = self.get_domain(data)
        weighment_ids = self.env['grower.weighment'].search(domain)
        if data.get('type_report') == 'custom':
            lines = self._prepare_report_lines(weighment_ids)
        else:
            lines = self._prepare_report_yearly_lines(weighment_ids,year.name)

        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date_from' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'type_report': data.get('type_report'),
            'farmer_name': farmer_name.display_name,
            'lines':lines,
            'year': year.name,
        }