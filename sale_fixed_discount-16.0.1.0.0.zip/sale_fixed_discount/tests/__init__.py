from . import test_sale_fixed_discount
