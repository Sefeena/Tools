# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class PackingTemplate(models.Model):
    _name = 'packing.template'
    _description = 'Packing Template'

    name = fields.Char(required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    packing_line = fields.One2many('packing.template.line', 'template_id', string="Packing Lines")


class PackingTemplateLine(models.Model):
    _name = 'packing.template.line'
    _description = 'Packing Template Lines'

    product_id = fields.Many2one('product.product', string="Product")
    template_id = fields.Many2one('packing.template')
