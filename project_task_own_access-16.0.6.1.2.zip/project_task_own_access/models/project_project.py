# -*- coding: utf-8 -*-

from odoo import models, fields, api , _
from odoo.exceptions import AccessError, MissingError

class ProjectProject(models.Model):
    _inherit = "project.project"

    custom_user_prj_ids = fields.Many2many(
        'res.users',
        'custom_project_users_rel_probc',
        string="Access Limited Users",
        help="Only applicable to a limited group of users."
    )

    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        if not self.env.context.get('do_not_include'):
            restricted_projects = self.env.user.has_group('project_task_own_access.custom_group_restricted_project_task')
            if restricted_projects:
                args = [('custom_user_prj_ids','in',self.env.user.id)] + list(args)
        return super(ProjectProject, self)._search(args, offset, limit, order, count, access_rights_uid)

    def read(self, fields=None, load='_classic_read'):
        projects = super(ProjectProject, self).read(fields=fields, load=load)
        if len(projects) == 1:
            if self.env.user.has_group("project_task_own_access.custom_group_restricted_project_task"):
                project_restrict_access_config = self.env['project.project'].sudo().search([('custom_user_prj_ids', 'in', self.env.user.ids)])
                if project_restrict_access_config:
                    for project in projects:
                        if project.get('id') and project.get('id') not in project_restrict_access_config.ids:
                            raise AccessError(_("You don't have the access!"))
        return projects

