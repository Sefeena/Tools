# -*- encoding: utf-8 -*-
##############################################################################
#
# Cron QuoTech
# Copyright (C) 2021 (https://cronquotech.odoo.com)
# 
##############################################################################

from . import wizard

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: