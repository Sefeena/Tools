# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class NtflYear(models.Model):
    _name = 'ntfl.year'

    name = fields.Char('Year', required=True, copy=False)

    @api.constrains('name')
    def _check_accounting_year(self):
        if not self.name.isnumeric() or self.search_count([('name', '=', self.name)]) > 1:
            raise ValidationError(_('Please enter valid year'))