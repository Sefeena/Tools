# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import date, datetime
from odoo.exceptions import UserError, Warning
import warnings


class InstallmentPayment(models.TransientModel):
    _name = 'installment.payment'
    _description = 'Installment Payment'

    customer_id = fields.Many2one('installment.customer', string=_('Customer'))
    installment_ids = fields.Many2many('installment.installment', string=_('Installment'), compute='compute_installment_id')
    installment_id = fields.Many2one('installment.installment', string=_('Installment'))
    payment_date = fields.Date(string=_('Payment Date'), default=fields.Date.context_today)
    amount = fields.Float(string=_('Amount'))
    delay_amount = fields.Float(string=_('Delay Amount'), compute='get_delay_amount', store=True)
    delay = fields.Boolean(string=_('Delay'), compute='get_delay_amount', store=True)

    def action_done(self):
        records = self.env['installment.installment.line'].search(
            [('installment_id', '=', self.installment_id.id), ('installment_id.state', '=', 'running'),
             ('installment_id.customer_id', '=', self.customer_id.id),
             ('paid', '=', False)], limit=1)
        if records:
            for rec in records:
                if self.amount > rec.installment_id.balance_amount:
                    raise UserError(
                        _("paid amount must be =  %s.", rec.installment_id.balance_amount))
                if self.amount > 0.0:
                    rec.write({'payment_amount': self.amount})
                    rec.write({'paid': True})
                    rec.write({'payment_date': self.payment_date})
                if self.delay:
                    rec.write({'delay_amount': self.delay_amount})
                if rec.installment_id.balance_amount == 0:
                    rec.installment_id.state = 'finished'
        data = {
            # 'model': 'sale.contract.wizard',
            'form': self.read()[0]

        }
        return self.env.ref('nthub_installment_management.pay_wizard_reports').report_action(self, data=data)

    @api.depends('installment_id', 'customer_id',)
    def get_delay_amount(self):
        records = self.env['installment.installment.line'].search(
            [('installment_id', '=', self.installment_id.id), ('installment_id.state', '=', 'running'),
             ('installment_id.customer_id', '=', self.customer_id.id),
             ('date', '<', fields.Date.today()), ('paid', '=', False)], limit=1)
        if records:
            for rec in records:
                d1 = datetime.strptime(str(self.payment_date), '%Y-%m-%d')
                d2 = datetime.strptime(str(rec.date), '%Y-%m-%d')
                d3 = d1 - d2
                d4 = int(d3.days)
                d5 = float(self.env['ir.config_parameter'].sudo().get_param('nthub_installment_management.delay_process'))
                d6 = float(self.env['ir.config_parameter'].sudo().get_param('nthub_installment_management.delay_penalty'))
                print('d4', d4)
                print('d5', d5)
                if d4 > d5:
                    self.delay_amount = (d6 * rec.amount)
                    print('self.delay_amount', self.delay_amount)
                    self.delay = True
                else:
                    self.delay = False
                    self.delay_amount = 0.0
        else:
            self.delay = False
            self.delay_amount = 0.0

    @api.depends('customer_id')
    def compute_installment_id(self):
        self.installment_ids = self.env['installment.installment'].search(
            [('customer_id', '=', self.customer_id.id), ('state', '=', 'running'), ('balance_amount', '!=', 0.0)])




