# -*- coding: utf-8 -*-
from odoo import fields, models, api, tools, _
import requests
import json
import logging
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError
_logger = logging.getLogger(__name__)

class Mobireach(models.Model):
    _name = "smsleopard.log"
    _description = "Smsleopard Log"

    def auto_remove_smsleopard_log(self):
        date = fields.Datetime.now() + timedelta(days=-1)
        smsleopard_ids = self.env['smsleopard.log'].search([('create_date', '<', date)])
        smsleopard_ids.unlink()
        return True

    registration_id = fields.Many2one('farmer.registration', string="Farmer Registration")
    smsleopard_number = fields.Char(string="Number")
    massage_id = fields.Char(string="Message id")
    message = fields.Char(string="Status Text")
    status = fields.Char(string="Status")
    success = fields.Char(string="Success")

class Partner(models.Model):
    _inherit = "res.partner"

    send_sms = fields.Boolean(string="Send Sms")

class FarmerRegistration(models.Model):
    _inherit = 'farmer.registration'

    def _get_message(self):
        message = " "
        template = self.env.ref('pways_collection_management.sms_template_smsleopard', raise_if_not_found=False)
        if template and template.body_html:
            template_body = template._render_template(template.body_html, 'farmer.registration', self.ids)
            message = tools.html2plaintext(template_body.get(self.id)).replace("*", "")
        return message 

    def _prepare_url(self):
        smsleopard_url = 'https://api.smsleopard.com/v1/sms/send?'
        company_id = self.env.company
        get_message = self._get_message()
        full_url = ''
        if not get_message:
            raise ValidationError(_("No message found.."))
        if not company_id.source or not company_id.source:
            raise ValidationError(_("Please set smsleopard configureration in compnay then after send sms...!"))
        if get_message and self.mobile and company_id.source:
            full_url = smsleopard_url+'message='+get_message+'&destination='+self.mobile+'&source='+company_id.source
        return full_url

    def smsleopard_log_create(self, values):
        recipients = values.get('recipients')
        message_id = ' '
        status = ' '
        if isinstance(recipients, list):
            message_id = recipients[0].get('id') if recipients[0] and recipients[0].get('id') else ' '
            status = recipients[0].get('status') if recipients[0] and recipients[0].get('status') else ' '
        log_id = self.env['smsleopard.log'].create({
            'success' : values.get('success', False),
            'registration_id' : self.id,
            'smsleopard_number' : self.mobile,
            'massage_id' : message_id,
            'message' : values.get('message', ' '),
            'status' : status,
        })
        return log_id

    def button_registered(self):
        res = super(FarmerRegistration, self).button_registered()
        if not self.env.user.has_group('pways_collection_management.group_registration_send_sms'):
            return res
        url = self._prepare_url()
        company_id = self.env.company
        response = requests.get(url, auth=(company_id.account_id, company_id.secret))
        log_id = self.smsleopard_log_create(json.loads(response.text))
        try:
            if response.status_code not in [200, 201]:
                _logger.info("Wrong Data Found {0}".format(response.text))
            else:
                _logger.info("Message Has bine send {0}".format(response.text))
        except Exception as e:
            _logger.info("RESPONCE IS: {0}".format(e))
        return res
