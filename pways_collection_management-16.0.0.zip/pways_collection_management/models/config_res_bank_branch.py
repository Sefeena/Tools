# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class ResBank(models.Model):
    _inherit = 'res.bank'
    
    branch_ids = fields.One2many('res.bank.branch', 'bank_id', string="Branch")
    swift_code = fields.Char(string="Swift Code")
    iban_no = fields.Char(string="IBAN No")
    bsb_no = fields.Char(string="BSB Number")
    ifsc_code = fields.Char(string="IFSC Code")

class ResBankBranch(models.Model):
    _name = 'res.bank.branch'
    _description = "Branch"
    _rec_name = 'branch_name'

    bank_id = fields.Many2one('res.bank')
    branch_name = fields.Char(string="Branch Name", required=True)
    branch_code = fields.Char(string="Branch Code", required=True)
    street = fields.Char(string='Street')
    street2 = fields.Char(string='Street2')
    zip = fields.Char(string='Zip')
    city = fields.Char(string='City')
    state_id = fields.Many2one("res.country.state", string='State')
    country_id = fields.Many2one('res.country', string='Country')
    ifsc_code = fields.Char(string="IFSC Code",required=True)
    swift_code = fields.Char(string="Swift Code", required=True)
    iban_no = fields.Char(string="IBAN No")
    bsb_no = fields.Char(string="BSB Number")
    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone")

class ResPartnerBank(models.Model):
    _inherit = 'res.partner.bank'

    branch_id = fields.Many2one('res.bank.branch',string="Branch")
    farm_id = fields.Many2one('farm.info', string="Farm")
    location_id = fields.Many2one('stock.location', copy=False, string="Collection Center")
    is_active = fields.Boolean('Active Bank Ac')

    def unlink(self):
        raise ValidationError(_('You cannot delete bank.'))

    @api.constrains('is_active')
    def _check_multi_active(self):
        for acc in self:
            if acc.farm_id and self.search_count([('farm_id', '=', acc.farm_id.id), ('is_active', '=', True)]) > 1:
                raise ValidationError(_('You cannot activate more than one account for same farm.'))

    def name_get(self):
        res_list = []
        for rec in self:
            rec_name = rec.acc_number
            if rec.acc_number and rec.bank_name:
                rec_name = rec.acc_number +' - '+ rec.bank_name
            res_list.append((rec.id, rec_name))
        return res_list

class FarmerBank(models.Model):
    _name = 'farmer.bank'

    acc_holder_number = fields.Char(string="Account Number")
    acc_holder_name = fields.Char(string="Account Holder Name")
    bank_id = fields.Many2one('res.bank', string="Bank")
    branch_id = fields.Many2one('res.bank.branch', string="Branch Name", domain="[('bank_id', '=', bank_id)]")
    farm_id = fields.Many2one('farm.info', string="Farm")