# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    code = fields.Selection(selection_add=[
        ('packaging_order', 'Packaging Orders')
    ], ondelete={'packaging_order': 'cascade'})

class StockLocation(models.Model):
    _inherit = 'stock.location'

    usage = fields.Selection(selection_add=[
        ('packaging_order', 'Packaging Order')
    ], ondelete={'packaging_order': 'cascade'})


class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    packaging_order_location_id = fields.Many2one('stock.location', string='Packaging Orders Location', domain="[('usage', '=', 'packaging_order')]")
    is_packaging_order = fields.Boolean()
    packaging_order_type_id = fields.Many2one(
        'stock.picking.type', 'Packaging Orders Operation Type',
        domain="[('code', '=', 'packaging_order'), ('company_id', '=', company_id)]", check_company=True)

    def _get_sequence_values(self):
        values = super(StockWarehouse, self)._get_sequence_values()
        values.update({
            'packaging_order_type_id': {'name': self.name + ' ' + _('Sequence Packaging Orders'), 'prefix': self.code + '/SRT/', 'padding': 5, 'company_id': self.company_id.id},
        })
        return values

    def _get_picking_type_update_values(self):
        data = super(StockWarehouse, self)._get_picking_type_update_values()
        data.update({
            'packaging_order_type_id': {
                'active': True,
                'default_location_src_id': self.lot_stock_id.id,
                'default_location_dest_id': self.lot_stock_id.id,
            },
        })
        return data

    def _get_picking_type_create_values(self, max_sequence):
        data, next_sequence = super(StockWarehouse, self)._get_picking_type_create_values(max_sequence)
        data.update({
            'packaging_order_type_id': {
                'name': _('Packaging Orders'),
                'code': 'packaging_order',
                'sequence': next_sequence + 2,
                'sequence_code': 'SRT',
                'company_id': self.company_id.id,
            },
        })
        return data, max_sequence + 4

    # @api.model
    # def create(self, vals):
    #     res = super(StockWarehouse, self).create(vals)
    #     for location in self.env['stock.location'].search([]):
    #         if location.warehouse_id.id == res.id and not res.is_sorting:
    #             location.write({'active': False})
    #     return res

class StockMove(models.Model):
    _inherit = 'stock.move'

    packaging_order_id = fields.Many2one('packaging.order', 'Packaging Order')
    consume_packaging_order_id =  fields.Many2one('packaging.order', 'Consume Packaging Order')
    produce_packaging_order_id =  fields.Many2one('packaging.order', 'Produce Packaging Order')

    def _key_assign_picking(self):
        keys = super(StockMove, self)._key_assign_picking()
        return keys + (self.packaging_order_id,)

    @api.model
    def _prepare_merge_moves_distinct_fields(self):
        distinct_fields = super()._prepare_merge_moves_distinct_fields()
        distinct_fields.append('packaging_order_id')
        return distinct_fields

    @api.model
    def _prepare_merge_move_sort_method(self, move):
        keys_sorted = super()._prepare_merge_move_sort_method(move)
        keys_sorted.append(move.packaging_order_id.id)
        return keys_sorted

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    packaging_order_id = fields.Many2one('packaging.order', string='INV No', compute='_compute_packaging_order_id')

    @api.depends('lot_id')
    def _compute_packaging_order_id(self):
        for line in self:
            pack_line = self.env['packaging.order.line'].search([('lot_id', '=', line.lot_id.id)], limit=1)
            line.packaging_order_id = pack_line.order_id.id

class StockProductionLot(models.Model):
    _inherit = 'stock.lot'

    packaging_ref = fields.Char('Reference', copy=False)
    pack_order_lines = fields.One2many('packaging.order.line', 'lot_id', 'Packing Lines')
    packaging_order_id = fields.Many2one('packaging.order', string='INV No', compute='_compute_packaging_order_id', store=True)

    @api.depends('pack_order_lines')
    def _compute_packaging_order_id(self):
        for line in self:
            pack_line = self.env['packaging.order.line'].search([('lot_id', '=', line.id)], limit=1)
            if pack_line:
                line.packaging_order_id = pack_line.order_id.id
            else:
                line.packaging_order_id = False

class CatalogOrderLineInherit(models.Model):
    _inherit = 'catalog.order.line'

    packaging_order_id = fields.Many2one('packaging.order', string='INV No')

