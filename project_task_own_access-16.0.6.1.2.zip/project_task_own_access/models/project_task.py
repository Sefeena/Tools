# -*- coding: utf-8 -*-

from odoo import models, fields , api, _
from odoo.osv import expression
from odoo.exceptions import AccessError, MissingError


class ProjectTask(models.Model):
    _inherit = "project.task"

    custom_task_user_ids = fields.Many2many(
        'res.users',
        'custom_task_users_rel_probc',
        string="Access Limited Users",
        help="Only applicable to a limited group of users."
    )

    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        if not self.env.context.get('do_not_include'):
            restricted_tasks = self.env.user.has_group('project_task_own_access.custom_group_restricted_project_task')
            if restricted_tasks:
                # args = ['|',('custom_task_user_ids','in', self.env.user.id),('user_id','=',self.env.user.id)] + list(args)
                args = ['|',('custom_task_user_ids','in', self.env.user.id),('user_ids','=',self.env.user.id)] + list(args)
        return super(ProjectTask, self)._search(args, offset, limit, order, count, access_rights_uid)

    def read(self, fields=None, load='_classic_read'):
        tasks = super(ProjectTask, self).read(fields=fields, load=load)
        if len(tasks) == 1:
            if self.env.user.has_group("project_task_own_access.custom_group_restricted_project_task"):
                task_restrict_access_config = self.env['project.task'].sudo().search([('custom_task_user_ids', 'in', self.env.user.ids)])
                if task_restrict_access_config:
                    for task in tasks:
                        if task.get('id') and task.get('id') not in task_restrict_access_config.ids:
                            raise AccessError(_("You don't have the access!"))
        return tasks