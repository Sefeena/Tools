# -*- coding: utf-8 -*-
##########################################################################
# Author : Webkul Software Pvt. Ltd. (<https://webkul.com/>;)
# Copyright(c): 2017-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>;
##########################################################################
from odoo import fields, models
from odoo.exceptions import MissingError,UserError


class wizard_message(models.TransientModel):
    _name = "wizard.sku"
    name = fields.Char(string="Name", readonly=True)
    product = fields.Many2many(
        'product.product', 'product_wizard_data', 'wizard_data', 'product_data')

    def apply_on_all_products(self):
        if self.product:
            res_config_data = self.env['res.config.settings'].get_values()[
                'sku_config']
            if res_config_data:
                sku_generator_id = self.env['sku.generator'].browse(
                    [res_config_data])
                if sku_generator_id.active:
                    self.env['sku.generator']._condition_check_for_changes(
                        False, self.product, sku_generator_id)
                else:
                    raise MissingError("Selected SKU config is not active...")    
            else:
                raise MissingError("Default SKU Generator not found!")
        else:
            products_id = self.env['product.product'].search([])
            sku_generator_id = self.env['sku.generator'].browse(
                self._context.get("active_id"))
            if sku_generator_id.active:
                self.env['sku.generator']._condition_check_for_changes(
                    True, products_id, sku_generator_id)
            else:
                raise UserError("Current SKU config is not active...")
        notification = {
            'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': ('Product SKU'),
                        'message': 'SKU update Successfully!',
                        'type': 'success',  # types: success,warning,danger,info
                        'sticky': False,  # True/False will display for few seconds if false
                    },
        }
        return notification

    def product_without_default_code(self):
        if self.product:
            products_id = self.product.filtered(
                lambda o: o if o.default_code == False else None)
            res_config_data = self.env['res.config.settings'].get_values()[
                'sku_config']
            if res_config_data:
                sku_generator_id = self.env['sku.generator'].browse(
                    [res_config_data])
                if sku_generator_id.active:
                    self.env['sku.generator']._condition_check_for_changes(
                        False, products_id, sku_generator_id)
                else:
                    raise MissingError("Selected SKU config is not active...")    
            else:
                raise MissingError("Default SKU Generator not found!")
        else:
            products_id = self.env['product.product'].search(
                [('default_code', '=', False)])
            sku_generator_id = self.env['sku.generator'].browse(
                self._context.get("active_id"))
            if sku_generator_id.active:
                self.env['sku.generator']._condition_check_for_changes(
                    False, products_id, sku_generator_id)
            else:
                raise UserError("Current SKU config is not active...") 
            notification = {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': ('Product SKU'),
                    'message': 'SKU update Successfully!',
                    'type': 'success',  # types: success,warning,danger,info
                    'sticky': False,  # True/False will display for few seconds if false
                },
            }
            return notification
