# -*- coding: utf-8 -*-

from odoo import models,fields,api,_
import datetime
import logging
_logger = logging.getLogger(__name__)
import pymysql.cursors
no_pymysql = False
try:
    import pymysql.cursors
except ImportError:
    no_pymysql = True

class Partner(models.Model):
    _inherit = 'res.partner'

    # odoo_mysql = fields.Boolean(string="Mysql")
    get_weighment = fields.Boolean('Gate Weighment')