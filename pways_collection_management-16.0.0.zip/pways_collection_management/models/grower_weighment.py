# -*- coding: utf-8 -*-
from odoo import fields, models, api, tools, _
import requests
import json
import logging
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError
_logger = logging.getLogger(__name__)

class Weighment(models.Model):
    _name = "grower.weighment"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Grower Weighment"

    @api.depends('weighment_line_ids')
    def _compute_weight(self):
        self.weight = sum(line.weight for line in self.weighment_line_ids)
        self.tare_weight = sum(line.tare for line in self.weighment_line_ids)
        self.moisture_weight = sum(line.moisture for line in self.weighment_line_ids)
        self.total_net = sum(line.net for line in self.weighment_line_ids)
        self.no_of_package = len(self.weighment_line_ids.ids)

    # def _default_product_id(self):
    #     return self.env.ref('pways_collection_management.product_product_green_leaves', raise_if_not_found=False)

    name = fields.Char(string="Weighment", readonly=True, copy=False,default=lambda self: self.env['ir.sequence'].next_by_code('grower.weighment'))
    weighment_date = fields.Date(string="Date")
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    farmer_id = fields.Many2one("res.partner", string="Out Grower")
    national_id = fields.Char(related='farmer_id.national_id', string="National ID")
    image_128 = fields.Binary(related='farmer_id.image_128', string="Image 128", readonly=False)
    image_1920 = fields.Binary(related='farmer_id.image_1920', string="Image 1920", readonly=False)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('post', 'Post'),
        ('cancel', 'Cancel')], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')
    trip_id = fields.Many2one('trip.trip', string="Trip", required=True)
    product_id = fields.Many2one("product.product", string="Product")
    # product_id = fields.Many2one("product.product", string="Product", default=_default_product_id)
    weighment_line_ids = fields.One2many('grower.weighment.line', 'weighment_id', string="Weighment Line ids")
    weight = fields.Float(string="Total Weight (Kg)", compute="_compute_weight", store=True)
    tare_weight = fields.Float(string="Tare Weight (Kg)", compute="_compute_weight", store=True)
    moisture_weight = fields.Float(string="Moisture", compute="_compute_weight", store=True)
    total_net = fields.Float(string="Total Net (Kg)", compute="_compute_weight", store=True)
    no_of_package = fields.Float(string="No of Bags", compute="_compute_weight", store=True)
    bill_count = fields.Integer(string="#Bill Count", compute="_tota_bill_count")
    stock_move_id = fields.Many2one('stock.move', 'Weighment Move', readonly=True)
    clerk_id = fields.Many2one('res.partner', string="Responsible")
    route_id = fields.Many2one('routes.routes', string="Routes")
    mobile_id = fields.Char(string="Mobile ID", copy=False)
    device_id = fields.Char(string="Device ID", copy=False)
    
    def _get_message(self, farmer, total_net, weighment_ids, weighment_date):
        message = " "
        display_name = farmer.uuid_random + '-' + farmer.name
        template = self.env.ref('pways_collection_management.sms_template_weighment', raise_if_not_found=False)
        if template:
            template.write({
                "body_html" : "<p>Dear,</br>{}</br> Your Net Green Leaf collection is {} on {}</br></br> Thank You,</p>".format(display_name, str(total_net), str(weighment_date))
            })
            template_body = template._render_template(template.body_html, 'grower.weighment', weighment_ids.ids)
            message = tools.html2plaintext(template_body.get(weighment_ids.ids[0])).replace("*", "")
        return message

    def _prepare_url(self, farmer, total_net, weighment_ids, weighment_date):
        smsleopard_url = 'https://api.smsleopard.com/v1/sms/send?'
        company_id = self.env.company
        get_message = self._get_message(farmer, total_net, weighment_ids, weighment_date)
        if not company_id.source:
            raise ValidationError(_("Please set smsleopard configureration in compnay then after send sms...!"))
        if not farmer.mobile:
            raise ValidationError(_("Please set mobile number in farmer...!"))
        full_url = smsleopard_url+'message='+get_message+'&destination='+farmer.mobile+'&source='+company_id.source
        return full_url

    def send_message(self, farmer, total_net, weighment_ids, weighment_date):
        url = self._prepare_url(farmer, total_net, weighment_ids, weighment_date)
        company_id = self.env.company
        response = requests.get(url, auth=(company_id.account_id, company_id.secret))
        try:
            if response.status_code not in [200, 201]:
                _logger.info("Wrong Data Found {0}".format(response.text))
            else:
                _logger.info("Message Has Been Send {0}".format(response.text))
        except Exception as e:
            _logger.info("RESPONCE IS: {0}".format(e))
        return True

    def grower_weigment_cron(self):
        total_net = 0.0
        farmer = []
        registration_ids = self.env['res.partner'].search([('is_farmer', '!=' , False )])
        for farmer in registration_ids:
            weighment_ids = self.env['grower.weighment'].search([('farmer_id', '=', farmer.id), ('weighment_date' , '=', fields.Date.today())])
            if weighment_ids:
                total_net = sum(rec.total_net for rec in weighment_ids)
                self.send_message(farmer, total_net, weighment_ids, fields.Date.today())
        return True


    def _tota_bill_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('weighment_id', '=', rec.id)])
            move_ids = self.env['account.move'].search([('picking_id', 'in', picking_ids.ids)])
            rec.bill_count = len(move_ids.ids)

    def action_view_bill_piking(self):
        picking_ids = self.env['stock.picking'].search([('weighment_id', '=', self.id)])
        move_ids = self.env['account.move'].search([('picking_id', 'in', picking_ids.ids)])
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', move_ids.ids)]
        }

    def _create_invoice(self, picking_ids):
        is_purchase_auto_bill = self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.is_purchase_auto_bill') or False
        is_purchase_auto_refund = self.env['ir.config_parameter'].sudo().get_param('pways_collection_management.is_purchase_auto_refund') or False
        for picking in picking_ids:
            if not picking.is_return and  is_purchase_auto_bill and picking.picking_type_id.code == 'incoming':
                picking.create_bill_weighment()
        return True

    def action_post(self):
        move_ids = False
        for record in self:
            move_lines = record._prepare_moves()
            move_ids = self.env['stock.move'].create(move_lines)
            stock_move = move_ids._action_confirm()
            if stock_move.picking_id:
                stock_move.picking_id.write({'trip_id' : record.trip_id.id})
            move_ids._action_done()
            record.stock_move_id = move_ids
            record.state = 'post'
            if move_ids:
                picking_ids = move_ids.mapped('picking_id')
                picking_ids.write({'weighment_id' : record.id, 'ntfl_type': 'farmer'})
                if picking_ids:
                    self._create_invoice(picking_ids)
        return True

    @api.onchange('trip_id')
    def _onchange_user_type_id(self):
        if self.trip_id:
            self.vehicle_id = self.trip_id.vehicle_id.id
            self.route_id = self.trip_id.route_id.id
            self.clerk_id =  self.trip_id.clerk_id.id

    def action_draft(self):
        self.state = 'draft'

    def _prepare_moves(self):
        picking_type_id = self.trip_id.picking_type_id
        # picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'incoming')])
        procurement_id = self.trip_id.group_id
        locations = self.weighment_line_ids.mapped('location_id')
        moves = []
        for location in locations:
            weight = sum(self.weighment_line_ids.filtered(lambda x: x.location_id == location).mapped('net'))
            moves.append({
                'partner_id' : self.farmer_id.id,
                'group_id' : procurement_id.id,
                'name': self.product_id.name,
                'product_id': self.product_id.id,
                'product_uom': self.product_id.uom_id.id,
                'origin': self.name,
                'picking_type_id': picking_type_id.id,
                'location_id': location.id or False,
                'location_dest_id': picking_type_id.default_location_dest_id.id or False,
                'procure_method': 'make_to_stock',
                'product_uom_qty': weight,
                'quantity_done': weight,
                'weighment_id': self.id,
                'trip_id': self.trip_id.id,
                })
        return moves

    def action_post(self):
        for record in self:
            move_lines = record._prepare_moves()
            move_id = self.env['stock.move'].create(move_lines)
            stock_move = move_id._action_confirm()
            if stock_move.picking_id:
                stock_move.picking_id.write({'trip_id' : record.trip_id.id})
            move_id._action_done()
            record.write({'state': 'post'})
        return True

    def action_cancel(self):
        self.state = 'cancel'

class WeighmentLine(models.Model):
    _name = "grower.weighment.line"
    _description = "Weighment Lines"

    @api.depends('weighment_id.weighment_line_ids')
    def _compute_weight(self):
        for line in self:
            total_weight = 0.0
            for rec in line.weighment_id.weighment_line_ids:
                total_weight += rec.net
                rec.total = total_weight

    @api.depends('weight', 'tare')
    def _compute_net_amount(self):
        net_amount = 0.0
        for line in self:
            net_amount = line.weight - (line.tare + line.moisture)
            line.net = net_amount  

    transaction_no = fields.Char("Transaction No")
    location_id = fields.Many2one("stock.location", string="Collection Center", required=True)
    weight = fields.Float(string="Gross Weight")
    tare = fields.Float(string="Tare") # TODO : moisture per kg 
    moisture = fields.Float(string="Moisture") # Moisture
    unq_no = fields.Char("Unique No")
    net = fields.Float(string="Net Weight", compute="_compute_net_amount", store=True)
    total = fields.Float(string="Total Weight", compute="_compute_weight")
    weighment_id = fields.Many2one('grower.weighment')
    latitude = fields.Char(string="Latitude", copy=False)
    logititude = fields.Char(string="Logititude", copy=False)
    weighment_start_date = fields.Datetime(string="Weighment Start Time")
    weighment_end_date = fields.Datetime(string="Weighment End Time")
