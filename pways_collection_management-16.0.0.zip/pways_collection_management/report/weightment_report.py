from odoo import tools
from odoo import api, fields, models


class WeightmentReport(models.Model):
    _name = "weightment.report"
    _auto = False
    _description = "Weightment Analysis Report"

    transaction_no = fields.Char("Transaction No")
    weight = fields.Float(string="Gross Weight")
    tare = fields.Float(string="Tare") # TODO : moisture per kg 
    moisture = fields.Float(string="Moisture") # Moisture
    net = fields.Float(string="Net")
    weighment_date = fields.Date('Weighment Date')
    location_id = fields.Many2one('stock.location', 'Collection Center')
    farmer_id = fields.Many2one('res.partner','Farmer')
    name = fields.Char('Name')
    trip_id = fields.Many2one('trip.trip','Trip')

    def init(self):
        tools.drop_view_if_exists(self._cr, 'weightment_report')
        self._cr.execute("""CREATE OR REPLACE VIEW weightment_report AS (
            SELECT row_number() OVER() AS id,gwl.transaction_no,gwl.location_id,gw.name,gw.trip_id,gw.farmer_id,gw.weighment_date,SUM(gwl.weight) as weight,SUM(gwl.tare) as tare,SUM(gwl.moisture) as moisture,SUM(gwl.net) as net
            FROM grower_weighment_line gwl
            LEFT JOIN grower_weighment gw ON (gw.id = gwl.weighment_id)
            GROUP BY gwl.transaction_no,gwl.location_id,gw.farmer_id,gw.weighment_date,gw.trip_id,gw.name
        )""")