# -*- coding: utf-8 -*-
from odoo import models, fields, api

class StockLocation(models.Model):
    _inherit = "stock.location"

    is_collection_center = fields.Boolean(string="Collection Center")
    route_id = fields.Many2many('routes.routes', relation="routes_routes_location_rel", string="Routes")
    lead_farmer_id = fields.Many2one('res.partner', string="Lead Out Grower")
    transport_rate = fields.Float(string="Transport Rate")
    
    # is_shade = fields.Boolean(string="Shade")
    # is_table = fields.Boolean(string="Table")
    # is_noticeboard = fields.Boolean(string="Noticeboard")
    # is_pit_latrine = fields.Boolean(string="Pit latrine")
    # is_sops = fields.Boolean(string="SOPs")
    # is_dustbin = fields.Boolean(string="Dustbin")
    # chemical_handler_id = fields.Many2one('res.partner', string="Chemical handler")