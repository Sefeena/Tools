# Copyright 2019-2023 Sodexis
# License OPL-1 (See LICENSE file for full copyright and licensing details)

from . import crm_claim
from . import res_partner
from . import account_invoice
from . import stock_inventory
from . import stock_picking
from . import sale
from . import purchase
from . import crm_claim_team
from . import stock_warehouse
from . import res_config_settings
