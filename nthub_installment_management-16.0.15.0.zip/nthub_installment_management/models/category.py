# -*- coding: utf-8 -*-

from odoo import models, fields, api,_


class Category(models.Model):
    _name = 'installment.category'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "category"
    _rec_name = "name"

    name = fields.Char(string=_("Name"))
    description = fields.Char(string=_("Description"))
    product_ids = fields.One2many("installment.product","category_id")

    product_count = fields.Integer(compute = "compute_product_count",readonly="1")

    def compute_product_count(self):
        for record in self:
            record.product_count = len(record.product_ids)




