from odoo import api, fields, models

class ProductTemplate(models.Model):
    _inherit = "product.template"

    sample_product_id = fields.Many2one('product.product', string="Sample Product")
    is_part = fields.Boolean(string="Is Parts", help="Allow product as Parts")
    product_category_id = fields.Selection([('primary', 'Primary'), ('secondary', 'Secondary')], string="Category")

