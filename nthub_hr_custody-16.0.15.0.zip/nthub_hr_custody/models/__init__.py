# -*- coding: utf-8 -*-

from . import hr_job
from . import hr_applicant
from . import hr_employee
from . import wizard_reason
from . import stock_picking
from . import custody
from . import updation_config
from . import product_product
from . import stock_quant
from . import custody_history

