# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class FirewoodPurchaseWizard(models.TransientModel):
    _name = "firewood.purchase.wizard"
    _description = "Firewood Purchase Wizard"

    def action_create_purchase(self):
        gate_weighment_ids = self.env['gate.weighment'].browse(self.env.context.get('active_ids'))
        if gate_weighment_ids and any(not w.partner_id for w in gate_weighment_ids):
            raise ValidationError(_('Supplier not set on weighment!'))
        if gate_weighment_ids and any(not w.is_firewood for w in gate_weighment_ids):
            raise ValidationError(_('Please select only firewood weighment'))
        if gate_weighment_ids and any(w.is_po_created for w in gate_weighment_ids):
            raise ValidationError(_('Purchase order already created for these weighments!'))

        firewood_product_id = self.env['product.product'].search([('firewood_ok', '=', True)], limit=1)
        if not firewood_product_id:
            raise ValidationError(_('Firewood product not found!'))

        partner_ids = gate_weighment_ids.mapped('partner_id')

        po_ids = self.env['purchase.order']
        for partner in partner_ids:
            weigh_ids = gate_weighment_ids.filtered(lambda x: x.partner_id.id == partner.id)
            weigh_lines = []
            for w in weigh_ids:
                weigh_lines.append((0, 0, {
                    'gate_weighment_id': w.id,
                    'qty': w.wood_total,
                }))
            order = self.env['purchase.order'].create({
                "partner_id": partner.id,
                "purchase_type": 'firewood',
                "order_line": [
                    (0, 0, {
                        'product_id': firewood_product_id.id,
                        'name': firewood_product_id.name,
                        'price_unit': firewood_product_id.list_price,
                        'product_qty': sum(weigh_ids.mapped('wood_total')),
                        'product_uom': firewood_product_id.uom_po_id.id,
                    })],
                "weighment_line_ids": weigh_lines,
            })
            po_ids |= order
            weigh_ids.write({'is_po_created': True})

        return {
            'name': _('Firewood Purchase'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'purchase.order',
            'views': [(self.env.ref('purchase.purchase_order_view_tree').id, 'tree'), (False, 'form')],
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', po_ids.ids)],
        }
