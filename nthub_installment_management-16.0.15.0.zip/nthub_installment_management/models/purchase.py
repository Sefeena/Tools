# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import date
from odoo.exceptions import UserError


class Purchase(models.Model):
    _name = 'installment.purchase.order'
    _description = "Installment Purchase Order"
    _rec_name = 'name'

    name = fields.Char(string='Reference')
    order_date = fields.Date(string=_("Order Date"), required=True)
    confirmation_date = fields.Date(readonly=True)
    state = fields.Selection([
        ('draft', 'RFQ'),
        ('submit', 'Submit'),
        ('confirm', 'Purchase Order'),
        ('cancelled', 'Cancelled'),
    ], string="status", default='draft')
    user_id = fields.Many2one('res.users', string="Bayer")
    vendor_id = fields.Many2one('installment.vendor', string=_("Vendor"),  required=True,)
    product_id = fields.Many2one('installment.product', related='installment_purchase_line_ids.product_id', string=_('Product'))
    total_amount = fields.Float(string=_("Total Amount"), compute='_compute_total_amount')
    note = fields.Text()
    installment_purchase_line_ids = fields.One2many('installment.purchase.order.line','installment_purchase_id')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.user.company_id.currency_id)

    def action_submit(self):
        self.state = 'submit'

    def action_confirm(self):
        self.state = 'confirm'
        self.confirmation_date = date.today()
        self.update_product_quantities()

    def action_cancel(self):
        for order in self:
            if order.state == 'confirm':
                order.cancel_product_quantities()
                order.state = 'cancelled'

    def set_to_draft(self):
        for order in self:
            order.state = 'draft'

    def update_product_quantities(self):
        for order in self:
            for line in order.installment_purchase_line_ids:
                product = line.product_id
                quantity = line.quantity
                if product and quantity:
                    new_quantity = product.quantity + quantity
                    product.write({'quantity': new_quantity})

    def cancel_product_quantities(self):
        for order in self:
            for line in order.installment_purchase_line_ids:
                product = line.product_id
                quantity = line.quantity
                if product and quantity:
                    if product.quantity > quantity:
                        new_quantity = product.quantity - quantity
                        if new_quantity >= 0:
                            product.write({'quantity': new_quantity})
                        else:
                            raise UserError(
                                _("Cannot subtract more quantity than available for product: %s" % product.name))

    @api.depends('installment_purchase_line_ids.sub_total')
    def _compute_total_amount(self):
        for rec in self:
            total_amount = sum(rec.installment_purchase_line_ids.mapped('sub_total'))
            rec.total_amount = total_amount

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('installment.purchase.order') or _('New')
        order = super(Purchase, self).create(vals)
        return order


class PurchaseOrderLine(models.Model):
    _name = 'installment.purchase.order.line'

    product_id = fields.Many2one('installment.product', string=_("Product"))
    quantity = fields.Float(string=_("Quantity"), default=1.0)
    unit_price = fields.Float(related='product_id.cost_price', string=_("Unit Price"))
    sub_total = fields.Float(string=_("SubTotal"), compute='_compute_sub_total', readonly=True)
    installment_purchase_id = fields.Many2one('installment.purchase.order')

    @api.depends('quantity', 'unit_price')
    def _compute_sub_total(self):
        for record in self:
            total = 0
            if record.quantity and record.unit_price:
                total = record.quantity * record.unit_price
            record.sub_total = total


