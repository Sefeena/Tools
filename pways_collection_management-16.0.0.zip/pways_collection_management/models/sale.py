from odoo import api, fields, models

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    force_location_id = fields.Many2one("stock.location", string="Force location")
