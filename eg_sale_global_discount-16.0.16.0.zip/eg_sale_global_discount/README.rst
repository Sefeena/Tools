=================================
Sale Global Discount
=================================
This application adds two new fields named Discount Method and Discount Amount from where user can select the discount methods like fixed and percentage.