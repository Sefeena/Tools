# -*- coding: utf-8 -*-
##########################################################################
# Author : Webkul Software Pvt. Ltd. (<https://webkul.com/>;)
# Copyright(c): 2017-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>;
##########################################################################
from odoo import models, api
from odoo.exceptions import MissingError, UserError


class ProductProduct(models.Model):
    _inherit = 'product.product'
    def sku_change_server_action(self):
        wizard_id = self.env['wizard.sku'].create(
            {'name': 'Do you want to override all selective products SKU?', 'product': [(6, 0, self._context['active_ids'])]})
        return {
            "name": "Generate SKU",
            "type": "ir.actions.act_window",
            "res_model": "wizard.sku",
            'res_id': wizard_id.id,
            "view_id": self.env.ref("sku_generator.sku_generator_form").id,
            "view_mode": "form",
            'nodestroy': True,
            "target": "new",
        }

    @api.model
    def create(self, values):
        product_id = super(ProductProduct, self).create(values)
        res_config_data = self.env['res.config.settings'].get_values()
        if res_config_data['generate_sku_automatically']:
            res_config_sku_data = res_config_data['sku_config']
            if res_config_sku_data:
                sku_generator_id = self.env['sku.generator'].browse(
                    [res_config_sku_data])
                if sku_generator_id.active:
                    product_id.default_code = self.env['sku.generator']._condition_check_for_changes(
                    False, product_id, sku_generator_id)
            else:
                raise MissingError("Default SKU Generator not found!")
            
        return product_id
