# -*- coding: utf-8 -*-
{
    'name': "Collection Management System",
    'author': "Preciseways",
    'website': "http://www.preciseways.com",
    'version': '16.0.0',
    'category': 'Industries',
    'summary': """  Collection Management System
                    Customer Entity Registration
                    Daily trip management of raw materials
                    Route and Vehicle Management
                    Weight Management for incoming goods
                    Quality Checks for incoming goods
                    Collection Centers for incoming goods
                    Instance billing for outgrower
                    Loan and Advance payment for outgrowers
                    Indent request for other materials
                    Type of sales and purchases
                    Multiple reporting
                    Collection are direct selling
                    Selling through intermediaries
                    Dual Collection
                    Reverse Collection """,

    'description': """ Collection Registration
                    Daily trip management of raw materials
                    Route and Vehicle Management
                    Weight Management for incoming goods
                    Quality Checks for incoming goods
                    Collection Centers for incoming goods
                    Instance billing for outgrower
                    Loan and Advance payment for outgrowers
                    Indent request for other materials
                    Type of sales and purchases
                    Multiple reporting """,
    
    'depends': ['stock_account', 'sale_management', 'sale_stock', 'purchase_stock', 'crm', 'fleet', 'base_address_extended'],
    'data': [
        'security/res_groups.xml',
        'security/ir.model.access.csv',
        'data/olial_seq.xml',
        'data/farm_data.xml',
        'data/ir_sequence.xml',
        'data/farmer_stage_data.xml',
        'data/stock_data.xml',
        'data/sequence.xml',
        'data/out_employee_sequnce.xml',

        # 'data/indent_request_data.xml',
        # 'data/auction.xml',
        # 'data/hr_stage.xml',
        # 'data/send_email.xml',
        # 'data/data.xml',
        # 'data/cron.xml',
        # 'data/packaging_data.xml',
        # 'data/quality_check_cron.xml',
        # 'data/stock_short_data.xml',
        
        #wizard
        # 'wizard/merge_tender_view.xml',
        'wizard/multi_farmer_registration.xml',
        'wizard/trip_details_wizard.xml',
        'wizard/farmer_statement.xml',
        'wizard/miscellaneous_bill_wizard.xml',
        'wizard/fleet_wizard.xml',
        'wizard/cc_performance_wizard.xml',
        'wizard/farmer_performance_wizard.xml',
        'wizard/tourn_around_wizard.xml',
        # 'wizard/grade_wise_stock_wizard.xml',
        # 'wizard/grade_percentage_wizard.xml',
        'wizard/import_out_grower_wizard.xml',
        # 'wizard/send_notification.xml',
        # 'wizard/casual_payment_wizard.xml',
        # 'wizard/pack_backorder_wizard.xml',
        'wizard/trip_cancel_reason.xml',
        # 'wizard/indent_request_wizard.xml',
        'wizard/quality_sheet_wizard.xml',
        # 'wizard/quality_report_wizard.xml',

        # mro
        # 'wizard/mrp_pause_wizard.xml',
        # 'wizard/mrp_production_wizard.xml',

        # 'wizard/nhif_cron_wizard.xml',
        'wizard/farmer_payment_summary_wizard_view.xml',
        'wizard/farmer_payment_advice_wizard_view.xml',
        'wizard/firewood_purchase_wizard.xml',
        
        #views
        'views/crm_view.xml',

        'views/res_partner_view.xml',
        'views/res_partner_fleet.xml',
        'views/truck_request.xml',
        'views/res_compnay_sql.xml',

        'views/farmer_registration.xml',
        'views/farm_view.xml',
        'views/out_grower_extended.xml',

        'views/out_grower_view.xml',
        'views/trip_view.xml',
        'views/trip_view_extended.xml',

        'views/weighment_view.xml',
        'views/gate_weighment_view.xml',
        'views/gate_weighment.xml',
        'views/farmer_sync_view.xml',

        # 'views/casual_labour_view.xml',
        # 'views/advance_payment_employee.xml',
        'views/account_view_extended.xml',

        'views/out_grower_loan.xml',

        'views/config_routes_view.xml',
        'views/trip_cancel_reason_view.xml',
        'views/collection_center_view.xml',
        'views/farmer_stage_view.xml',
        'views/res_bank_branch_view.xml', 
        # 'views/purchase_view.xml',


        # 'views/stock_transfer_view.xml',
        # 'views/auction_request_view.xml',
        # 'views/stock_picking_view.xml',
        # 'views/catalog_order_view.xml',
        # 'views/recatlog_lot_lines.xml',
        # 'views/indent_request_view.xml',
        # 'views/hr_department_view.xml',
        # 'views/purchase_order_view.xml',
        # 'views/purchase_multi_warehouse.xml',   
        # 'views/product_view.xml',
        # 'views/ra_certified_view.xml',

        'views/handover.xml',
        'views/external_repair_view.xml',
        'views/res_config_settings_view.xml',
        'views/fleet_view.xml',
        # 'views/maintance.xml',
        'views/vehicle_view.xml',
        'views/vehicle_tyre_details.xml',
        'views/vehicle_fuel_log.xml',
        
        # 'views/out_grower_job.xml',
        # 'views/hr_view.xml',
        # 'views/hr_applicant_parameters.xml',
        # 'views/hr_employee_private_details.xml',
        # 'views/medical_report.xml',

        # 'views/packaging_sequence.xml', 
        # 'views/packaging_order_template.xml',
        # 'views/packaging_order_view.xml',


        # mrp
        # 'views/mrp_workorder_view.xml',
        # 'views/mrp_production_view.xml',
        # 'views/maintenance_view.xml',
        # 'views/account_move_inherited.xml',

        # 'views/stock_picking_invoice.xml',
        # 'views/res_config_settings_invoice.xml',
        # 'views/stock_view.xml',

        # 'views/shorting_template_view.xml',
        # 'views/shorting_order_view.xml',
        # 'views/sorting_order_line_view.xml',
        # 'views/packaging_order_view_inherit.xml',
        # 'wizard/shorting_backorder_wizard.xml',
        
        # 'views/stock_packaging_view.xml',
        # 'views/sale_order_view.xml',
        
        # report
        'report/farmer_payment_summary_template.xml',

        'report/farmer_statement_template.xml',
        'report/trip_details_template.xml',
        "report/cc_performance_template.xml",
        "report/ff_performance_template.xml",
        "report/tourn_around_template.xml",
        'report/farmer_payment_advice_template.xml',

        "report/fleet_template.xml",
        # "report/ntfl_production_report_action.xml",
        'report/outgrower_report_actions.xml',
        "report/report_action.xml",
        'report/report_actions.xml',

        'views/menus_view.xml',
        # 'report/auction_sale_template.xml',
        # 'report/auction_sale_template_dispath.xml',
        # 'report/indent_request_report.xml',
        'report/quality_sheet_report.xml',
        # "report/grade_percentage_template.xml",
        # "report/grade_wise_stock_template.xml",
        # 'report/mrp_production_template.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'pways_collection_management/static/src/js/action_manager.js',
        ],
    },
    # 'post_init_hook': '_create_warehouse_packaging_data',
    # 'post_init_hook': '_create_warehouse_sorting_data',
    # 'post_init_hook': '_create_warehouse_packing_data',    
    'price': 59,
    'currency': 'EUR',
    'installable': True,
    'application': True,
    'auto_install': False,
    'images':['static/description/banner.png'],
    'license': 'LGPL-3',
}
