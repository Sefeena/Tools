# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class RaCertified(models.Model):
    _name = "res.racertified"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Ra Certified"

    name = fields.Char('Name', required=True, index=True, readonly=True, copy=False, default='New') 
    farmer_regis_no = fields.Char(string="Farmer Registration")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')],string="Gender")
    age = fields.Integer(string="Age", copy=False)
    no_of_familles = fields.Integer(string="Families", copy=False)
    total_farm_size = fields.Float(string="Total Farm Size",)
    natural_ecosystem = fields.Char(string="Natural Ecosystem",)
    total_production_area = fields.Float(string="Total Production Area")
    worker_type = fields.Selection([('temporary_workers', 'Temporary Workers'), ('primary_workers', 'Primary Workers')], string="Worder Type")
    worker_gender = fields.Selection([('male', 'Male'), ('female', 'Female')])
    farmer_declaration = fields.Html(string="Farmer Declaration")
    note = fields.Text(string="Note")
    line_ids = fields.One2many('res.racertified.line', 'racertified_id', string="Ra-certified Line")
    #quations_ids = fields.Many2many('res.quations', string="Questions")
    survey_id =  fields.Many2one('survey.survey', string="Survey")
    answer_count = fields.Integer(compute='_answer_count', string='# Answer')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('res.racertified') or '/'
        return super(RaCertified, self).create(vals)

    def open_survey_answer(self):
        user_input_ids = self.env['survey.user_input'].search([('survey_id', '=', self.survey_id.id)])
        return {
            'name': _('Survey User Input'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', user_input_ids.ids)],
        }

    def _answer_count(self):
        for rec in self:
            user_input_ids = self.env['survey.user_input'].search([('survey_id', '=', self.survey_id.id)])
            rec.answer_count = len(user_input_ids.ids)


    def button_fill_up_survey(self):
        ''' Open the website page with the survey form into test mode'''
        self.ensure_one()
        if self.survey_id:
            if not self.env.user.has_group('survey.group_survey_user'):
                raise AccessError(_('Only survey users can manage sessions.'))
            self.survey_id.sudo().write({
                'questions_layout': 'page_per_question',
                'session_start_time': fields.Datetime.now(),
                'session_question_id': None,
                'session_state': 'ready'
            })
        return self.action_open_session_manager()

    def action_open_session_manager(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'name': "Open Session Manager",
            'target': 'self',
            'url': '/survey/session/manage/%s' % self.survey_id.access_token
        }


class RaCertifiedLine(models.Model):
    _name = "res.racertified.line"
    _description = "Res Certified Lines"

    crop = fields.Char(string="Crop")
    crop_population = fields.Char(string="Crop Population")
    crop_varlety = fields.Char(string="Crop Varlety(Clone)")
    crop_age = fields.Char(string="Crop Age")
    product_kg_yr = fields.Char(string="Production (KG/YR)")
    ratio = fields.Boolean(string="Ratio")
    racertified_id = fields.Many2one("res.racertified", string="Racertified ID")
