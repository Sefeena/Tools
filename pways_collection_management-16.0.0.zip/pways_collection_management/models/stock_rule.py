from odoo import api,fields,models

class StockRule(models.Model):
    _inherit = "stock.rule"

    def _get_stock_move_values(self, product_id, product_qty, product_uom, location_id, name, origin, company_id, values):
        res = super(StockRule, self)._get_stock_move_values(product_id=product_id, product_qty=product_qty, product_uom=product_uom, location_id=location_id, name=name, origin=origin, company_id=company_id, values=values)
        group_id = values.get('group_id', False)
        if res.get('sale_line_id') and self.picking_type_id.code == 'outgoing' and group_id and group_id.sale_id:
            if group_id.sale_id and group_id.sale_id.force_location_id:
                res['location_dest_id'] = group_id.sale_id.force_location_id.id
        return res

class ProcurementGroup(models.Model):
    _inherit = 'procurement.group'

    @api.model
    def _get_rule(self, product_id, location_id, values):
        """ Find a pull rule for the location_id, fallback on the parent
        locations if it could not be found.
        """
        force_location_id = location_id
        partner_rule = self.env['stock.rule']
        if values.get('sale_line_id'):
            sale_line = self.env['sale.order.line'].browse(values.get('sale_line_id'))
            if sale_line.order_id.force_location_id:
                force_location_id = sale_line.order_id.force_location_id
                partner_rule = super(ProcurementGroup, self)._get_rule(product_id=product_id, location_id=force_location_id, values=values)
        if not partner_rule:
            partner_rule = super(ProcurementGroup, self)._get_rule(product_id=product_id, location_id=location_id, values=values)
        return partner_rule
