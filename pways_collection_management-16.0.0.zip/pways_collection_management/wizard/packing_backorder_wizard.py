# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError

class PackingBackorderWizard(models.TransientModel):
    _name = 'packing.backorder.wizard'
    _description = 'Packing Backorder Wizard'

    def action_create_backorder(self):
        active_id = self.env.context.get('active_id')
        packing_order = self.env['packing.order'].browse(active_id)
        todo_qty = packing_order.product_qty - packing_order.process_qty
        return_packing_order = packing_order.copy({
            'product_qty': todo_qty,
            'product_id': packing_order.product_id.id,
            'template_id': packing_order.template_id.id,
            'backorder_id': packing_order.id,
            'move_id': False,
        })
        for line in packing_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        packing_order.move_id.write({'quantity_done': packing_order.process_qty})
        back_move = packing_order.move_id._action_done(cancel_backorder=False)
        packing_order.write({'state': 'done'})
        return_packing_order.onchange_template_id()
        return_packing_order.write({'move_id': back_move.id})
        return True

    def action_no_create_backorder(self):
        stock_move = self.env['stock.move']
        active_id = self.env.context.get('active_id')
        packing_order = self.env['packing.order'].browse(active_id)
        packing_order.write({'product_qty': packing_order.process_qty})
        for line in packing_order.order_line.filtered(lambda x: x.qty > 0):
            move_id = self.env['stock.move'].create(line.prepare_moves())
            stock_move = move_id._action_confirm()
            stock_move._action_done()
            line.write({'move_id': stock_move})
        packing_order.move_id.write({'quantity_done': packing_order.product_qty})
        packing_order.move_id._action_done(cancel_backorder=True)
        packing_order.write({'state': 'done'})
        return True
