# -*- coding: utf-8 -*-
##########################################################################
# Author : Webkul Software Pvt. Ltd. (<https://webkul.com/>;)
# Copyright(c): 2017-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>;
##########################################################################
{
    "name": "Odoo SKU Generator",
    "summary": "Odoo SKU Generator Module enables you to generate the SKU(Internal Reference Code)  for products. You can manage SKU creation conditions and records.  We can override all SKU products as well as selective SKU products.",
    "category": "Website",
    "version":"1.0.1",
    "license":"Other proprietary",
    "description": "sku, sku generator, reference code, internal reference code, sku creation, stock keeping unit codes, stock keeping unit, sku codes, internal codes",
    "author": "Webkul Software Pvt. Ltd.",
    'price': 69,
    'currency': 'USD',
    "website": "https://store.webkul.com/",
    "live_test_url": "http://odoodemo.webkul.com/?module=sku_generator",
    "depends": ['sale_management'],
    "data": ['security/ir.model.access.csv',
             'wizard/sku_generate_wizard.xml',
             'views/sku_generator_views.xml',
             'views/res_config_settings_views.xml',
             'views/product_product_views.xml',

             ],
    "images": ['static/description/odoo_sku_generator.gif'],
    "application": True,
    "installable": True,
    "auto_install": False,
    "license": "Other proprietary",
    "pre_init_hook": "pre_init_check",
}
