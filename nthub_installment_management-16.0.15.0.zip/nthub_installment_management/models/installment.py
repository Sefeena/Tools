# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from datetime import datetime
from odoo.exceptions import UserError


class Installment(models.Model):
    _name = 'installment.installment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Customer Installment'
    _rec_name = 'name'

    name = fields.Char(string='Reference', copy=False, readonly=True,
                       default=lambda self: _('New'))
    state = fields.Selection(selection=[('draft', 'Draft'), ('running', 'Running'), ('finished', 'Finished'), ],
                             default='draft', string=_('State'), comput='compute_finished_state')
    installment_date = fields.Date(string=_('Installment Date'), required=True)
    customer_id = fields.Many2one('installment.customer', string=_('Customer'))
    user_id = fields.Many2one('res.users', string="Sales Person")
    product_id = fields.Many2one('installment.product', string=_('Product'))
    sale_price = fields.Float(string=_('Amount'), related='product_id.sale_price')
    duration_config = fields.Integer(string=_('Duration'))
    duration = fields.Integer(string=_('Duration'), default=1.0, )
    down_payment_percentage_config = fields.Float(string=_('Down Payment(%)'))
    down_payment_percentage = fields.Float(string=_('Down Payment(%)'))
    down_payment_amount = fields.Float(string=_('Down Payment'))
    administrative_expenses_percentage = fields.Float(string=_('A.Expenses Amount(%)'))
    administrative_expenses = fields.Float(string=_('A.Expenses Amount'))
    amount_after_down_payment = fields.Float(string=_('Amount A.D.Payment'))
    nid = fields.Boolean(string=_('Nid'), compute='compute_required_document', store=True)
    salary_components = fields.Boolean(string=_('Salary Components'), compute='compute_required_document', store=True)
    bank_statement = fields.Boolean(string=_('Bank Statement'), compute='compute_required_document', store=True)
    bank_rate_letter = fields.Boolean(string=_('Bank Rate Letter'), compute='compute_required_document', store=True)
    rental_contract = fields.Boolean(string=_('Rental Contract'), compute='compute_required_document', store=True)
    ownership_contract = fields.Boolean(string=_('Ownership Contract'), compute='compute_required_document', store=True)
    installment_line_ids = fields.One2many('installment.installment.line', string=_('Installment Line'),
                                           inverse_name='installment_id')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.user.company_id.currency_id)
    annual_rate_percentage = fields.Float(string=_('Annual Rate Percentage'))
    total_after_rate = fields.Float(string=_('Total'))
    total_amount = fields.Float(string="Total Amount", compute='_compute_installment_amount', store=True)
    balance_amount = fields.Float(string="Balance Amount", compute='_compute_installment_amount', store=True)
    total_paid_amount = fields.Float(string="Total Paid Amount", compute='_compute_installment_amount', store=True)
    delay_amount = fields.Float(string=_('Delay Amount'), compute='_compute_installment_amount', store=True)
    total_after_delay_amount = fields.Float(string=_('Total After Delay Amount'), compute='_compute_installment_amount',
                                            store=True)

    @api.depends('customer_id')
    def compute_required_document(self):
        if self.customer_id.national_id:
            self.nid = True
        else:
            self.nid = False

        if self.customer_id.rental_contract:
            self.rental_contract = True
        else:
            self.rental_contract = False

        if self.customer_id.ownership_contract:
            self.ownership_contract = True
        else:
            self.ownership_contract = False

        if self.customer_id.salary_components:
            self.salary_components = True
        else:
            self.salary_components = False

        if self.customer_id.bank_statement:
            self.bank_statement = True
        else:
            self.bank_statement = False

        if self.customer_id.bank_rate_letter:
            self.bank_rate_letter = True
        else:
            self.bank_rate_letter = False

    @api.depends('total_after_rate', 'installment_line_ids.paid', 'installment_line_ids.amount')
    def _compute_installment_amount(self):
        total_paid = 0.0
        total_delay = 0.0
        for installment in self:
            for line in installment.installment_line_ids:
                if line.paid:
                    total_paid += line.payment_amount
                    total_delay += line.delay_amount
            installment.total_amount = installment.total_after_rate
            installment.delay_amount = total_delay
            installment.total_after_delay_amount = installment.total_amount + total_delay
            balance_amount = installment.total_after_delay_amount - (total_paid + total_delay)
            installment.balance_amount = balance_amount
            installment.total_paid_amount = total_paid + total_delay
            installment.compute_required_document()

    def compute_installment(self):
        for installment in self:
            self.down_payment_percentage_config = self.env['ir.config_parameter'].sudo().get_param(
                'nthub_installment_management.down_payment')
            if self.down_payment_percentage < self.down_payment_percentage_config:
                raise UserError(
                    _("down payment must be >=  %s.", self.down_payment_percentage_config))
            self.administrative_expenses_percentage = self.env['ir.config_parameter'].sudo().get_param(
                'nthub_installment_management.administrative_expenses')
            self.down_payment_amount = (self.down_payment_percentage * self.sale_price)
            self.amount_after_down_payment = self.sale_price - self.down_payment_amount
            self.administrative_expenses = self.administrative_expenses_percentage * self.amount_after_down_payment
            self.duration_config = int(float(self.env['ir.config_parameter'].sudo().get_param(
                'nthub_installment_management.max_duration')))
            if self.duration > self.duration_config:
                raise UserError(
                    _("duration must be <=  %s.", self.duration_config))
            self.annual_rate_percentage = self.env['ir.config_parameter'].sudo().get_param(
                'nthub_installment_management.annual_rate_percentage')
            self.total_after_rate = self.amount_after_down_payment + (
                        self.amount_after_down_payment * self.duration * self.annual_rate_percentage)
            installment.installment_line_ids.unlink()
            date_start = datetime.strptime(str(installment.installment_date), '%Y-%m-%d')
            amount = installment.total_after_rate / installment.duration / 12
            for i in range(1, (installment.duration * 12) + 1):
                self.env['installment.installment.line'].create({
                    'date': date_start + relativedelta(months=1),
                    'amount': amount,
                    'installment_id': installment.id})
                date_start = date_start + relativedelta(months=1)

        return True

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('installment.seq')
        return super(Installment, self).create(vals)

    def confirm_action(self):
        self.compute_installment()
        self.state = 'running'
        if self.down_payment_percentage < self.down_payment_percentage_config:
            raise UserError(
                _("down payment must be >=  %s.", self.down_payment_percentage_config))
        if self.duration > self.duration_config:
            raise UserError(
                _("Duration must be <=  %s.", self.duration_config))
        if not self.product_id:
            raise UserError(
                _("Product is empty"))
        if self.product_id.quantity <= 0:
            raise UserError(
                _("Product quantity is zero"))
        if self.sale_price <= 0:
            raise UserError(
                _("Product has no price"))
        if self.total_amount == 0:
            raise UserError(
                _("Compute installment to confirm it"))

        product = self.product_id
        quantity = 1
        if product:
            new_quantity = product.quantity - quantity
            product.write({'quantity': new_quantity})

    @api.depends('balance_amount', 'total_amount', 'state')
    def compute_finished_state(self):
        if self.state == 'running' and self.total_amount:
            if self.balance_amount == 0:
                self.state = 'finished'
        elif self.state == 'running' and self.total_amount:
            if self.balance_amount != 0:
                self.state = 'running'
        else:
            self.state = 'draft'


class InstallmentLine(models.Model):
    _name = 'installment.installment.line'
    _description = 'Customer Installment Line'
    _rec_name = 'installment_id'

    date = fields.Date(string=_('Date'))
    amount = fields.Float(string=_('Amount'))
    paid = fields.Boolean(string=_('Paid'))
    payment_date = fields.Date(string=_('Payment Date'))
    payment_amount = fields.Float(string=_('Payment Amount'))
    delay_amount = fields.Float(string=_('Delay Amount'))
    color = fields.Char(string=_('Color'), compute='compute_payment_state_color')
    installment_id = fields.Many2one('installment.installment', string=_('Installment'))
    customer_id = fields.Many2one(string=_('Customer'), related='installment_id.customer_id', store=True)
    product_id = fields.Many2one(string=_('Product'), related='installment_id.product_id', store=True)
    state = fields.Selection(string=_('State'), related='installment_id.state', store=True)

    @api.depends('paid', 'date', 'amount')
    def compute_payment_state_color(self):
        for rec in self:
            rec.color = 'white'
            if rec.state in ['finished', 'running']:
                if rec.paid == True:
                    rec.color = 'green'
                if rec.date and rec.date < fields.Date.today() and rec.paid == False:
                    rec.color = 'red'

    def print_installment_line(self):
        installments = self.env['installment.installment'].search_read(
            [('customer_id', '=', self.installment_id.customer_id.id),
             ('id', '=', self.installment_id.id)])
        data = {
            'model': 'installment.installment.line',
            'form': self.read()[0],
            'installments': installments
        }
        return self.env.ref('nthub_installment_management.installment_line_reports').report_action(self, data=data)
