from odoo import models, fields, api, _

class GradePercentageWizard(models.TransientModel):
    _name = 'grade.percentage.wizard'

    date_from = fields.Date(string="Date From")
    date_to = fields.Date(string="Date To")
    tea_type = fields.Selection([('CTC','CTC'),('Orthodex','Orthodex')],string='Tea Type')

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'tea_type': self.tea_type,
        }
        return self.env.ref('pways_collection_management.grade_percentage_report').report_action(self, data=data)


class GradePercentageWizardReport(models.AbstractModel):
    _name = 'report.pways_collection_management.grade_percentage_template'

    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date_from' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'tea_type' :  data.get('tea_type'),
            
        }
