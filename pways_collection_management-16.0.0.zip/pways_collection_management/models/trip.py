# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class Trip(models.Model):
    _name = "trip.trip"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Out Grow Trip"

    def _default_picking_type_id(self):
        return self.env['stock.picking.type'].search([('code', '=', 'incoming')], limit=1)

    name = fields.Char(string='Name', index=True, copy=False, default='New', readonly=True)
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle", required=True)
    image_128 = fields.Binary(related='clerk_id.image_128', string="Avatar", readonly=False)
    trip_date = fields.Date(string="Date")
    tare_value = fields.Float(string="Tare Value")
    moisture_value = fields.Float(string="Moisture Value")
    clerk_id = fields.Many2one("res.partner", string="Responsible", required=True)
    extenstion_officer = fields.Many2one("res.partner", string="Extenstion Officer")
    no_of_assignment = fields.Integer(string="No of Bags")
    is_weighing_scale = fields.Boolean(string="Weighing Scale")
    weighing_scale = fields.Char(string="Weighing Scale No")
    is_phone = fields.Boolean(string="Mobile")
    crates_product_id = fields.Many2one("product.product", string="Crates Product")
    crates_quantity = fields.Float(string="Crates Quantity")
    weighment_allow_in_kg = fields.Float(string="Weighing Allow (kg)")
    phone_imei = fields.Char(string="Mobile Imei")
    is_scale_calibration = fields.Boolean(string="Scale Calibration")
    scale_unique_number = fields.Char(string="Scale Calibration")
    route_id = fields.Many2one('routes.routes', string="Route", required=True)
    collection_ids = fields.Many2many('stock.location', string="Collection Center")
    picking_ids = fields.One2many('stock.picking', 'trip_id', string="Pickings")
    weighment_lines = fields.One2many("grower.weighment", "trip_id", string="Weighments")
    state = fields.Selection([('draft', 'Draft'), ('in_progress', 'in Progress'), ('done', 'Done'), ('cancel', 'Cancel')], default='draft', copy=False, track_visibility="onchange")
    picking_count = fields.Integer(compute='_picking_count', string='# Outgoin Picking')
    incoming_picking_count = fields.Integer(compute='_picking_count', string='# Incoming Picking')
    picking_type_id = fields.Many2one('stock.picking.type', string='Operation Type', default=_default_picking_type_id, required=True, ondelete='restrict')
    group_id = fields.Many2one('procurement.group', copy=False)
    gate_weighment_id = fields.Many2one("gate.weighment", string="Gate Weighment")
    weight = fields.Float(string="Total Weight (Kg)", compute="_compute_weight", store=True)
    tare_weight = fields.Float(string="Tare Weight (Kg)", compute="_compute_weight", store=True)
    moisture_weight = fields.Float(string="Moisture", compute="_compute_weight", store=True)
    total_net = fields.Float(string="Total Net (Kg)", compute="_compute_weight", store=True)
    quality_sheet_ids = fields.One2many('quality.sheet', 'trip_id')
    show_quality_check = fields.Boolean(compute='_compute_show_quality_check')
    transporter_bill_count = fields.Integer(string="#Transporter Bill Count", compute="_transporter_bill_count")
    farmer_bill_count = fields.Integer(string="#Farmer Bill Count", compute="_farmer_bill_count")
    stock_move_ids = fields.One2many('stock.move', 'trip_id')
    total_kg_of_move = fields.Float('Total kg', compute='_compute_total_kg_of_move', store=True)
    visible_create_bill = fields.Boolean(compute='_compute_visible_create_bill')
    vehicle_capacity = fields.Char(string="Vehicle Capacity", copy=False)
    on_hand_qty = fields.Float(string="On Hand Qty", related="crates_product_id.qty_available")
    farmer_count = fields.Integer("Out Grower Count", compute='_compute_farmer_count')

    @api.depends('stock_move_ids')
    def _compute_total_kg_of_move(self):
        for trip in self:
            trip.total_kg_of_move = sum(trip.stock_move_ids.mapped('product_uom_qty'))

    def _farmer_bill_count(self):
        for trip in self:
            trip.farmer_bill_count = self.env['account.move'].search_count([('picking_id', 'in', trip.picking_ids.ids), ('move_type', '=', 'in_invoice')])

    def _transporter_bill_count(self):
        for trip in self:
            trip.transporter_bill_count = self.env['account.move'].search_count([('trip_id', '=', trip.id)])

    def open_stock_move_ids(self):
        return {
            'name': _('Moves'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', self.stock_move_ids.ids)]
        }

    def open_farmer_bills(self):
        bill_ids = self.env['account.move'].search([('picking_id', 'in', self.picking_ids.ids), ('move_type', '=', 'in_invoice')])
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', bill_ids.ids)]
        }

    def open_transporter_bill(self):
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('trip_id', '=', self.id)]
        }

    def _compute_show_quality_check(self):
        for trip in self:
            trip.show_quality_check = bool(trip.quality_sheet_ids)

    @api.depends('weighment_lines', 'weighment_lines.weight')
    def _compute_weight(self):
        for trip in self:
            trip.weight = sum(line.weight for line in trip.weighment_lines)
            trip.tare_weight = sum(line.tare_weight for line in trip.weighment_lines)
            trip.moisture_weight = sum(line.moisture_weight for line in trip.weighment_lines)
            trip.total_net = sum(line.total_net for line in trip.weighment_lines)

    def _prepare_procurement_id(self):
        procurement = self.env["procurement.group"].create({'name' : self.name})
        return procurement.id

    def _picking_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('trip_id', '=', rec.id), ('picking_type_id.code', '=', 'outgoing')])
            incoming_ids = self.env['stock.picking'].search([('trip_id', '=', rec.id), ('picking_type_id.code', '=', 'incoming')])
            rec.picking_count = len(picking_ids.ids)
            rec.incoming_picking_count = len(incoming_ids.ids)

    def open_outgoing_picking(self):
        picking_ids = self.env['stock.picking'].search([('trip_id', '=', self.id), ('picking_type_id.code', '=', 'outgoing')])
        return {
            'name': _('Outgoing Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)],
        }

    def open_incoming_picking(self):
        picking_ids = self.env['stock.picking'].search([('trip_id', '=', self.id), ('picking_type_id.code', '=', 'incoming')])
        return {
            'name': _('Incoming Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)],
        }

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('trip.trip') or '/'
        return super(Trip, self).create(vals)

    @api.onchange('route_id')
    def onchange_journal_id(self):
        if self.route_id:
            location_ids = self.env['stock.location'].search([('route_id', '=', self.route_id.id)])
            self.collection_ids = location_ids.ids

    def action_in_progress(self):
        self.group_id = self._prepare_procurement_id()
        self.create_outgoin_picking()
        return True

    def _compute_visible_create_bill(self):
        for trip in self:
            transporter_bills = self.env['account.move'].search([('trip_id', '=', trip.id)])
            if not transporter_bills and trip.state == 'done':
                trip.visible_create_bill = True
            else:
                trip.visible_create_bill = False

    def create_bill(self):
        move_obj = self.env['account.move']
        log_contract_id = False
        lines = self._create_prepaire_bill_line()
        if self.vehicle_id and self.vehicle_id.log_contracts:
            log_contract_id = self.vehicle_id and self.vehicle_id.log_contracts[0]
        if self.gate_weighment_id and log_contract_id:
            vals = {
                'move_type': 'in_invoice', 
                'partner_id': log_contract_id.insurer_id.id if log_contract_id else False, 
                'invoice_date': self.trip_date,
                'trip_id': self.id,
                'vehicle_id': self.vehicle_id.id,
                'ref': self.gate_weighment_id.weighment_no,
                'ntfl_type': 'transporter',
                'invoice_line_ids': lines
            }
            move_obj.create(vals)
        return True

    def action_done(self):
        for rec in self:
            if not rec.gate_weighment_id:
                raise ValidationError(_("Please define gate weighment then after done!"))
        self.create_incoming_picking()
        self.weighment_lines.filtered(lambda x: x.state == 'draft').action_post()
        self.write({'state': 'done'})
        print("Yess filter completed........")
        if self.vehicle_id and self.gate_weighment_id:
            invoice_line = self.create_bill()
        return True

    def action_cancel(self):
        self.write({'state' : 'cancel'})

    def _prepare_move_outgoing(self):
        company_id = self.env.company
        picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'outgoing')], limit=1)
        stock_location = self.env.ref('stock.stock_location_locations', raise_if_not_found=False)
        location_id = self.env.ref('pways_collection_management.stock_location_virtual_locatio')
        # procurement_id = self.with_context(outgoing=True)._prepare_procurement_id()
        return {
            'name' : self.name,
            'product_id': self.crates_product_id.id,
            'product_uom': self.crates_product_id.uom_id.id,
            'location_id': picking_type_id.default_location_src_id.id or False,
            'location_dest_id':location_id.id,
            'company_id': company_id.id,
            'product_uom_qty': self.crates_quantity,
            'origin': self.name,
            'group_id' : self.group_id.id,
            'picking_type_id': picking_type_id.id,
            'quantity_done' : self.crates_quantity
        }

    def _prepare_move_incoming(self):
        company_id = self.env.company
        stock_location = self.env.ref('stock.stock_location_locations', raise_if_not_found=False)
        picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'incoming')], limit=1)
        location_dest_id = self.env.ref('pways_collection_management.stock_location_virtual_locatio')
        # procurement_id = self.with_context(incoming=True)._prepare_procurement_id()
        return {
            'name' : self.name,
            'product_id': self.crates_product_id.id,
            'product_uom': self.crates_product_id.uom_id.id,
            'location_id': location_dest_id.id,
            'location_dest_id': picking_type_id.default_location_dest_id.id or False,
            'company_id': company_id.id,
            'product_uom_qty': self.crates_quantity,
            'origin': self.name,
            'group_id' : self.group_id.id,
            'picking_type_id': picking_type_id.id,
            'quantity_done' : self.crates_quantity
        }

    def create_outgoin_picking(self):
        if self.crates_quantity > 0:
            move_line_vals = self._prepare_move_outgoing()
            stock_move = self.env['stock.move'].create(move_line_vals)
            stock_move._action_confirm()
            stock_move._action_done()
            stock_move.picking_id.trip_id = self.id
        self.state = 'in_progress'
        return True

    def create_incoming_picking(self):
        if self.crates_quantity > 0:
            move_line_vals = self._prepare_move_incoming()
            stock_move = self.env['stock.move'].create(move_line_vals)
            stock_move._action_confirm()
            stock_move._action_done()
            stock_move.picking_id.write({'trip_id': self.id})
        return True

    def action_quality_sheet(self):
        return {
            'name': _('Generate Quantity Sheet'),
            'res_model': 'quality.sheet.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('pways_collection_management.quality_sheet_wizard_form').id,
            'context': self.env.context,
            'target': 'new',
            'type': 'ir.actions.act_window',
        }

    def _create_prepaire_bill_line(self):
        transport_rate = 0.0
        if self.vehicle_id and self.vehicle_id.log_contracts:
            contract_ids = self.vehicle_id.log_contracts.filtered(lambda x: x.expiration_date > self.trip_date)
            transport_rate = sum(contract_ids.mapped('transport_rate'))
        quantity = self.gate_weighment_id.net_weight or 1.0
        product_id = self.env.ref('pways_collection_management.transport_rate_product')
        return [(0, 0, {
                'product_id' : product_id.id,
                'name': product_id.name,
                'quantity': quantity,
                'vehicle_id': self.vehicle_id.id,
                'price_unit': transport_rate,
                'tax_ids': [(6, 0, [])],
            })]

    @api.depends('picking_ids', 'picking_ids.partner_id')
    def _compute_farmer_count(self):
        for rec in self:
            farmer_count = len(rec.weighment_lines.mapped('farmer_id'))
            rec.farmer_count = farmer_count

    @api.onchange('crates_quantity')
    def _onchange_crates_quantity(self):
        if self.crates_quantity and self.on_hand_qty:
            if self.crates_quantity > self.on_hand_qty:
                raise ValidationError(_('Product Quantity limit Over!!!'))

    @api.onchange('vehicle_id')
    def _onchange_vehicle_id(self):
        if self.vehicle_id:
            self.vehicle_capacity = self.vehicle_id.vehicle_capacity






