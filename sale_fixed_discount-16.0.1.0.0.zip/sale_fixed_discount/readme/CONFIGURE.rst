To configure this module, you need to:

#. Go to *Sales > Configuration > Settings*.
#. In the *Pricing* section select *Discounts* option to grant discounts on sales order lines.
