# -*- coding: utf-8 -*-
from odoo import models
from datetime import datetime
from odoo.exceptions import ValidationError

class PaymentSummaryReport(models.AbstractModel):
    _name = 'report.pways_collection_management.fp_summary_report'
    _description = 'Payment Summary Report'

    def _get_group_by_partner(self, bill_ids):
        group_by_partner_id  = {}
        for bill in bill_ids:
            partner_id = bill.partner_id
            if partner_id not in group_by_partner_id:
                group_by_partner_id[partner_id] = bill
            else:
                group_by_partner_id[partner_id] |= bill
        return group_by_partner_id

    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        date_from = data.get('date_from')
        date_to = data.get('date_to')
        partner_ids = data.get('partner_ids')
        bank_ids = data.get('bank_ids')
        payment_type = data.get('payment_type')
        lines = []
        domain=[('partner_id.is_farmer', '=', True), ('state', '=', 'posted'), ('invoice_date', '>=', date_from), ('invoice_date', '<=', date_to)]
        if payment_type == 'unpaid':
            domain.append(('payment_state', 'in', ['not_paid','partial']))
        else:
            domain.append(('payment_state', '=', 'paid'))
        if partner_ids:
            domain.append(('partner_id', 'in', partner_ids))
        bill_ids = self.env['account.move'].search(domain)
        group_by_partner_id = self._get_group_by_partner(bill_ids)
        total_netwt = 0.0
        total_amount = 0.0
        for partner_id, bill_ids in group_by_partner_id.items():
            partner_bank_id = partner_id.bank_ids and partner_id.bank_ids[0]
            if not bank_ids or (partner_bank_id.bank_id.id in bank_ids):
                line_ids = bill_ids.mapped('invoice_line_ids')
                netwt = sum(line_ids.filtered(lambda x: x.product_id.green_leaf_ok).mapped('quantity'))
                amount = sum(bill_ids.mapped('amount_residual'))
                total_netwt += netwt 
                total_amount += amount
                lines.append({
                    'farmer_code': partner_id.code,
                    'farmer_name': partner_id.name,
                    'national_id': partner_id.national_id,
                    'contact_no': partner_id.mobile,
                    'account_no': partner_bank_id.acc_number,
                    'bank_id': partner_bank_id.bank_id.name,
                    'branch_id': partner_bank_id.branch_id.branch_name,
                    'bank_code': partner_bank_id.bank_id.bic,
                    'branch_code': partner_bank_id.branch_id.branch_code,
                    'netwt': netwt,
                    'amount': amount,
                })
        return {
            'docs' : docs,
            'lines': lines,
            'total_netwt': total_netwt,
            'total_amount': total_amount,
        }
