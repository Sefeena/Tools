# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class CRM(models.Model):
    _inherit = "crm.lead"

    farmer_name = fields.Char(string="Out Grower", copy=False)
    farmer_id = fields.Many2one("farmer.registration", string="Registration")
    clerk_id = fields.Many2one("res.partner", domain=[('is_clerk', '=', True)])
    national_id = fields.Char("National Identification No")
    bank_ac_no = fields.Char("Bank Account No")
    lr_no = fields.Char("LR No")
    national_id_document = fields.Binary("National ID Document", attachment=True)
    bank_ac_document = fields.Binary("Bank Account Document", attachment=True)
    farmer_count = fields.Integer(compute='_farmer_count', string='# Farmers')
    is_registration_stage = fields.Boolean(string="IS Registration", compute='_registration_stage')

    @api.depends('stage_id')
    def _registration_stage(self):
        stage_id = self.env.ref('pways_collection_management.stage_is_registation')
        for rec in self:
            if rec.stage_id == stage_id:
                rec.is_registration_stage = True
            else:
                rec.is_registration_stage = False

    def _farmer_count(self):
        for rec in self:
            farmer_ids = self.env['farmer.registration'].search([('lead_id', '=', rec.id)])
            rec.farmer_count = len(farmer_ids.ids)

    def action_open_farmer(self):
        farmer_ids = self.env['farmer.registration'].search([('lead_id', '=', self.id)])
        return {
            'name': _('Farmer Registration'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'farmer.registration',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', farmer_ids.ids)],
        }

    def prepare_farmer_data(self):
        # if not self.partner_id:
        #   raise ValidationError(_("Please select partner!"))
        return {
            'partner_id' : self.partner_id.id,
            'stage_id': False,
            'is_company': False,
            'company_type': 'person',
            'image_1920': False,
            'name': self.partner_id.name or self.name or False,
            'parent_id': False,
            'company_name': False,
            'bank_ac_no': self.bank_ac_no or False,
            'national_id_document': self.national_id_document or False,
            'bank_ac_document': self.bank_ac_document or False,
            'farmer_type': 'out_grower',
            'type': 'contact',
            'lr_no': self.lr_no,
            'street': self.street,
            'street2': self.street2,
            'city': self.city,
            'state_id': self.state_id.id or False,
            'zip': self.zip,
            'country_id': self.country_id.id or False,
            'farmer_sub_country_id': False,
            'national_id':  self.national_id or False,
            'clerk_id': self.clerk_id.id or False,
            'phone': self.phone,
            'mobile': self.mobile,
            'email': self.email_from,
            'gender': False,
            'title': self.title.id,
            'lang': 'en_US',
            'user_id': False,
            'contract_period': False,
            'contract_status': 'active',
            'transport_rate': False,
            'contract_sign_date': False,
            'contact_name': self.contact_name,
            'lead_id' : self.id,
            'note': False}

    def create_farmer(self):
        # if not self.contact_name:
        #     for rec in self.partner_id:
        #         self.contact_name = rec.name
        values = self.prepare_farmer_data()
        registration_id = self.env['farmer.registration'].create(values)
        self.farmer_id = registration_id.id
        return True
