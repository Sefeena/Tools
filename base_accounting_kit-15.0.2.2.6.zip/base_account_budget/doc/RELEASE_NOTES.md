## Module <base_account_budget>

#### 06.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 Budget Management

#### 27.06.2023
#### Version 15.0.1.1.1
#### REF
- Refactor code and remove unused files