	# -*- coding: utf-8 -*-

# ===============leads======================
from . import crm_lead
# =======================================================

# ===============Out Grower Details======================== 
from . import res_partner
from . import farmer_registration
# =======================================================

# ===============Trip======================== 
from . import trip
# =======================================================

# ===============Weightment======================== 
from . import gate_weighment
from . import weighment
from . import grower_weighment
from . import farmer_sync_data
# =======================================================

# ===============payemts and loans======================== 
from . import account_payment
from . import out_grower_loan
# =======================================================

# ===============Configuration======================== 
from . import config_routes
from . import config_collection_center
from . import config_stage
from . import config_res_bank_branch
from . import config_trip_cancel_reason
from . import config_accounting_year
# =======================================================

# =======================fleet=============================
from . import res_config_settings
from . import res_partner_fleet
from . import handover
from . import fleet
from . import vehicle_tyre_details
from . import vehicle_fuel_log
from . import external_repair
from . import vehicle
from . import truck_request
from . import product
from . import purchase
# =======================================================


























# from . import casual_labour

from . import stock_picking
# from . import stock_transfer

# from . import tea_arrival
# from . import request_for_quote
# from . import catalog_order
# from . import recatlog_lot_lines

#ident request
# from . import committee
# from . import indent_request
# from . import hr_department
# from . import stock_move
# from . import purchase_requisition
# from . import purchase_order
from . import product_template
# from . import account

# ================ out grower=======================
# from . import outgrower_product
# from . import gate_weighment
# from . import ra_certified
# from . import res_company_extended
# from . import out_grower_extended
# from . import purchase
# from . import stock_picking_extended
# from . import hr
# =======================================================

# from . import maintance

#out-grower-employee
# from . import private_details
# from . import hr_job
# from . import hr_applicant_parameters
# from . import packaging_order_template
# from . import shorting_template
# from . import shorting_order
# from . import packaging_order
# from . import medical_report

#packaging order
# from . import packging_sequence
# from . import stock_packaging
# from . import stock_traceability
# from . import res_company
from . import account_move
# from . import res_config_settings_invoice
# from . import stock_picking_invoice

# from . import purchase_multi_warehouse
# from . import sale
# from . import stock_rule

# ==============auction sale======================
# from . import auction_request
# from . import stock
# ====================================

# ================ quality control=======================
# from . import quality_control
# =============================================

# ================ mrp=======================
# from . import mrp_pause_reason
# from . import mrp_workorder
# from . import mrp_production
# from . import maintenance
# =============================================

# ==================sort================
# from . import stock_short
# from . import stock_short_traceability
# =======================================

# ==================packing================
# from . import stock_packing
# from . import packing_order_template
# from . import packing_order
# =========================================
# from . import pos_order
# from . import quality
#from . import quations