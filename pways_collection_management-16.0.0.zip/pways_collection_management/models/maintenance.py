# -*- coding: utf-8 -*-
from odoo import api, fields, models

class EquipmentDiameterHistory(models.Model):
    _name = 'equipment.diameter.history'
    _description = 'Equipment Diameter Hostory'

    request_id = fields.Many2one('maintenance.request', string='Request')
    equipment_id = fields.Many2one('maintenance.equipment', related='request_id.equipment_id', string='Equipment')
    date = fields.Date('Date')
    before_dia = fields.Float('Before Dia')
    after_dia = fields.Float('After Dia')
    remarks = fields.Char('Remarks')

class MaintenanceEquipment(models.Model):
    _inherit = "maintenance.equipment"

    is_roller = fields.Boolean(string="Is Roller")
    standard_capacity = fields.Float('Standard Capacity')
    processed_qty = fields.Float('Processed Qty')
    diameter_history_ids = fields.One2many('equipment.diameter.history', 'equipment_id')
    available_qty = fields.Float('Available Qty', compute='_compute_available_qty')

    def _compute_available_qty(self):
        for equipment in self:
            equipment.available_qty = equipment.standard_capacity - equipment.processed_qty

    def action_change(self):
        self.processed_qty = 0.0


class MaintenanceRequest(models.Model):
    _inherit = "maintenance.request"

    diameter_history_ids = fields.One2many('equipment.diameter.history', 'request_id')
    is_roller = fields.Boolean(string="Is Roller", related='equipment_id.is_roller')

