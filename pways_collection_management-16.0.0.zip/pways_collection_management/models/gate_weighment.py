# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class GateWeighment(models.Model):
    _name = "gate.weighment"
    _inherit = ['format.address.mixin', 'image.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "Gate Weighment"
    _rec_name = "weighment_no"

    name = fields.Char("Name")
    in_date = fields.Datetime(string="Date & In Time")
    out_date = fields.Datetime(string="Date & Out Time")
    weighment_no = fields.Char(string="Weighment No")
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    moisture = fields.Integer(string='Moisture')
    gross_weight = fields.Float(string='Gross Weight')
    tare_weight = fields.Float(string='Tare Weight')
    net_weight = fields.Float(string='Net Weight', compute='_compute_net_weight',)
    vehicle_no = fields.Char(string='Vehicle No')
    reduction = fields.Float(string='Reduction (%)')
    trip_id = fields.Many2one("trip.trip", string="Trip")
    partner_id = fields.Many2one('res.partner', string="Partner")
    product_id = fields.Many2one('product.product', string="Product")
    origin = fields.Char(string="Origin")
    route_id = fields.Many2one('routes.routes')
    # is_firewood = fields.Boolean(related='route_id.is_firewood', store=True)
    is_for_billing = fields.Boolean(related='route_id.is_for_billing', store=True)
    transfer_created = fields.Boolean('Internal Transfer', readonly=True)
    bill_created = fields.Boolean('Bill Created', readonly=True)
    boiler_cubic = fields.Char(string="Boiler Cubic")
    delvnote_no = fields.Char(string="Delvnote")
    delvnote_date = fields.Date(string="Delvnote Date")
    bill_count = fields.Integer(string="#Bill Count", compute="_tota_bill_count")
    remark = fields.Text(string="Remarks", copy=False)
    is_quality_check = fields.Boolean()
    supplier_claim = fields.Float('Supplier Claim', readonly=True)
    wood_total = fields.Float('Our Claim', readonly=True)
    is_po_created = fields.Boolean('PO Created')

    @api.depends('gross_weight', 'tare_weight')
    def _compute_net_weight(self):
        net_weight = 0.0
        for record in self:
            net_weight = record.gross_weight - record.tare_weight
            record.net_weight = net_weight

    def _tota_bill_count(self):
        for rec in self:
            move_ids = self.env['account.move'].search([('trip_id', '=', self.trip_id.id)])
            rec.bill_count = len(move_ids.ids)

    def open_bill_weighment(self):
        gate_move_ids = self.env['account.move'].search([('trip_id', '=', self.trip_id.id)])
        return {
            'name': _('Bill'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', gate_move_ids.ids)]
        }

    @api.constrains('weighment_no')
    def check_weighment_constraint(self):
        for rec in self:
            get_weighment_id = self.env['gate.weighment'].search([('weighment_no', '=', rec.weighment_no), ('id', '!=', rec.id)])
            if get_weighment_id:
                raise ValidationError(_("Weighment Number must be unique"))

    @api.onchange('trip_id')
    def _onchange_mobile_id(self):
        if self.trip_id:
            self.vehicle_id = self.trip_id.vehicle_id.id if self.trip_id.vehicle_id else False
            self.vehicle_no = self.trip_id.vehicle_id.license_plate if self.trip_id.vehicle_id else ''

    def unlink(self):
        if self.trip_id.state == "done":
            raise ValidationError(_('You cannot delete gate weighment'))
        return super().unlink()