# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    @api.constrains('qty_done')
    def _check_positive_qty_done(self):
        super(StockMoveLine, self)._check_positive_qty_done()
        for ml in self:
            if ml.move_id.purchase_line_id and ml.qty_done > ml.move_id.product_uom_qty:
                raise ValidationError(_('You cannot receive more than purchase quantity.'))

class StockQuant(models.Model):
    _inherit = "stock.quant"

    categ_id = fields.Many2one('product.category', string="Product Category", related='product_id.categ_id', store=True)
    display_quantity = fields.Float(string="Display Quantity", compute="_compute_display_quantity", store=True)
    display_uom_stock_id = fields.Many2one('uom.uom', string="Display Unit Of Measure", related='product_id.display_uom_id')

    @api.depends('quantity', 'display_uom_stock_id')
    def _compute_display_quantity(self):
        for line in self:
            if line.product_uom_id.category_id == line.display_uom_stock_id.category_id:
                line.display_quantity = line.product_uom_id._compute_quantity(line.quantity, line.display_uom_stock_id)
            else:
                line.display_quantity = 0



   