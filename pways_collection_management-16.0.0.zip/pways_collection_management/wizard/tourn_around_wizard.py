from odoo import models, fields, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import date, datetime

from datetime import datetime, time

class TournAroundWizard(models.TransientModel):
    _name = 'tourn.around.wizard'

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    vehicle_id = fields.Many2one('fleet.vehicle', string="Vehicle")
    clerk_id = fields.Many2one("res.partner", domain=[('is_clerk', '=', True)])
    route_id = fields.Many2one("routes.routes")

    def action_print_report(self):
        data = {
            'date_from' : self.date_from,
            'date_to' : self.date_to,
            'vehicle_id' : self.vehicle_id.id,
            'clerk_id' : self.clerk_id.id,
            'route_id' : self.route_id.id,
        }
        return self.env.ref('pways_collection_management.tourn_around_report').report_action(self, data=data)


class TournAroundWizardReport(models.AbstractModel):
    _name = 'report.pways_collection_management.tourn_around_template'

    def search_query(self, record, old_value,new_value):
        query = """SELECT m.create_date
                   FROM mail_tracking_value v
                   LEFT JOIN mail_message m ON (v.mail_message_id = m.id)
                   JOIN trip_trip tp ON (tp.id = m.res_id)
                   WHERE m.model = 'trip.trip'
                     AND m.message_type = 'notification'
                     AND m.res_id = %s
                     AND v.old_value_char = %s
                     AND v.new_value_char = %s
                     ;
                """
        self.env.cr.execute(query, (record, old_value, new_value))
        res = self.env.cr.fetchone()
        user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
        import pytz
        local = pytz.timezone(user_tz)
        date = res[0]
        date = datetime.strptime(datetime.strftime(pytz.utc.localize(date, DEFAULT_SERVER_DATETIME_FORMAT).astimezone(local),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date

    def _prepare_tourn_lines(self, trip_ids):
        lines = []
        for record in trip_ids:
            time_in = self.search_query(record.id, 'Draft','in Progress')
            time_out = self.search_query(record.id, 'in Progress','Done')

            lines.append({
                'vehicle_no': record.vehicle_id.license_plate if record.vehicle_id and record.vehicle_id.license_plate else '',
                'route_name': record.route_id.name,
                'time_out':time_out.strftime('%d/%m/%y %H:%M %p'),
                'time_in': time_in.strftime('%d/%m/%y %H:%M %p'),
                'duration': round((time_out - time_in).total_seconds() / 3600,2),
                'clerk': record.clerk_id.name if record.clerk_id else '',
                'weight': round(record.total_net,2),

                })
        return lines

    def get_domain(self, data):
        domain = []
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        clerk_id = self.env['res.partner'].browse(data.get('clerk_id'))
        route_id = self.env['routes.routes'].browse(data.get('route_id'))
        if data.get('date_from') and data.get('date_to'):
             domain += [('trip_date', '>=', data.get('date_from')), ('trip_date', '<=', data.get('date_to')),('state','=','done')]
        if vehicle_id:
            domain += [('vehicle_id', '=', vehicle_id.id)] 
        if clerk_id:
            domain += [('clerk_id', '=', clerk_id.id)]
        if route_id:
            domain += [('id', '=', route_id.id)]
        return domain


    @api.model
    def _get_report_values(self, docids, data=None):
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        domain = self.get_domain(data)
        trip_ids = self.env['trip.trip'].search(domain)
        lines = self._prepare_tourn_lines(trip_ids)
        vehicle_id = self.env['fleet.vehicle'].browse(data.get('vehicle_id'))
        clerk_id = self.env['res.partner'].browse(data.get('clerk_id'))
        route_id = self.env['routes.routes'].browse(data.get('route_id'))
        return {
            'doc_ids': data.get('ids'),
            'doc_model': data.get('model'),
            'date_from' :  data.get('date_from'),
            'date_to' :  data.get('date_to'),
            'lines' : lines,
            'vehicle_name' : vehicle_id.model_id.display_name if vehicle_id.model_id else '',
            'clerk_name' : clerk_id.name if clerk_id else '',
            'route_name' : route_id.name ,
        }