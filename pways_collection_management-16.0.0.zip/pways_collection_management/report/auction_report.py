# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, models, _
from odoo.exceptions import UserError,ValidationError


class StockPicking(models.AbstractModel):
    _name = 'report.pways_collection_management.report_auction_request'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['stock.picking'].browse(docids)
        for doc in docs:
            if doc.picking_type_id.code != 'outgoing' or doc.state != 'done':
                raise UserError('You can only print done outgoing !')
        return {
            'doc_ids': docids,
            'doc_model': 'stock.picking',
            'docs': self.env['stock.picking'].browse(docids),
        }
