# -*- coding: utf-8 -*-

from odoo import models, fields, api,_


ADDRESS_FIELDS = ('street', 'street2', 'zip', 'city', 'state_id', 'country_id')


class Vendor(models.Model):
    _name = 'installment.vendor'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Vendor'
    _rec_name = 'name'

    company_type = fields.Selection([
        ('individual', 'Individual'),
        ('company', 'Company'),
    ], required=True)
    name = fields.Char(string=_("Name"))
    note = fields.Text()
    street = fields.Char()
    street2 = fields.Char()
    zip = fields.Char(change_default=True)
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict',
                               domain="[('country_id', '=?', country_id)]")
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
    function = fields.Char(string='Job Position')
    title = fields.Many2one('res.partner.title')

    phone = fields.Char(string=_('Phone'))
    mobile = fields.Char(string=_('Mobile'))
    email = fields.Char(string=_('Email'))
    image = fields.Image(string=_("Image"))
    total_amount = fields.Float(compute='get_total_orders')
    purchase_count = fields.Integer(compute='get_total_orders')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.user.company_id.currency_id)

    def get_purchase_orders(self):
        current_vendor_id = self.id
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase',
            'view_mode': 'tree,form',
            'target': 'current',
            'domain': [('vendor_id', '=', current_vendor_id)],
            'res_model': 'installment.purchase.order',
        }

    def get_total_orders(self):
        for rec in self:
            total_purchase = self.env['installment.purchase.order'].search([('vendor_id', "=", rec.id)])
            rec.total_amount = sum(total_purchase.mapped('total_amount'))
            rec.purchase_count = len(total_purchase)
