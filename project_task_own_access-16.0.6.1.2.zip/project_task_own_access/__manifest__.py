# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd. See LICENSE file for full copyright and licensing details.
{
    'name': "Project and Tasks Restricted User Access",
    'version': '6.1.2',
    'price': 99.0,
    'currency': 'EUR',
    'license': 'Other proprietary',
    'summary': """Project and Tasks Restricted User Access""",
    'description': """
Project and Tasks Restricted User Access
Project and Tasks Restricted User Access
""",
    'author': "Probuse Consulting Service Pvt. Ltd.",
    'website': "www.probuse.com",
    'support': 'contact@probuse.com',
    'live_test_url': 'https://probuseappdemo.com/probuse_apps/project_task_own_access/72',#'https://youtu.be/A4pVt7j-jbM',
    'images': ['static/description/image.png'],
    'category' : 'Operations/Project',
    'depends': ['project'],
    'data':[
        'views/project_view.xml',
        'views/task_view.xml',
        'security/security.xml',
    ],
    'installable' : True,
    'application' : False,
    'auto_install' : False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
