# -*- coding: utf-8 -*-
from odoo import api, models, fields, _
from dateutil.relativedelta import relativedelta
from datetime import datetime

import random

from odoo import api, models, fields, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class QualityPoint(models.Model):
    _inherit = "quality.point"

    measure_frequency_unit = fields.Selection([
        ('hours', 'Hours'),
        ('day', 'Days'),
        ('week', 'Weeks'),
        ('month', 'Months')], default="day")

    def run_quality_check(self):
        point_id = self.search([('measure_frequency_type', '=', 'periodical'), ('measure_frequency_unit', '=', 'hours')], limit=1)
        if point_id:
            workorder_ids = self.env['mrp.workorder'].search([('operation_id', '=', point_id.operation_id.id), ('state', '=', 'progress')])
            for workorder in workorder_ids:
                checks = self.env['quality.check'].create({
                    'point_id':  point_id.id,
                    'product_id': workorder.product_id.id,
                    # 'production_id': workorder.production_id.id,
                    'workorder_id': workorder.id,
                    'team_id': point_id.team_id.id,
                })

    def check_execute_now(self):
        self.ensure_one()
        if self.measure_frequency_type == 'all':
            return True
        elif self.measure_frequency_type == 'random':
            return (random.random() < self.measure_frequency_value / 100.0)
        elif self.measure_frequency_type == 'periodical':
            delta = False
            if self.measure_frequency_unit == 'day':
                delta = relativedelta(days=self.measure_frequency_unit_value)
            elif self.measure_frequency_unit == 'week':
                delta = relativedelta(weeks=self.measure_frequency_unit_value)
            elif self.measure_frequency_unit == 'month':
                delta = relativedelta(months=self.measure_frequency_unit_value)
            elif self.measure_frequency_unit == 'hours':
                # delta = relativedelta(hours=self.measure_frequency_unit_value)
                return False
            date_previous = datetime.today() - delta
            checks = self.env['quality.check'].search([
                ('point_id', '=', self.id),
                ('create_date', '>=', date_previous.strftime(DEFAULT_SERVER_DATETIME_FORMAT))], limit=1)
            return not(bool(checks))
        return super(QualityPoint, self).check_execute_now()
