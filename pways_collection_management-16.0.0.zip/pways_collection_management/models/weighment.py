# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class LocationShade(models.Model):
    _name = 'location.shade'

    name = fields.Char(required=True, copy=False)

class StockPicking(models.Model):
    _inherit = "stock.picking"

    trip_id = fields.Many2one('trip.trip', string="Trip")
    gate_weighment_id = fields.Many2one('gate.weighment', string="Gate Weighment")
    sequence = fields.Integer(string='Sequence', default=10)
    shade_id = fields.Many2one('location.shade', string='Shade/Block')

    def button_validate(self):
        res = super(StockPicking, self).button_validate()
        for picking in self.filtered(lambda x: x.picking_type_code == 'internal' and x.gate_weighment_id and x.gate_weighment_id.is_for_billing):
            if picking.gate_weighment_id.transfer_created:
                raise ValidationError(_('Internal Transfer already created for %s weighment.' % picking.gate_weighment_id.weighment_no))
            picking.gate_weighment_id.write({'transfer_created': True})
        return res

class StockMove(models.Model):
    _inherit = "stock.move"

    wooden_kg = fields.Float(string="Wood in Kg")
    rasio = fields.Float(string="Ratio", compute="_get_rasio")
    trip_id = fields.Many2one('trip.trip', 'Trip')
    weighment_id = fields.Many2one('grower.weighment', 'Weighment')

    @api.depends('product_uom_qty', 'wooden_kg')
    def _get_rasio(self):
        for rec in self:
            rasio = 0.0
            if rec.product_uom_qty and rec.wooden_kg:
                rasio = rec.product_uom_qty / rec.wooden_kg
            rec.rasio = rasio

class QualitySheet(models.Model):
    _name = 'quality.sheet'

    trip_id = fields.Many2one('trip.trip')
    location_id = fields.Many2one('stock.location', string='Collection Center')
    daily_collection = fields.Float(string='Daily Collection')
    a_bud = fields.Float(string='A BUD', digits='Product Unit of Measure')
    leaf_1 = fields.Float(string='1 LEAF A BUD', digits='Product Unit of Measure')
    leaf_2 = fields.Float(string='2 LEAF A BUD', digits='Product Unit of Measure')
    soft_bhanji = fields.Float(string='SOFT BHANJI', digits='Product Unit of Measure')
    leaf_3 = fields.Float(string='3 LEAF A BUD', digits='Product Unit of Measure')
    hard_bhanji = fields.Float(string='HARD BHANJI', digits='Product Unit of Measure')
    looses = fields.Float(string='LOOSES', digits='Product Unit of Measure')
    damage_leaf = fields.Float(string='DAMAGE LEAF', digits='Product Unit of Measure')
    quality_type = fields.Selection([('kgs', 'Kgs'), ('percentage', 'Percentage(%)')], string="Description", default='kgs')
