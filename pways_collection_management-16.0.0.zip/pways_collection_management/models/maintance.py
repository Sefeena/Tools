# -*- coding: utf-8 -*-
from odoo import api, fields, models,_

class Maintance(models.Model):
    _inherit = 'repair.order'

    job_no = fields.Char('Job No.')
    vehicle_id = fields.Many2one('fleet.vehicle', 'Fleet No.')
    license_plate = fields.Char(related="vehicle_id.license_plate")
    make  = fields.Char('Make')
    model = fields.Char('Model')
    km_in = fields.Float('Km In')
    km_out = fields.Float('Km Out')
    date_in  = fields.Datetime('Date In')
    date_out  = fields.Datetime('Date Out')
    checked_id  = fields.Many2one('hr.employee', 'Checked By')
    workcenter_id = fields.Many2one('mrp.workcenter', string='Workcenter')
    external_repair_count = fields.Integer(compute='_compute_external_repair')

    def _compute_external_repair(self):
        for order in self:
            order.external_repair_count = self.env['external.repair'].search_count([('repair_id', '=', order.id)])

    def action_external_repair(self):
        return {
            'name': "External Repair",
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'external.repair',
            'view_id': self.env.ref('pways_collection_management.external_repair_view_form').id,
            'context': {
                'default_repair_id': self.id,
                'default_product_id': self.product_id.id,
                'default_qty': self.product_qty,
                'default_partner_id': self.partner_id.id,
            },
        }

    def action_open_external_repair(self):
        return {
            'name': _('External Repair'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'external.repair',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('repair_id', '=', self.id)],
        }


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_part = fields.Boolean(
        string="Is Parts",
        help="Allow product as Parts")
