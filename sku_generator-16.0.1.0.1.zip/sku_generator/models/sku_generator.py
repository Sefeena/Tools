# -*- coding: utf-8 -*-
##########################################################################
# Author : Webkul Software Pvt. Ltd. (<https://webkul.com/>;)
# Copyright(c): 2017-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>;
##########################################################################
from odoo import models, fields, api
from odoo.exceptions import MissingError


class SkuGenerator(models.Model):
    _name = "sku.generator"


    name = fields.Char(string="Name", required=True)
    active = fields.Boolean(string="Active", default=True)
    sku_rule = fields.One2many(
        comodel_name = 'sku.rules',inverse_name= 'sku_rule_generator', string="SKU Rule")
    prefix = fields.Char(string="Prefix")
    suffix = fields.Char(string="Suffix")

    def sku_generate_wizard(self):
        wizard_id = self.env['wizard.sku'].create(
            {'name': 'Do you want to override all products SKU?', 'product': False})
        return {
            "name": "Generate SKU",
            "type": "ir.actions.act_window",
            "res_model": "wizard.sku",
            'res_id': wizard_id.id,
            "view_id": self.env.ref("sku_generator.sku_generator_form").id,
            "view_mode": "form",
            'nodestroy': True,
            "target": "new",
        }

    def _product_function(self,rule,sku_generate_id,separator, product_name, no_of_character):
        sku_generate_id=product_name[0:int(no_of_character)].upper()
        if rule.use_separator:
            sku_generate_id+=separator
        return sku_generate_id

    def _attribute_function(self, rule,attribute_ids, sku_generate_id,trim_sku,avoid_separator,total_record,separator,last_separator):

        if attribute_ids:
            count=0
            if rule.exclude_attribute:
                size=len(rule.exclude_attribute.mapped('id'))
                for attribute in attribute_ids.attribute_id:
                    check=0
                    for excl_attr in rule.exclude_attribute:
                        if attribute!= excl_attr:
                            check+=1    
                    if check==size:
                        sku_generate_id += attribute.name[0:int(rule.no_of_character)].upper()+rule.attribute_separator
                        count+=1
                if count !=0:
                    sku_generate_id =sku_generate_id[:len(sku_generate_id)-len(rule.attribute_separator)]
                    if rule.use_separator:
                        sku_generate_id+=separator
                
                if count==0:
                    if trim_sku==True and total_record==1:
                        sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
                    if rule.use_separator and total_record==1:
                        avoid_separator=True
                return [sku_generate_id,avoid_separator]          
            else:
                for attribute in attribute_ids.attribute_id:
                    sku_generate_id += attribute.name[0:int(rule.no_of_character)].upper()+rule.attribute_separator
                sku_generate_id =sku_generate_id[:len(sku_generate_id)-len(rule.attribute_separator)]
                if rule.use_separator:
                    sku_generate_id+=separator
                return [sku_generate_id,avoid_separator]
        else:
            if trim_sku==True and total_record==1:
                sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
            if rule.use_separator and total_record==1:
                avoid_separator=True
            return [sku_generate_id,avoid_separator]

    def _internal_category_function(self, category_id, rule, sku_generate_id,separator,trim_sku,avoid_separator,total_record,last_separator):
        
        
        size=len(rule.exclude_internal_category.mapped('id'))
        check=0
        if size>0:
            for excl_attr in rule.exclude_internal_category:
                if category_id!= excl_attr:
                        check+=1
            if check==size:
                sku_generate_id += category_id.name[0:int(rule.no_of_character)].upper()
                if rule.use_separator:
                    sku_generate_id+=separator
            else:
                if trim_sku==True and total_record==1:
                    sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
                if rule.use_separator and total_record==1:
                    avoid_separator=True
        elif size==0:
            if category_id != rule.exclude_internal_category:
                sku_generate_id += category_id.name[0:int(rule.no_of_character)].upper()
                if rule.use_separator:
                        sku_generate_id+=separator
            else:
                if trim_sku==True and total_record==1:
                    sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
                if rule.use_separator and total_record==1:
                    avoid_separator=True
        return [sku_generate_id,avoid_separator]
        
    def _ecommerce_category_function(self,rule,ecommerce_category_ids,sku_generate_id,separator,trim_sku,avoid_separator,total_record,last_separator):
        if ecommerce_category_ids:
            count=0
            size=len(rule.exclude_ecommerce_category.mapped('id'))
            if rule.exclude_ecommerce_category:
                for category in ecommerce_category_ids:
                    check=0
                    for excl_categ in rule.exclude_ecommerce_category:
                        if category !=excl_categ:
                            check+=1
                            
                    if check==size:
                        sku_generate_id += category.name[0:int(rule.no_of_character)].upper()+rule.ecommerce_separator
                        count+=1
                    
                if count !=0:
                    sku_generate_id =sku_generate_id[:len(sku_generate_id)-len(rule.ecommerce_separator)]
                    if rule.use_separator:
                        sku_generate_id+=separator
                if count==0:
                    if trim_sku==True and total_record==1:
                        sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
                    if rule.use_separator and total_record==1:
                        avoid_separator=True    
                return [sku_generate_id,avoid_separator]          
            else:
                for category in ecommerce_category_ids:
                    sku_generate_id += category.name[0:int(rule.no_of_character)].upper()+rule.ecommerce_separator
                sku_generate_id =sku_generate_id[:len(sku_generate_id)-len(rule.ecommerce_separator)]
                if rule.use_separator:
                    sku_generate_id+=separator
                return [sku_generate_id,avoid_separator]
            
        else:
            if trim_sku==True and total_record==1:
                sku_generate_id=sku_generate_id[:len(sku_generate_id)-last_separator]
            if rule.use_separator and total_record==1:
                avoid_separator=True
            return [sku_generate_id,avoid_separator]  

    def _sequence_function(self,rule,sku_generate_id,separator):
        if rule.next_option:
            rule.next_option = str(
                int(rule.next_option)).zfill(rule.size)
        else:
            rule.next_option = str(
                rule.start).zfill(rule.size)
        if rule.sequence_prefix:
            sku_generate_id += (rule.sequence_prefix + rule.next_option)
        else:
            sku_generate_id += rule.next_option
        rule.next_option = str(
            int(rule.next_option)+rule.step)
        if rule.use_separator:
            sku_generate_id+=separator
        return sku_generate_id
    def _add_prefix_suffix(self,sku_generator_id,sku_generate_id,trim_sku,last_separator):
        if sku_generator_id.prefix:
            sku_generate_id = sku_generator_id.prefix+ sku_generate_id
        if trim_sku:
            sku_generate_id = sku_generate_id[:len(
                sku_generate_id)-last_separator]
        if sku_generator_id.suffix:
            sku_generate_id += sku_generator_id.suffix
        return sku_generate_id
        

    def _condition_check_for_changes(self, condition, products_id, sku_generator_id):
        if condition:
            for rule in sku_generator_id.sku_rule:
                rule.next_option = ""
        if products_id:
            
            for product in products_id:
                sku_generate_id = ''
                trim_sku = False
                last_separator=0
                avoid_separator=''
                sku_rule = sku_generator_id.sku_rule
                start=0
                if sku_rule:
                    total_record=len(sku_rule.mapped('id'))
                    for rule in sku_rule:
                        if rule.use_separator:
                            separator = rule.separator
                        else:
                            separator = ''   
                        if rule.sku_type == 'product':
                            sku_generate_id += self._product_function(rule,sku_generate_id,separator,
                                product.name, rule.no_of_character)
                        elif rule.sku_type == 'attribute':
                            sku_data = self._attribute_function(rule,
                                product.attribute_line_ids, sku_generate_id,trim_sku,avoid_separator,total_record,separator,last_separator)
                            sku_generate_id=sku_data[0]
                            avoid_separator=sku_data[1]
                        elif rule.sku_type == 'internal category':
                            sku_data= self._internal_category_function(
                                product.categ_id, rule, sku_generate_id,separator,trim_sku,avoid_separator,total_record,last_separator)
                            sku_generate_id=sku_data[0]
                            avoid_separator=sku_data[1]
                        elif rule.sku_type == 'ecommerce category':
                            sku_data = self._ecommerce_category_function(rule,product.public_categ_ids,
                                sku_generate_id,separator,trim_sku,avoid_separator,total_record,last_separator)
                            sku_generate_id=sku_data[0]
                            avoid_separator=sku_data[1]
                        elif rule.sku_type == 'sequence':
                            sku_generate_id = self._sequence_function(rule,sku_generate_id,separator)
                        if rule.use_separator:
                            last_separator=len(separator)
                            if avoid_separator==True:
                                trim_sku=False
                                avoid_separator=''
                            else:
                                trim_sku = True
                        else:
                            trim_sku = False
                            last_separator=0
                        total_record-=1
                product.default_code = self._add_prefix_suffix(sku_generator_id,sku_generate_id,trim_sku,last_separator)
        else:
            raise MissingError("No one record found without SKU!")
        return self._add_prefix_suffix(sku_generator_id,sku_generate_id,trim_sku,last_separator)


class SkuRules(models.Model):
    _name = "sku.rules"
    _rec_name = 'sku_type'

    sku_rule_generator = fields.Many2one(
        'sku.generator', string="SKU Rule Generator")
    use_separator = fields.Boolean(string="Use separator")
    separator = fields.Char(string="separator")
    sku_type = fields.Selection([('product', 'Product'), ('attribute', 'Attributes'), (
        'internal category', 'Internal Category'), ('ecommerce category', 'Ecommerce Category'), ('sequence', 'Sequence')], required=True, string='SKU Type')
    no_of_character = fields.Selection(
        [('1', 'One'), ('2', 'Two'), ('3', 'Three')])
    attribute_separator = fields.Char(string="Attribute separator")
    exclude_attribute = fields.Many2many(
        'product.attribute', 'exclude_product_attr_rel',  string="Exclude Attribute")
    exclude_internal_category = fields.Many2many(
        'product.category', string='Exclude Category')
    exclude_ecommerce_category = fields.Many2many(
        'product.public.category', 'exclude_public_category_rel', 'exclude_ecommerce_categ_id', 'public_category_id',string="Exclude Ecommerce Categ")
    ecommerce_separator = fields.Char(string="separator")
    step = fields.Integer(string="Step")
    size = fields.Integer(string='Minimum Size')
    start = fields.Integer(string="Sequence start")
    next_option = fields.Char(string="Next", readonly=True)
    sequence_prefix = fields.Char(String="Prefix")


    @api.model_create_multi
    def create(self,vals_list):
        res = super(SkuRules,self).create(vals_list)
        return res

    def read(self, fields=None, load='_classic_read'):
        res = super(SkuRules, self).read(fields=fields, load=load)
        return res
