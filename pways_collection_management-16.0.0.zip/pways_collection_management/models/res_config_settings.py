# -*- coding: utf-8 -*-
from odoo import fields, models


class Settings(models.TransientModel):
    _inherit = 'res.config.settings'

    csr_journal_id = fields.Many2one('account.journal', string='CSR Journal', config_parameter='pways_collection_management.csr_journal_id')
    csr_credit_account_id = fields.Many2one('account.account', string='Credit Account', config_parameter='pways_collection_management.csr_credit_account_id')
    csr_debit_account_id = fields.Many2one('account.account', string='Debit Account', config_parameter='pways_collection_management.csr_debit_account_id')
