# from odoo import fields , models,api,tools,_
# from datetime import datetime,timedelta
# from odoo.exceptions import ValidationError
# # from odoo import amount_to_text
#
# class CheckFollowup(models.Model):
#
#     _inherit = 'check.followup'
#
#     check_created = fields.Date(string='Petty cash Date',)
#     petty_cash_id = fields.Many2one('custody.request',string='Petty cash Request')
