# -*- coding: utf-8 -*-
{
    'name': "Installment Management",

    'summary': """Installment Management module is used to installment products for customers""",
    'version': '15.0',
    'description': """With the Odoo Installment Management Module, you can easily create and manage installment plans for your customers. 
    This module is perfect for businesses that sell products or services on a long-term basis, such as furniture stores, car dealerships, and educational institutions.""",
    'author': 'Neoteric Hub',
    'company': 'Neoteric Hub',
    'live_test_url': '',
    'price': 149.0,
    'currency': 'USD',
    'category': 'Sales',
    'website': "https://www.neoterichub.com",

    'depends': ['base', 'mail'],

    'data': [
        'data/data_views.xml',
        'security/ir.model.access.csv',
        'views/category_views.xml',
        'views/configuration_views.xml',
        'views/customer_views.xml',
        'views/installment_views.xml',
        'views/installment_line_views.xml',
        'views/customer_views.xml',
        'views/installment_views.xml',
        'views/product_views.xml',
        'views/purchase_views.xml',
        'views/vendor_views.xml',
        'wizards/installment_payment_views.xml',
        'views/menu_views.xml',
        "reports/installment_templates.xml",
        "reports/purchase_templates.xml",
        "reports/pay_report_template.xml",
        "reports/installment_line_templates.xml",
    ],
    'images': ['static/description/banner.gif'],
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
