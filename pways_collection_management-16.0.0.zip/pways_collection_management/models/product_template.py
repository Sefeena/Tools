# -*- coding: utf-8 -*-

from odoo import models,fields,api, _
from odoo.addons import decimal_precision as dp
from odoo.exceptions import ValidationError, UserError
from odoo.tools.float_utils import float_compare, float_is_zero, float_round

class ProductCategory(models.Model):
    _inherit = 'product.category'

    property_account_expense_id_from_indent = fields.Many2one('account.account')


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_fuel_product = fields.Boolean(string="Is Fuel Product", help="Allow Crate Fuel Product")

    def _get_product_accounts(self):
        accounts = super(ProductTemplate, self)._get_product_accounts()
        if self.categ_id.property_account_expense_id_from_indent:
            accounts.update({'stock_output': self.categ_id.property_account_expense_id_from_indent})
        return accounts
