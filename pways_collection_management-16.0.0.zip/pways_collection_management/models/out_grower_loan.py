# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError

class StockPicking(models.Model):
    _inherit = "stock.picking"

    loan_id = fields.Many2one('out.grower.loan', string="Loan")

class OutGrowerLoan(models.Model):
    _name = "out.grower.loan"
    _inherit = ['format.address.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = "out.grower.loan"
    _rec_name = 'name'

    @api.depends('loan_line_ids.price_subtotal', 'loan_line_ids.quantity', 'loan_line_ids.unit_price')
    def _compute_total(self):
        for rec in self:
            total_amount = 0.0
            for line in rec.loan_line_ids:
                total_amount += line.price_subtotal
            rec.total_amount = total_amount

    name = fields.Char('Name', required=True, index=True, readonly=True, copy=False, default='New')
    farmer_id = fields.Many2one('res.partner', string="Out Grower", required=True)
    farmer_code = fields.Char(string="Out Grower Code")
    farmer_registration_no = fields.Char(string="Registration No")
    journal_id = fields.Many2one('account.journal', string='Journal', required=True)
    date = fields.Date(string="Date", default=fields.Date.today(), required=True)
    note = fields.Text(string="Notes")
    state = fields.Selection([('draft','Draft'), ('confirm','Confirm'), ('cancel','Cancel')], 
        string='Status', required=True, readonly=True, copy=False, tracking=True, default='draft')
    loan_line_ids = fields.One2many("out.grower.loan.line", "loan_id", string="Loan ids")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True, readonly=True, default=lambda self: self.env.company.currency_id.id)
    total_amount = fields.Float(string='Total Amount', compute="_compute_total")
    payment_count = fields.Integer(compute='_payment_count', string='# Payment')
    payment_term_id = fields.Many2one('account.payment.term', 'Payment Terms')
    picking_count = fields.Integer(string="#Delivery Count", compute="_tota_picking_count")
    farmer_due = fields.Float('Outstanding Amount', compute='_compute_farmer_due')
    credit_account_id = fields.Many2one('account.account', string="Credit Account")
    debit_account_id = fields.Many2one('account.account', string="Debit Account")

    def _prepare_procurement_id(self):
        procurement = self.env["procurement.group"].create({'name' : self.name})
        return procurement

    def _prepare_move_outgoing(self, line):
        company_id = self.env.company
        picking_type_id = self.env['stock.picking.type'].search([('code', '=', 'outgoing')], limit=1)
        procurement_id = self._prepare_procurement_id()
        return {
            'name' : line.product_id.name,
            'product_id': line.product_id.id,
            'product_uom': line.product_id.uom_id.id,
            'location_id': picking_type_id.default_location_src_id.id or False,
            'location_dest_id':self.farmer_id.property_stock_customer.id if self.farmer_id.property_stock_customer else False,
            'company_id': company_id.id,
            'product_uom_qty': line.quantity,
            'origin': self.name,
            'group_id' : procurement_id.id,
            'picking_type_id': picking_type_id.id,
            'quantity_done' : line.quantity,
            'partner_id' : self.farmer_id.id or False
        }

    def button_confirm(self):
        if not self.loan_line_ids:
            raise UserError(_('You need to add some lines before confirm.'))
        if self.farmer_due < self.total_amount:
            raise UserError(_('Insufficient Balance'))
        move_lines = [self._prepare_move_outgoing(line) for line in self.loan_line_ids]
        move_ids = self.env['stock.move'].create(move_lines)
        stock_move = move_ids._action_confirm()
        stock_move._action_done()
        if stock_move.picking_id:
            stock_move.picking_id.write({'loan_id' : self.id})
        self.create_deduction_entry()
        self.write({'state' : 'confirm'})

    def button_cancel(self):
        picking = self.env['stock.picking'].search([('loan_id', '=', self.id), ('state', '=', 'done'), ('origin', '=', self.name)])
        return_picking = self.env['stock.picking'].search([('loan_id', '=', self.id), ('origin', 'like', picking.name), ('state', '=', 'done')])
        account_move = self.env['account.move'].search([('loan_id', '=', self.id), ('state', '=', 'posted')])
        if (picking and not return_picking) or account_move:
            raise UserError(_('Please return delivery and cancel journal entry manually!'))
        self.write({'state' : 'cancel'})

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('out.grower.loan') or '/'
        return super(OutGrowerLoan, self).create(vals)

    def _payment_count(self):
        for rec in self:
            move_ids = self.env['account.move'].search([('out_grower_loan_id', '=', rec.id)])
            rec.payment_count = len(move_ids.ids)

    def view_payment(self):
        move_ids = self.env['account.move'].search([('out_grower_loan_id', '=', self.id)])
        return {
            'name': _('Journal Entry'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'views': [(self.env.ref('account.view_move_tree').id, 'tree'), (False, 'form')],
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', move_ids.ids)],
        }

    @api.onchange('farmer_id')
    def onchange_farmer_id(self):
        if self.farmer_id:
            self.farmer_code = self.farmer_id.code if self.farmer_id.code else ""
            self.farmer_registration_no = self.farmer_id.self.farmer_id.uuid_random if self.farmer_id.uuid_random else ""

    @api.depends('farmer_id')
    def _compute_farmer_due(self):
        for loan in self:
            line_ids = self.env['account.move.line'].search([('move_id.state', '=', 'posted'), ('partner_id', '=', loan.farmer_id.id), ('account_id.account_type', '=', 'liability_payable')])
            loan.farmer_due = sum(line_ids.mapped('credit'))-sum(line_ids.mapped('debit'))

    def _tota_picking_count(self):
        for rec in self:
            picking_ids = self.env['stock.picking'].search([('loan_id', '=', rec.id)])
            rec.picking_count = len(picking_ids.ids)

    def view_picking(self):
        picking_ids = self.env['stock.picking'].search([('loan_id', '=', self.id)])
        return {
            'name': _('Picking'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', picking_ids.ids)]
        }

    def create_deduction_entry(self):
        if self.journal_id and self.debit_account_id and self.credit_account_id:
            deduction_amount = self.total_amount
            move = self.env['account.move'].create({
                'move_type': 'entry',
                'date': self.date,
                'journal_id': self.journal_id.id,
                'ref': 'FERTILIZER DEDUCTION ' + self.name,
                'out_grower_loan_id': self.id,
                'partner_id': self.farmer_id.id,
                'currency_id': self.env.user.company_id.currency_id.id,
                'line_ids': [
                    (0, 0, {
                        'debit': deduction_amount,
                        'credit': 0.0,
                        'name': 'FERTILIZER DEDUCTION ' + self.name,
                        'date_maturity': self.date,
                        'account_id': self.debit_account_id.id,
                        'partner_id': self.farmer_id.id,
                    }),
                    (0, 0, {
                        'debit': 0.0,
                        'credit': deduction_amount,
                        'date_maturity': self.date,
                        'name': 'FERTILIZER DEDUCTION ' + self.name,
                        'account_id': self.credit_account_id.id,
                        'partner_id': self.farmer_id.id,
                    }),
                ],
            })
            move.action_post()
        return True

class OutGrowerLoanLine(models.Model):
    _name = 'out.grower.loan.line'
    _description = 'Direct Transfer Line'

    @api.depends('unit_price', 'quantity')
    def _compute_amount(self):
        for line in self:
            line.price_subtotal = line.unit_price * line.quantity

    product_id = fields.Many2one('product.product', 'Product', required=True)
    name = fields.Char(string='Description')
    quantity = fields.Float('Quantity', default=1.0)
    ave_quantity = fields.Float('Available Quantity', related="product_id.qty_available")
    unit_price = fields.Integer(string='Unit price')
    uom_id = fields.Many2one('uom.uom', string='Unit of Measure')
    price_subtotal = fields.Float(string='Subtotal', compute="_compute_amount")
    loan_id = fields.Many2one('out.grower.loan', 'Loan')
    tax_ids = fields.Many2many('account.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])

    @api.onchange('product_id')
    def onchange_product_id(self):
        if self.product_id:
            self.unit_price = self.product_id.standard_price or 0.0
            self.ave_quantity = self.product_id.qty_available
            self.name = self.product_id.display_name
            self.uom_id = self.product_id.uom_id.id

