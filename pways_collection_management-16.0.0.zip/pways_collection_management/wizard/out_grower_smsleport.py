# -*- coding: utf-8 -*-
from odoo import models,fields,api,_
import datetime
import logging
_logger = logging.getLogger(__name__)


class SmsleportWizard(models.TransientModel):
    _name = 'smsleport.wizard'

    sms_date = fields.Datetime('Date', default=fields.Date.today())

    def send_sms(self):
        total_net = 0.0
        grower_weighment_ids = self.env['grower.weighment'].search([('weighment_date' , '=', self.sms_date)])
        if grower_weighment_ids and self.env.user.has_group('pways_collection_management.group_weighment_send_sms'):
            farmer_ids = grower_weighment_ids.mapped('farmer_id').filtered(lambda x : x.send_sms)
            for farmer in farmer_ids:
                weighment_ids = grower_weighment_ids.filtered(lambda x: x.farmer_id.id == farmer.id)
                total_net = sum(rec.total_net for rec in weighment_ids)
                self.env['grower.weighment'].send_message(farmer, total_net, self.sms_date)
        return True