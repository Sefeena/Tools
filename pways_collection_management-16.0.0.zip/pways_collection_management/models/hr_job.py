# -*- coding: utf-8 -*-
from odoo import fields, models, api, _

class HrJobs(models.Model):
    _inherit = 'hr.job'

    job_number = fields.Char('Number')
    job_position_kpi_ids = fields.Many2many('hr.applicant.parameters', string="KPI")
    job_detail = fields.Text('Job Detail')

    # @api.model
    # def create(self, vals):
    #     code = self.env['ir.sequence'].next_by_code('hr.job')
    #     vals['job_number'] = code
    #     return super(HrJobs, self).create(vals)

