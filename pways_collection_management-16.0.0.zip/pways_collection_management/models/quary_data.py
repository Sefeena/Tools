# -*- coding: utf-8 -*-

from odoo import models,fields,api,_
import datetime
import requests
import json
import logging
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from dateutil.relativedelta import relativedelta
import pytz
_logger = logging.getLogger(__name__)
import pymysql.cursors

class OdooInsert(models.Model):
    _name = "outgrower.odoo.quary"
    _description = "Insert Quary"
    _rec_name = "weighment_no"

    weighment_no = fields.Char(string="Weighment No")
    gwe_date = fields.Char(string="Gwe Date")
    gwe_in_time = fields.Char(string="Gwe In Time")
    gwe_out_time = fields.Char(string="Gwe Out Time")
    grosswt = fields.Float(string="Gwe Gross Wt")
    tare_wt = fields.Float(string="Gwe Tare Wt")
    net_wt = fields.Float(string="Gwe Net Wt")
    reduction_wt = fields.Float(string="Reduction Wt")
    rm_id = fields.Char(string="RM ID")
    trip_no_of_days = fields.Float(string="Trip No of Days")
    delvnoteno = fields.Char(string="Delvnoteno")
    delvnote_date = fields.Char(string="Delvnote Date")
    unit_id = fields.Char(string="Unit ID")
    user_idcr = fields.Char(string="User Idcr")
    date_cr = fields.Char(string="Date Cr")
    gwe_id = fields.Char(string="Gwe Id")
    vm_id = fields.Char(string="VM Id")
    fm_id = fields.Char(string="FM Id")
    vehicle_number = fields.Char(string="Vehicle Number")
    moisture = fields.Char(string="Moisture")
    boilercubic = fields.Char(string="Boilercubic")
    weighment_id = fields.Integer(string="Weighment")
    is_weighment = fields.Boolean(string="Is Weighment")

    # _sql_constraints = [
    #     ('weighment_no_uniq', 'unique (weighment_no)', 'The Weighment No must be unique !')
    # ]

    def _connect_mysql_instance(self):
        company_id = self.env.company
        if (not company_id.mysql_host_name) or (not company_id.mysql_port) or (not company_id.mysql_user_name) or (not company_id.mysql_passwd) or (not company_id.mysql_db):
            _logger.info("Getting an Error set configuration Company: {0}".format(e))
            return False
        try:
            db = pymysql.connect(host=company_id.mysql_host_name, port=int(company_id.mysql_port), user=company_id.mysql_user_name, passwd=company_id.mysql_passwd, db=company_id.mysql_db)
            return db
        except Exception as e:
            _logger.info("Getting an Error in database connection: {0}".format(e))
            return False

    def _get_keys(self):
        return ('WEIGHMENT_NO', 'GWE_DATE', 'GWE_IN_TIME', 'GWE_OUT_TIME', 'GWE_GROSSWT', 'GWE_TARE_WT', 'NET_WT', 'REDUCTION_WT', 'RM_ID', 'TRIP_NO_OF_DAYS', 'DELVNOTENO',
         'DELVNOTE_DATE', 'UNIT_ID', 'USR_IDCR', 'DATE_CR', 'GWE_ID', 'VM_ID', 'FM_ID', 'VEHICLE_NUMBER', 'MOISTURE', 'BOILERCUBIC')

    def _prepare_quary_data(self, outgrower_data):
        keys = self._get_keys()
        quary_data = []
        for record in outgrower_data:
            quary_data.append(dict(zip(keys, record)))
        return quary_data

    def _find_vehicle(self, record):
        vehicle_id = False
        if record.vm_id:
            vehicle_id = self.env['fleet.vehicle'].search([('id', '=', int(record.vm_id))])
        return vehicle_id

    def _find_partner(self, record):
        farmer_id = False
        if record.fm_id:
            farmer_id = self.env['res.partner'].search([('id', '=', int(record.fm_id))])
        return farmer_id

    def find_tip(self, vehicle_id):
        trip_id = False
        if vehicle_id:
           trip_id = self.env['trip.trip'].search([('vehicle_id', '=', int(vehicle_id.id)), ('state', '=', 'in_progress')], limit=1)
        return trip_id

    def find_route(self, record):
        rm_id = False
        if record.rm_id:
            rm_id = self.env['routes.routes'].browse(int(record.rm_id))
        return rm_id

    def convert_str_to_datetime(self, value):
        datetime_obj = False
        if value:
            datetime_obj = datetime.datetime.strptime(value, "%d%m%Y%H%M%S")
        return datetime_obj

    def _get_utc_time(self, date):
        """ Need to configure a time (local to server) in proper manners"""
        user_tz = self.env.user.tz or self.env.context.get('tz') or 'UTC'
        local = pytz.timezone(user_tz)
        date_utc = datetime.datetime.strptime(datetime.datetime.strftime(local.localize(datetime.datetime.strptime(date, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(pytz.utc),"%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S")
        return date_utc


    def create_get_weighment(self):
        mysql_instance = self._connect_mysql_instance()
        if mysql_instance:
            mycursor = mysql_instance.cursor()
            for record in self.env['outgrower.odoo.quary'].sudo().search([('is_weighment', '=', False)]):
                vehicle_id = self._find_vehicle(record)
                farmer_id = self._find_partner(record)
                trip_id = self.find_tip(vehicle_id)
                route_id = self.find_route(record)
                utc_in_time = self.convert_str_to_datetime(record.gwe_in_time)
                utc_out_time = self.convert_str_to_datetime(record.gwe_out_time)
                vals = {
                    'weighment_no' : record.weighment_no,
                    'in_date' : self._get_utc_time(str(utc_in_time)),
                    'out_date' : self._get_utc_time(str(utc_out_time)),
                    'gross_weight' : record.grosswt,
                    'tare_weight' : record.tare_wt,
                    'net_weight' : record.tare_wt,
                    'route_id': route_id.id if route_id else False,
                    'vehicle_no' : record.vehicle_number,
                    'boiler_cubic' : record.boilercubic,
                    'delvnote_no' : record.delvnoteno,
                    'vehicle_id' : vehicle_id.id if vehicle_id else False,
                    'partner_id' : farmer_id.id if farmer_id else False,
                    'trip_id' : trip_id.id if trip_id else False,
                }
                weighment_id = self.env['gate.weighment'].search([('weighment_no', '=', record.weighment_no)], limit=1)
                if not weighment_id:
                    weighment_id = self.env['gate.weighment'].sudo().create(vals)
                if mycursor:
                    sql_query = "update outgrower_odoo_query set odoo_id='%s' where WEIGHMENT_NO='%s'"%(str(weighment_id.id), record.weighment_no);
                    mycursor.execute(sql_query)
                if trip_id:
                    trip_id.gate_weighment_id = weighment_id
                record.write({'weighment_id' : weighment_id.id, 'is_weighment' : True})
            mysql_instance.commit()
        return True
            

    def create_data(self, lines):
        record = []
        for rec in lines:
            quary_ids = self.env['outgrower.odoo.quary'].sudo().search([('weighment_no', '=', rec.get('WEIGHMENT_NO'))])
            if not quary_ids:
                record.append({
                    'weighment_no' : rec.get('WEIGHMENT_NO'),
                    'gwe_date' : rec.get('GWE_DATE'),
                    'gwe_in_time' : rec.get('GWE_IN_TIME'),
                    'gwe_out_time' : rec.get('GWE_OUT_TIME'),
                    'grosswt' : rec.get('GWE_GROSSWT'),
                    'tare_wt' : rec.get('GWE_TARE_WT'),
                    'net_wt' : rec.get('NET_WT'),
                    'reduction_wt' : rec.get('REDUCTION_WT'),
                    'rm_id' : rec.get('RM_ID'),
                    'trip_no_of_days' : rec.get('TRIP_NO_OF_DAYS'),
                    'delvnoteno' : rec.get('DELVNOTENO'),
                    'delvnote_date' : rec.get('DELVNOTE_DATE'),
                    'unit_id' : rec.get('UNIT_ID'),
                    'user_idcr' : rec.get('USR_IDCR'),
                    'date_cr' : rec.get('DATE_CR'),
                    'gwe_id' : rec.get('GWE_ID'),
                    'vm_id' : rec.get('VM_ID'),
                    'fm_id' : rec.get('FM_ID'),
                    'vehicle_number' : rec.get('VEHICLE_NUMBER'),
                    'moisture' : rec.get('MOISTURE'),
                    'boilercubic' : rec.get('BOILERCUBIC'),
                })
        if record:
            self.env['outgrower.odoo.quary'].create(record)

    def _get_server_ip(self):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        server_id = s.getsockname()[0]
        s.close()
        return server_id

    def quary_sync_data(self):
        company_id = self.env.company
        if company_id.server_ip == self._get_server_ip():
            mysql_instance = self._connect_mysql_instance()
            if mysql_instance:
                mycursor = mysql_instance.cursor()
                mycursor.execute("select * from outgrower_odoo_query where odoo_id is null;")
                outgrower_data = mycursor.fetchall()
                if outgrower_data:
                    quary_data = self._prepare_quary_data(outgrower_data)
                    self.create_data(quary_data)
                mysql_instance.commit()
                self.create_get_weighment()
        return True
