# -*- coding: utf-8 -*-
from . import hr_loan
from . import hr_payroll
from . import res_config_settings
from . import account_payment

